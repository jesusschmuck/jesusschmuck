=== Jesusschmuck Social MCP ===
Contributors: jesusschmuck
Tags: instagram, facebook, mcp, reels, scheduling
Requires at least: 6.4
Requires PHP: 8.1
Stable tag: 0.7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Eigenständige Social-Veröffentlichung mit ausdrücklicher Freigabe, serverseitiger Warteschlange und MCP.

== Description ==
Siehe LIESMICH.md und docs/EINRICHTUNG.md. Meta-App, Facebook Login, gewählte Zielkonten und minütlicher CLI-Cronjob müssen eingerichtet werden. Keine Verbindung oder Veröffentlichung erfolgt automatisch bei Aktivierung.

Version 0.1.3: Meta-App-Zugangsdaten können geschützt in WordPress gespeichert werden; kein eigener Verschlüsselungsschlüssel in wp-config.php mehr erforderlich. MCP erhält Setup-/Diagnose-/Zielauswahl-Werkzeuge, unterstützt Remote-Origins mit Bearer/OAuth und weist offline_access für Refresh-Tokens aus. 0.1.2: Leichter CLI-Runner prüft Termine ohne WordPress-Start im Leerlauf; vollständige Kontrollprüfung stündlich.

== Installation ==
ZIP über WordPress hochladen, aktivieren und Jesusschmuck Social > Verbindungen öffnen.
Meta-App-Zugangsdaten im Bereich Verbindungen speichern, Facebook Login autorisieren, Zielseite auswählen, System-Cronjob prüfen und anschließend MCP verbinden.

== Changelog ==

= 0.2.2 =
* OAuth 2.0 + PKCE für ChatGPT Sites/Web wieder aktiviert; private URL bleibt Fallback.
* MCP-Discovery vor Login erlaubt; Social-Daten und Publish-Logik unverändert.
* Leere required-Arrays bleiben aus den Tool-Schemas entfernt.

= 0.2.0 =
* Eigenständige ChatGPT-MCP-Anbindung nach dem bewährten privaten URL-Token-Prinzip.
* Bestehende Meta-Konfiguration, verschlüsselte Tokens, Zielkonten, Jobs, Queue, Worker und Freigabelogik bleiben erhalten.
* MCP-OAuth/PKCE/DCR wird für die ChatGPT-Verbindung nicht mehr benötigt.
* Leere required-Arrays aus Tool-Schemas entfernt, um strikte MCP-Clients nicht zu blockieren.
* Private MCP-Adresse kann im WordPress-Admin kopiert und rotiert werden.
* Keine Verbindung oder Änderung am Jesusschmuck Produktkatalog.

= 0.1.5 =
MCP-/ChatGPT-OAuth-Kompatibilität aktualisiert: initialize und tools/list sind vor dem Login erreichbar, alle Social-Tools deklarieren oauth2/securitySchemes mit social:manage, und nicht authentifizierte Tool-Aufrufe liefern die MCP-Challenge _meta["mcp/www_authenticate"]. Nutzerdaten und Schreibaktionen bleiben tokenpflichtig; Meta-Veröffentlichungslogik und Freigabeschutz unverändert.
= 0.1.4 =
MCP-OAuth: Lokale HTTP-Rückrufadressen für Desktop-Clients werden ausschließlich für 127.0.0.1 und [::1] akzeptiert. Bei der Autorisierung darf nur der lokale Port gemäß RFC 8252 variieren; Host, Pfad und Query bleiben exakt gebunden. Beim Tokenaustausch muss die tatsächlich autorisierte Rückrufadresse einschließlich Port exakt stimmen. Fremde HTTP-Ziele bleiben gesperrt. Meta-Anbindung, Warteschlange, Cronjob und Veröffentlichungsfreigaben unverändert.
= 0.1.3 =
Geschützte Meta-Konfiguration direkt in WordPress; WordPress-Salts als Verschlüsselungsfallback; neue MCP-Tools für Status, Routen, Betriebsoptionen und Zielauswahl; Remote-MCP-Origin-Blockade entfernt; OAuth-Discovery um offline_access/Refresh-Token-Kompatibilität ergänzt.
= 0.1.2 =
Minütlicher Runner ohne WordPress/DB/Netzwerk im Leerlauf. Dauerhafter Termin-Hinweis vor Datenbankänderungen invalidiert; nächster Termin unter bestehender DB-Sperre aktualisiert. Prozesssperre vor WordPress-Start, stündliche Kontrollprüfung, Dateiprüfsumme, getrennte Timer-/Worker-Anzeige und Fehlerstatus. Freigabe- und Doppelpost-Schutz erhalten.
= 0.1.1 =
Performance: Klassen erst bei Verwendung laden; Verwaltung und OAuth-Einstiegspunkte über verzögerte Callbacks. Keine OAuth-Discovery-Prüfung auf gewöhnlichen Shopseiten. Freigabe, Warteschlange, Konfiguration und Veröffentlichung unverändert.
= 0.1.0 =
Erste eigenständige Version: Reels und JPEG, Vorschau/Freigabe, Berlin-Termine, plattformspezifische Warteschlange, Instagram Audio, Facebook Login, MCP mit OAuth/PKCE.
