(function () {
  'use strict';
  document.querySelectorAll('.jss-media').forEach(function (button) {
    button.addEventListener('click', function () {
      var field = document.getElementById(button.dataset.target);
      var frame = wp.media({ title: 'Datei für den Social-Beitrag', multiple: false,
        library: { type: button.dataset.target === 'cover_id' ? 'image' : ['video', 'image'] },
        button: { text: 'Diese Datei verwenden' } });
      frame.on('select', function () {
        var selected = frame.state().get('selection').first().toJSON();
        field.value = selected.id;
        button.textContent = selected.filename || selected.title || 'Datei ausgewählt';
      });
      frame.open();
    });
  });
})();
