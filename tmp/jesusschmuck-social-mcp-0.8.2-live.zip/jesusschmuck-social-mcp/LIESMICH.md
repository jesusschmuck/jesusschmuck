# Jesusschmuck Social MCP 0.1.3

Eigenständiges WordPress-Plugin für Instagram und Facebook. Erstversion für Einrichtung und kontrollierten Kontotest. Erstversion vom 19.09.2026, Performance-Update vom 25.09.2026.

## Start

1. Dieses ZIP unter **WordPress → Plugins → Installieren → Plugin hochladen** installieren und aktivieren.
2. **Jesusschmuck Social → Verbindungen** öffnen.
3. Die Anleitung [docs/EINRICHTUNG.md](docs/EINRICHTUNG.md) abarbeiten: geschützte Konfiguration, eigene Meta-App, Facebook Login, konkrete Zielseite, Server-Cronjob, separate MCP-Verbindung.
4. Ein Medium einmal hochladen, Zielplattformen und Texte wählen und einen **Entwurf** speichern.
5. Erst nach Prüfung der vollständigen Vorschau ausdrücklich freigeben. Ein zukünftiger Termin ist bis dahin unverbindlich.

**Das mitgelieferte Plugin enthält weder Zugangsdaten noch einen freigegebenen/geplanten Beitrag. Das Test-Reel wird nicht mitinstalliert und nicht automatisch veröffentlicht.**

## Enthalten

- Reels und JPEG-Einzelbilder; Instagram/Facebook einzeln oder zusammen.
- Eine WordPress-Mediendatei für beide Ziele, unabhängige Captions.
- Facebook-Produktlink mit `utm_source=facebook`, `utm_medium=organic_social` und eigener Kampagne.
- Instagram ohne URLs, mit Aufforderung zum Shop-Link im Profil; Standard-Hashtags, falls keine eingegeben wurden.
- Vollständige Vorschau, SHA-256-Prüfwert und ausdrückliche Freigabe.
- Sofort oder Termin inklusive später heute; Europe/Berlin und Prüfung der Zeitumstellungen.
- Übersicht, Terminverschiebung mit erneuter Freigabe und Stornierung.
- Leichter minütlicher CLI-Runner: WordPress nur bei Arbeit oder stündlicher Kontrollprüfung; keine Abhängigkeit von Chat oder Website-Besuchern.
- Getrennter Plattformstatus, gespeicherte Meta-IDs, Beitragslinks, verständliche Fehler.
- Idempotente Entwurfserstellung, Datenbanksperre, dauerhafte Sendeabsicht und selektive Wiederholungen.
- Instagram Audio API: Suche, Trends ohne Suchbegriff, Titelwahl, verfügbare Vorhörlinks, getrennte Lautstärken.
- Instagram-Reel-Cover per JPEG oder Videozeitpunkt; `share_to_feed`.
- Optionale Instagram-Produktmarkierungen für JPEG-Einzelbilder nach zusätzlicher Konfiguration, Berechtigungs- und Eligibility-Prüfung. Reel-Produktmarkierungen gesperrt.
- Facebook Login für Meta bleibt getrennt von der ChatGPT-MCP-Anbindung. Die MCP-Anbindung verwendet ab 0.2.0 eine eigene private, rotierbare URL mit Zugriffsschlüssel.

## Was tatsächlich geprüft ist

Version 0.1.3 ergänzt eine direkt bedienbare geschützte Meta-Konfiguration in WordPress, MCP-Werkzeuge für Setup/Diagnose/Zielauswahl, den korrekten Remote-MCP-Origin-Betrieb und OAuth-Refresh-Discovery. Version 0.1.2 ergänzte Prüfungen der Termin-Hinweise, Fehlerbehandlung und tatsächlicher Dateisperren zwischen lokalen Prozessen. Im Leerlauf wurde anhand eines isolierten WordPress-Doubles geprüft, dass `wp-load.php` nicht ausgeführt wird. Details und Einschränkungen: `docs/TESTPROTOKOLL-0.1.2.txt`. Der produktive Cronjob muss noch vom Hosting eingerichtet und geprüft werden.

Version 0.1.1: 68 Funktionstests sowie 18 separate Bootstrap-Szenarien unter PHP 8.4.25 (PHP-WASM) bestanden. WordPress, Datenbank und Meta-Antworten werden dabei simuliert. Die Tests laden die echte Plugin-Startdatei einschließlich Autoloader. JavaScript syntaktisch geprüft. Ergebnisse: `docs/TESTPROTOKOLL-0.1.1.txt`.

Auf gewöhnlichen Shop-Aufrufen lädt das Plugin nur seine Startdatei, ohne Fachmodule, eigene Datenbank-/Meta-Aufrufe oder Frontend-Assets. REST-Anfragen registrieren die MCP-/OAuth-Routen; Verwaltung und Worker laden ihre Klassen bei Bedarf. Die tatsächliche Zeitersparnis hängt von Server, OPcache, Cachezustand und weiteren Plugins ab. Das Laden einer PHP-Klassendatei bedeutet nicht, dass alle darin definierten Funktionen ausgeführt werden.

Die Version 0.1.0 wurde auf Jesusschmuck.com installiert und aktiviert; ihre Verwaltungsoberfläche wurde im Browser geöffnet. Diese Live-Prüfung ist kein Meta-Veröffentlichungstest. Das ältere `docs/TESTPROTOKOLL.txt` dokumentiert den ursprünglichen lokalen Testlauf.
Die konkrete angehängte Testdatei wurde mit FFprobe geprüft: 22 Sekunden, 1080 × 1920, 30 fps, H.264 High, yuv420p, progressive, AAC-LC, 48 kHz, Stereo, rund 136 kbit/s Audio, 3.508.310 Bytes.

Live bereits geprüft: Facebook Login, gespeicherte Jesusschmuck-Zielkonten, lesende Rechteprüfung für Facebook/Instagram sowie Instagram-Audiosuche und Trends mit zurückgelieferten Vorschau-Links. Eine kommerzielle Titel-Lizenz ist damit nicht bestätigt.

**Noch nicht durchgeführt:** reale MySQL-Sperrkonkurrenz, abschließende Konto-/App-Review-Freischaltung außerhalb zulässiger App-Rollen, produktiver MCP-Client-Handshake, Server-Cronjob auf Jesusschmuck.com und echte Veröffentlichung. Die simulierten Prüfungen ersetzen diese Kontotests nicht.

## Grenzen dieser ersten Version

- Ein Facebook-Seiten-/Instagram-Kontopaar pro Installation. Mehrere Kampagnen möglich.
- Kein Facebook-Privatprofil, keine Stories, Karussells, Effekte, Sticker, Standort-/Personenmarkierungen oder Kollaboratoren.
- Instagram-Audio wird nicht auf Facebook übertragen. Facebook nutzt den in der Datei enthaltenen Ton. Die zwei Instagram-Lautstärken ändern die Datei nicht.
- Meta bietet keine Vorschau des fertig mit API-Audio gemischten Reels. Vorhörlinks können fehlen oder ablaufen.
- Ein gefundener Titel, ein Trend-Ranking oder `is_ads_eligible` sind keine pauschale kommerzielle Lizenz. Konkrete Rechtequelle muss bestätigt werden.
- Facebook-Cover-/Produktmarkierungsoptionen sind in dieser Version nicht implementiert. Keine Gleichsetzung mit Business Suite.
- Termin bedeutet Start der Verarbeitung beim nächsten Worker-Lauf (gewöhnlich bis etwa eine Minute später); Meta benötigt gegebenenfalls weitere Minuten. Kein sekundengenauer Veröffentlichungszeitpunkt.
- Nach Serverausfall werden überfällige freigegebene Jobs nachgeholt. Bei längerem Ausfall vorab stornieren, wenn der Inhalt zeitlich nicht mehr passt.
- Bei verlorener Antwort ohne sicher zuordenbare Meta-ID wird angehalten. Ein technisch garantiertes „genau einmal“ über zwei externe APIs ist nicht möglich; Sicherheit vor Doppelposts hat Vorrang. Es gibt keinen gefährlichen „trotzdem nochmal senden“-Knopf.
- Eine bereits gesendete Veröffentlichung lässt sich mit „Storno“ nicht zurückholen. Der tatsächliche Status kann weiter abgefragt werden.
- Inhaltlich ändern: bisherigen Job vor Verarbeitung stornieren und neuen Entwurf anlegen. Direktes Editieren eines freigegebenen Inhalts ist absichtlich nicht vorgesehen.
- Token können ablaufen oder widerrufen werden. Erneut verbinden; Terminfreigabe ist bei bekannter Token-Laufzeit über das Tokenende hinaus blockiert.
- Medien liegen in der normalen WordPress-Mediathek und müssen für Meta öffentlich über HTTPS erreichbar sein.

Weitere Details: [Einrichtung](docs/EINRICHTUNG.md), [Schnittstelle und Sicherheit](docs/TECHNIK.md), [API-Funktionsmatrix und Quellen](docs/META-API-STATUS.md), [Testprotokoll](docs/TESTPROTOKOLL.txt).


## Update 0.2.2
Facebook-Shoplink ist optional. Rand-Leerzeilen in Captions werden akzeptiert. Musik kann bei offenen Rechten vorgemerkt werden, die Veröffentlichung bleibt dann gesperrt. Für Facebook kann eine separate bereits vertonte MP4 gewählt werden (facebook_attachment_id, facebook_audio_rights). Dies mischt keine Musik automatisch und bestätigt keine Lizenz durch API-Verfügbarkeit.
