<?php
// Only an OS scheduler may invoke this file. No public HTTP worker endpoint.
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
$load = $argv[1] ?? '';
if (!$load || !is_file($load) || basename($load) !== 'wp-load.php') { fwrite(STDERR, "Usage: php runner.php /absolute/wordpress/wp-load.php\n"); exit(2); }
define('DOING_CRON', true);
require_once __DIR__ . '/includes/class-gate.php';
$gate = JSSocial_Gate::site($load);
$runner_lock = null;
try {
    $runner_lock = $gate->runner_lock();
    if (!$runner_lock) { exit(0); } // A running worker owns the heartbeat; do not hide a hung worker.
    if (!$gate->probe(time())) { exit(0); } // No WP, database, object cache or network access while idle.
    require $load;
    if (!class_exists('JSSocial_Worker')) { throw new RuntimeException('Jesusschmuck Social MCP ist nicht aktiv.'); }
    $result = JSSocial_Worker::tick();
    $gate->complete(time());
    if ($result['processed_jobs']) { echo wp_json_encode($result) . "\n"; }
} catch (Throwable $e) {
    try { $gate->failed(time()); } catch (Throwable $ignored) {}
    fwrite(STDERR, $e->getMessage() . "\n"); exit(1);
} finally { if (is_resource($runner_lock)) { fclose($runner_lock); } }
