# Schnittstelle und Sicherheitsmodell

## Speicherung

Separater Namespace `jssocial/v1`, Klassenpräfix `JSSocial_`, Optionen `jssocial_*`, Tabelle `<wp-prefix>jssocial_jobs`. Kein Hook in die Produktkatalog-Bridge. Keine WooCommerce-Abhängigkeit.

Ein Job enthält das unveränderliche Freigabemanifest mit Datei-Hash, URL, Konten-IDs, Texten, Einstellungen, UTC-Termin und Revision. `preview_hash` bindet Job-ID, Revision und Manifest. Dateien und Zielkonten werden vor Freigabe und vor Worker-Verarbeitung erneut geprüft. Terminänderung erhöht die Revision und setzt den Job auf Entwurf; alte Planung entfällt sofort.

Meta-Verbindungsdaten inklusive User- und Page-Tokens: AES-256-GCM, 12 zufällige IV-Bytes, 16-Byte-Tag, AAD `jssocial-v1`, eigener 32-Byte-Schlüssel aus geschützter Konfiguration. Keine Token-Ausgabe im Status. Unverschlüsseltes App-Secret ausschließlich in geschützter Konfiguration. PHP-/Server-/WordPress-Administratoren sind Teil der Vertrauensgrenze; die Datenbankverschlüsselung schützt nicht vor Vollzugriff auf Server und Konfiguration gemeinsam.

MCP-Zugriff ab 0.2.0: eigener privater 64-stelliger Zugriffsschlüssel in der vollständigen MCP-Adresse. Die Adresse wird ausschließlich im geschützten WordPress-Adminbereich angezeigt und kann dort rotiert werden. Meta/Facebook-OAuth bleibt davon vollständig getrennt. Eine MCP-Verbindung ist keine Beitragsfreigabe.

Öffentliche OAuth-Registrierung hat ein einfaches IP-basiertes Ratenlimit; für einen produktiven öffentlich erreichbaren Server zusätzlich vorhandene WAF/Rate-Limits passend konfigurieren. Discovery-Pfade müssen durch den Webserver erreichbar sein. App-/Client-Login und Redirect-Verhalten müssen vor produktivem Einsatz mit dem tatsächlichen Client geprüft werden.

## Warteschlange

- Betriebssystem-Cron jede Minute → CLI-Dateiprüfung → WordPress nur bei Arbeit oder stündlicher Kontrollprüfung → `JSSocial_Worker::tick`.
- MySQL/MariaDB `GET_LOCK` serialisiert Worker und Job-Mutationen. Vor API-POST wird der Besitz der Sperre erneut geprüft.
- Permanente Speicherung der Sendeabsicht erfolgt **vor** jedem veröffentlichenden API-Aufruf.
- Erfolgreiche Plattform bleibt erfolgreich. Wiederholung betrifft nur explizit sichere Fehler ohne unklare Sendeabsicht.
- Container-/Uploadfehler vor der Publikation dürfen wiederholt werden; es können dabei unpublizierte Container verbleiben.
- Unklare Veröffentlichung führt zu lesenden Statusabfragen mit Warteintervallen, danach gegebenenfalls zu manuellem Klärungsstatus.
- Keine Wiederholung von Veröffentlichung nach unklarer Antwort. Facebook-Foto ohne empfangene ID bleibt bei Unklarheit gesperrt.
- Instagram kann bei verlorener `media_publish`-Antwort die Veröffentlichung per Container bestätigen. Die Beitrags-ID und damit der Link können dann fehlen; das wird angezeigt. Kein unsicheres Zuordnen anhand gleicher Captions.
- Facebook-Finish-`success` bedeutet nur angenommen. Erst der Status `publishing_phase.publish_status=published` wird als veröffentlicht gemeldet.
- Ein separater `next_run`-Index verhindert, dass aufgeschobene Statusabfragen andere fällige Jobs blockieren.
- Bekannte Facebook-Reel-Grenze lokal konservativ auf 30 Veröffentlichungsversuche in 24 Stunden begrenzt. Andere Clients können weitere Quota verbrauchen; Meta bleibt maßgeblich. Instagram-Limits werden über die API-Antworten behandelt.

Kein verteilter Exactly-once-Commit zwischen WordPress und Meta. Auch ein Prozessabbruch zwischen gespeicherter Sendeabsicht und tatsächlichem Netzwerkaufruf kann deshalb eine manuelle Klärung verlangen. Das ist der bewusste Preis für den Schutz vor automatischen Doppelposts.

## MCP-Werkzeuge

| Werkzeug | Wirkung |
|---|---|
| `js_social_status` | Konfiguration, Ziele, Token-Ablauf und Workerstatus ohne Geheimnisse |
| `js_social_verify_connection` | Lesende Konten-/Rechteprüfung, optionale Tag-Eligibility/Kataloge |
| `js_social_upload_media` | MP4/JPEG bis 12 MB einmal übernehmen, Hash-Deduplizierung |
| `js_social_create_draft` | Unverbindlicher Entwurf, stabiler `request_key` für Wiederholungen |
| `js_social_preview` | Vollständige Vorschau und Prüfwert |
| `js_social_list` | Bis 100 Jobs, mit `before_id` weiterblättern |
| `js_social_approve` | Ausdrückliche Nutzerfreigabe an aktuelle Vorschau binden; verbindlich einplanen |
| `js_social_reschedule` | Alten Termin aufheben, neuen unverbindlichen Termin vorbereiten |
| `js_social_cancel` | Weitere Verarbeitung stoppen, keine Meta-Löschung |
| `js_social_retry` | Nur sicher fehlgeschlagene Plattform wiederholen |
| `js_social_reconcile` | Ausschließlich Veröffentlichungsstatus und Links nachlesen |
| `js_social_audio_search` | Audio-Suche, Trends oder einzelne Titelmetadaten |

Tool-Schemas sind durch `tools/list` verfügbar. Unbekannte Felder, falsche Typen, zusätzliche Plattformen, unzulässige IDs und ungültige Mengen werden abgelehnt. Toolfehler werden als MCP-Resultat mit `isError=true` geliefert. Notifications erhalten HTTP 202. GET auf der privaten MCP-Adresse liefert einen kompakten Status; POST transportiert JSON-RPC. Protokollversionen: 2024-11-05, 2025-03-26, 2025-06-18. Ab 0.2.0 schützt der private URL-Token die gesamte MCP-Route; die Tool-Schemas enthalten deshalb keine zweite OAuth-Sicherheitsdeklaration. Leere JSON-Schema-`required`-Arrays werden nicht ausgegeben, damit strikte MCP-Clients die Werkzeugliste akzeptieren.

## Freigabe aus dem Chat

1. Medium und Entwurf vorbereiten.
2. Vollständige `js_social_preview`-Ausgabe nutzerverständlich zeigen: Datei, konkrete Konten, vollständige Captions, lokale Zeit inklusive Offset, Cover, Audio und Unterschiede zwischen Plattformen.
3. Nutzer muss den dargestellten Inhalt ausdrücklich zur sofortigen oder geplanten Veröffentlichung freigeben. Gestaltung allein reicht nicht.
4. `js_social_approve` nur mit der aktuellen `preview_hash`, der zurückgegebenen exakten `confirmation` und der **tatsächlich erteilten** Nutzerfreigabe in `approval_evidence` aufrufen.
5. Die Terminfreigabe berechtigt den Worker zur späteren automatischen Ausführung. Keine zweite Nachfrage zum Ausführungszeitpunkt.

Die Serverprüfung verhindert veraltete/manipulierte Manifeste und unbeabsichtigte Standardfreigaben. Ein beliebiger voll autorisierter MCP-Client könnte eine Nutzerzustimmung behaupten; deren Wahrheit ist eine zusätzliche Pflicht des Clients/Assistenten. Wer die Freigabe unabhängig davon ausschließlich selbst steuern möchte, benutzt den WordPress-Freigabeknopf und lässt den Client nur Entwürfe vorbereiten. Granulare MCP-Lese-/Schreibscopes sind in 0.1.0 noch nicht getrennt.

## Medien

WordPress-Medienbibliothek für größere Dateien; MCP-Upload maximal 12 MB. Nur lokale Dateien innerhalb des Upload-Verzeichnisses werden verarbeitet. Keine beliebige Remote-URL-Importfunktion, keine dynamischen Graph-Hosts. Rupload-URL wird auf festen Meta-Host und Video-Upload-Pfad begrenzt. Redirects bei serverseitigen Meta-Requests sind ausgeschaltet.

GetID3/WordPress prüft im Plugin Dateityp, Länge und Dimensionen. Vollständige Codec-/Bitrate-/GOP-Validierung beliebiger späterer Dateien erfolgt nicht lokal; Meta kann sie ablehnen. Die im Auftrag bereitgestellte Testdatei wurde zusätzlich separat mit FFprobe geprüft. Mediendateien sollten nach Freigabe nicht ersetzt oder gelöscht werden.

## Testausführung

`tests/contract.php` enthält den portablen PHP-Testlauf mit WordPress-, Datenbank- und API-Attrappen. Er wird niemals von WordPress geladen und verlangt einen expliziten Bootstrap. In einer **separaten lokalen** PHP-Umgebung ausführen:

```bash
php -r "define('JSSOCIAL_TEST_BOOTSTRAP', true); require 'tests/contract.php';"
```

Benötigt PHP 8.1+, OpenSSL, mbstring und Schreib-/Leserechte auf die beigefügten Test-Fixtures. Kein realer HTTP-Aufruf, keine Anmeldung, keine Veröffentlichung. Der beim Bau ausgeführte Lauf nutzte PHP 8.3.32 in PHP-WASM. Die Tests belegen Logik, keine reale MySQL-/WordPress-Integration.


## Laden bei Bedarf (0.1.1)

Die Plugin-Startdatei registriert einen Autoloader mit einer festen Klassenzuordnung sowie kleine Hook-Callbacks. Damit löst auch WordPress' Prüfung eines Admin-Menü-Callbacks noch keine Modul-Ladung aus. `JSSocial_Meta_Error` und `JSSocial_Meta` verweisen bewusst auf dieselbe Datei.

- Normaler Shop-Aufruf: keine der acht Fachdateien, keine plugin-eigenen Optionenabfragen/HTTP-Aufrufe/Assets; kein `parse_request`-Callback.
- Übrige Verwaltungsseiten: nur Menüregistrierung; Social-Assets ausschließlich auf der Social-Seite.
- REST-Initialisierung: MCP-/OAuth-Routen werden unabhängig von Permalinkform und internem `rest_do_request()` registriert. Die übrigen Module laden erst bei Verwendung.
- OAuth-Discovery: Callback nur bei den beiden `.well-known`-Präfixen. Die exakte URL-Prüfung erfolgt weiterhin im OAuth-Modul; WordPress-Unterverzeichnisse bleiben unterstützt.
- WP-CLI und eigenständiger Runner: Worker lädt beim Aufruf; `class_exists()` im Runner nutzt den Autoloader. Kein Start durch Websitebesucher.

18 Bootstrap-Szenarien laufen jeweils in einem frischen lokalen PHP-Prozess:

```bash
for scenario in front front-logged-in admin assets rest action oauth authorize consent cli runner error-class activation lookalike discovery discovery-subdir resource resource-subdir; do
  php -r "define('JSSOCIAL_TEST_BOOTSTRAP', true); require 'tests/bootstrap.php';" -- "$scenario"
done
```

Der Lauf für 0.1.1 nutzte PHP 8.4.25 in PHP-WASM. Er prüft Hook-Dispatch, nachgeladenen Code und die bestehenden Schutzprüfungen mit WordPress-Attrappen. Eine Server-Zeitmessung oder ein echter Meta-Kontotest wird damit nicht ersetzt. Kein Schemawechsel und keine Änderung gespeicherter Verbindungen, Entwürfe, Freigaben oder Cron-Einrichtung durch dieses Update.


## Leichter Runner (0.1.2)

`class-gate.php` hat keine WordPress-Abhängigkeit. Die Site-Identität bindet Pluginpfad und kanonischen `wp-load.php`-Pfad. Das Laufzeitverzeichnis liegt außerhalb des beim Update ersetzten Pluginordners. Jede Datei enthält nur Steuerdaten, keine Tokens oder Captions. `state.php` beginnt mit einem PHP-Abbruch; JSON wird ausschließlich als Daten gelesen und durch Schema-/Typprüfung sowie SHA-256-Prüfsumme validiert. Die Prüfsumme erkennt Beschädigungen, sie ist kein Schutz gegen einen Serveradministrator.

Die stabile `state.lock` schützt kurze Lese-/Schreibabschnitte. Änderungen werden in eine temporäre Datei geschrieben, mit fflush/fsync gesichert und atomar umbenannt. `runner.lock` bleibt während des gesamten CLI-Aufrufs einschließlich WordPress-Start gehalten. Ein zweiter Prozess endet ohne Bootstrap und ohne falsches Lebenszeichen. Alle Dateisperren sind lokale advisory locks; ein einzelner Webserver mit lokalem Dateisystem und identischem Website-/Cron-Systembenutzer ist vorausgesetzt. Verteiltes Hosting ist damit nicht zugesagt.

Jede Warteschlangenmutation markiert den Hinweis **vor** dem ersten Datenbankschreibzugriff eines gesperrten Abschnitts dauerhaft als ungültig. Gelingt das nicht, wird die Mutation abgebrochen. Unter derselben MySQL-Sperre ermittelt der Store nach Abschluss einmal das Minimum von `next_run` für `queued`/`running` und schreibt es in den Hinweis. Ein Abbruch zwischen Invalidierung, DB-Commit und Erneuerung lässt einen ungültigen Hinweis zurück und erzwingt die nächste vollständige Prüfung. Ein fehlgeschlagenes Erneuern wird protokolliert. Auch nach leerem Worker-Lauf wird synchronisiert.

Das CLI-Lebenszeichen zählt auch erfolgreiche leichte Minutenprüfungen. Vollständiger Lauf und nächster Arbeitstermin werden separat angezeigt. Ein fehlgeschlagener vollständiger Lauf wird nicht als Erfolg gezählt. Ein hängender Worker kann sein Lebenszeichen nicht durch konkurrierende Prozesse auffrischen. Rückwärts laufende Systemzeit, fehlende/beschädigte Daten oder ein nicht abgeschlossener Lauf erzwingen einen vollständigen Neustart. Abschlussmeldungen verändern niemals den Queue-Hinweis, den ein paralleler Webaufruf inzwischen aktualisiert haben kann.

Zusätzliche lokale Prüfungen:

```bash
php -r "define('JSSOCIAL_TEST_BOOTSTRAP', true); require 'tests/gate.php';"
python3 tests/runner-integration.py /pfad/zur/php-cli
```

Der Integrationstest nutzt ein isoliertes `wp-load.php`-Double, zählt tatsächliche Bootstrap-Aufrufe und prüft Dateisperren zwischen getrennten Betriebssystemprozessen. Das ist keine Live-MySQL-/Hosting-Prüfung. Prüfumgebung und Ergebnisse stehen in `TESTPROTOKOLL-0.1.2.txt`.
