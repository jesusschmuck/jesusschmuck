# Meta-API-Prüfung – 19.09.2026

Die offizielle Dokumentation wurde live abgerufen. Der Web-Suchzugriff lieferte teils Fehler/429; die unten genannten entscheidenden Referenzen konnten direkt per HTTPS geladen und ausgewertet werden. Dies ist eine Prüfung der dokumentierten API-Verträge, keine Bestätigung für die reale App bzw. die realen Konten.

| Funktion | Offiziell dokumentierter Weg | Umsetzung 0.1.0 / Kontostatus |
|---|---|---|
| Instagram Reel | `/{ig-id}/media` mit `media_type=REELS`, Status prüfen, `media_publish` | Implementiert; User-Token über Facebook Login entsprechend spezifischer Media-/Audio-Referenz. Live offen. |
| Facebook Reel | `/{page-id}/video_reels`, Start, Upload zu `rupload.facebook.com`, Finish, Status | Implementiert für Seiten mit Page-Token; keine privaten Profile. Live offen. |
| Einzelbild | Instagram JPEG-Container / Facebook `/{page-id}/photos` | Implementiert. Instagram maximal 8 MB, Seitenverhältnis 4:5–1,91:1. Live offen. |
| Eigener Termin | Eigener serverseitiger Versand zum gespeicherten UTC-Zeitpunkt | Implementiert, Europe/Berlin-Konvertierung getestet. Tatsächlicher Server-Cronjob noch einzurichten. |
| Facebook-native Planung | Guide nennt mindestens 10 Minuten Vorlauf und höchstens 29 Tage | Bewusst eigener Worker für beide Plattformen; kein `SCHEDULED` an Meta. Damit auch spätere Uhrzeit heute und kurze Vorlaufzeit möglich. |
| Audio-Suche / Trends | `GET /ig_audio`, `audio_type`, `user_id`, optionale `search_query` | Implementiert. Ohne Suchbegriff kommen laut Audio-Referenz Trends. Kontoverfügbarkeit offen. |
| Audio-Metadaten | `GET /{audio-id}?user_id=...` | Vor Titelübernahme nochmals abgefragt. Live offen. |
| Getrennte Lautstärken | `audio_configuration.audio_volume` und `video_volume`, jeweils 0–100 | Implementiert nur für Instagram. Datei bleibt unverändert. |
| Vorhören | Temporäre `download_url`, alternativ `on_platform_audio_preview_link` | Soweit geliefert in Oberfläche. Fehlende Vorschau sichtbar. Kein Mix-Preview: laut Audio-API nicht unterstützt. |
| Musikrechte | API-Katalog nur für Drittanbieter freigegebene Auswahl; `is_ads_eligible` kann fehlen | Keine pauschale kommerzielle Zusage. Nutzer muss konkrete Rechtequelle bestätigen. Weder Trend noch Ads-Flag ist universelle Nutzungslizenz. |
| Sound Collection | Audio-Doku beschreibt Ersatzmusik für Ads: `product=ADS`, `purpose=AUDIO_COPYRIGHT_REPLACEMENT` | Separater eingeschränkter Zugang, `ads_management`, bestehendes Reel mit Copyrightproblem. Nicht als allgemeine organische Musiksuche implementiert. Offizieller Sound-Collection-Link in UI. |
| Facebook-Musik aus Instagram Audio API | Instagram-Doku gilt für Instagram mit Facebook Login | Keine automatische Übertragung. Facebook-Reels-Guide bestätigt diesen Instagram-Parameter nicht; v0.1 sendet ihn nicht an Facebook. Nur Originalton der Datei. |
| Instagram-Cover | `cover_url` oder `thumb_offset`; Cover-URL hat Vorrang | Implementiert für Reels. JPEG erforderlich. Live offen. |
| Instagram-Feed | `share_to_feed` | Implementiert; keine Garantie der tatsächlichen algorithmischen Feed-Ausspielung. |
| Instagram-Produktmarkierung | Spezifischer Product-Tagging-Guide und `product_tags`, Eligibility-/Katalog-Endpunkte | Optional für JPEG-Einzelbilder, höchstens fünf eindeutige Tags, zusätzliche Rechte und positive Eligibility nötig. Reel-Tags in v0.1 gesperrt. |
| Facebook-Cover / Produktmarkierungen | Eigenständige API-/Kontoprüfung erforderlich; keine Übernahme von IG-Parametern | Nicht implementiert. Business-Suite-Verfügbarkeit ist kein Beleg für denselben API-Vertrag. |
| Filter, Sticker, native Audio-Editoren, Trial Reels, Partnerlabels, Collaborators | Unterschiedliche APIs / native Funktionen / weitere Rechte | Nicht Teil 0.1.0. Keine pauschale Übernahme sämtlicher Business-Suite-Einstellungen. |

## Dokumentationsunterschiede

Die allgemeinen Publishing-Seiten und spezielle Referenzen sind nicht vollständig konsistent: Die allgemeine Übersicht beschränkt Shopping-Tags, während der spezielle Facebook-Login-Product-Tagging-Guide entsprechende Wege beschreibt. Die Media-Referenz enthält noch einen älteren Hinweis auf Originalaudio, während die neue Audio-API explizit Musiksuche und `audio_configuration` dokumentiert. Für Audio wurde die konkrete neue Referenz verwendet. Produktmarkierungen sind konservativ separat abschaltbar, kontogeprüft und auf Einzelbilder begrenzt. Die tatsächliche Freischaltung wird nicht aus Dokumentation abgeleitet.

## Offizielle Quellen

- [Instagram Audio API](https://developers.facebook.com/documentation/instagram-platform/content-publishing/audio-api.md) – Suche, Trends, Metadata, Previews, Volumes, Sound-Collection-Ads-Ersatz und Facebook-Login-Anforderung. Direkt gelesen.
- [Instagram IG User Media](https://developers.facebook.com/documentation/instagram-platform/instagram-graph-api/reference/ig-user/media.md) – Parameter, Medienvorgaben, Cover und Berechtigungen. Direkt gelesen; Referenz nennt v25.0.
- [Instagram Content Publishing](https://developers.facebook.com/documentation/instagram-platform/content-publishing.md) – Publishing-Schritte, Rate Limits, öffentliche Medien und zusätzliche Optionen. Direkt gelesen.
- [Instagram Container](https://developers.facebook.com/documentation/instagram-platform/instagram-graph-api/reference/ig-container.md) – `FINISHED`, `PUBLISHED`, `ERROR`, `EXPIRED`. Direkt gelesen.
- [Facebook Reels Publishing](https://developers.facebook.com/docs/video-api/guides/reels-publishing/) – Start/Upload/Finish/Status, Berechtigungen, native Planungsgrenzen. Direkt gelesen.
- [Facebook Page Photos](https://developers.facebook.com/docs/graph-api/reference/page/photos/) – `url`, `caption`, `published`, Rückgabe `id`/`post_id`. HTML-Referenz direkt gelesen.
- [Facebook Photo Reference](https://developers.facebook.com/docs/graph-api/reference/photo/) – `link` und Foto-Metadaten. HTML-Referenz direkt gelesen.
- [Instagram Product Tagging](https://developers.facebook.com/documentation/instagram-platform/instagram-api-with-facebook-login/product-tagging.md) – Eligibility, Katalog, spezielle Rechte und Kontoanforderungen. Direkt gelesen.
- [Instagram Available Catalogs](https://developers.facebook.com/documentation/instagram-platform/instagram-graph-api/reference/ig-user/available_catalogs.md) – verfügbare Kataloge. Direkt gelesen.
- [Facebook Login Manual Flow](https://developers.facebook.com/documentation/facebook-login/guides/advanced/manual-flow.md) – Facebook-OAuth-Codefluss. Direkt gelesen.
- [Meta Sound Collection](https://www.facebook.com/sound/collection/) – Katalog für manuelle kontobezogene Prüfung. Keine Titelrechte im Benutzerkonto geprüft.
- [MCP Transport Specification 2025-06-18](https://modelcontextprotocol.io/specification/2025-06-18/basic/transports) – POST/JSON und stateless Streamable HTTP.

## Bereits vorhandene Integration

Das vorhandene Statuswerkzeug meldete **Meta for WooCommerce 3.7.6: installiert und aktiv**. Das ist kein Nachweis, dass unsere neue App Seiten-/Instagram-Publishing- oder Audio-Rechte besitzt. Vorhandene Tokens wurden weder ausgelesen noch übernommen. An der Produktkatalog-Bridge wurde nichts geändert.
