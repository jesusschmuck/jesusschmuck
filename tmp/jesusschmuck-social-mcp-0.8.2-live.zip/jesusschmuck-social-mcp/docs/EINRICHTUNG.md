# Einrichtung – Schritt für Schritt

## 1. WordPress

ZIP installieren und aktivieren. Die vorhandene Produktkatalog-Bridge bleibt unabhängig aktiv. Menü: **Jesusschmuck Social**.

Voraussetzungen: WordPress 6.4+, PHP 8.1+ mit OpenSSL und üblicher WordPress-Medienunterstützung, MySQL/MariaDB mit `GET_LOCK`/`RELEASE_LOCK`, HTTPS, öffentliche HTTPS-Uploads, funktionierende WordPress-REST-API. PHP-CLI muss dieselbe Installation und PHP-Konfiguration erreichen können. Die Seite darf Meta beim Abruf der gewählten Medien nicht durch Basic Auth, Hotlink-Schutz oder Bot-Regeln sperren.

Die Datenbanktabelle `<prefix>jssocial_jobs` wird neu angelegt. Keine Änderung an Produkten, WooCommerce, Theme, bestehender Bridge, globalem WP-Cron oder bestehenden Cronjobs.

## 2. Eigene Meta-App einrichten

Eine vorhandene WooCommerce-/Katalog-Verbindung wird nicht übernommen. Für die neue App müssen die Rechte separat erteilt werden.

1. Im [Meta-App-Dashboard](https://developers.facebook.com/apps/) eine geeignete eigene Business-App einrichten oder eine geeignete **eigene** App wählen. Nicht die fremde Hersteller-App von Meta for WooCommerce verwenden.
2. Facebook Login / Facebook Login for Business und Instagram API **mit Facebook Login** konfigurieren. Nicht Instagram Login wählen: die geprüfte Audio API verlangt Facebook Login.
3. Als Website-Domain die tatsächliche Domain verwenden. App-Einstellungen zu Kontakt, Datenschutz und Datenlöschung entsprechend der von Meta verlangten App-Konfiguration hinterlegen. In Entwicklungsmodus müssen verwendete Test-/Administratorkonten passende App-Rollen haben.
4. Im WordPress-Menü „Verbindungen“ die angezeigte **Facebook-Redirect-URI** unverändert in Metas erlaubte OAuth-Redirect-URIs übernehmen. Bei üblicher Installation:

   `https://www.jesusschmuck.com/wp-admin/admin-post.php?action=jssocial_oauth`

5. Bei Facebook Login for Business eine Konfiguration für einen **User access token** anlegen. Die optionale Konfigurations-ID unten als `JSSOCIAL_FB_CONFIG_ID` setzen. Die Audio API benötigt einen User-Token; für Facebook-Seiten ermittelt das Plugin daraus den Page-Token.
6. App-ID und App-Secret nur in der geschützten Serverkonfiguration hinterlegen. Keine Tokens, App-Secrets oder Schlüssel in den Chat, in Screenshots, in Tickets oder in öffentliche URLs kopieren.

Basisrechte:

| Recht | Verwendung |
|---|---|
| `pages_show_list` | Seiten auswählen |
| `pages_read_engagement` | Seiten-/Medienstatus und Instagram-Voraussetzungen |
| `pages_manage_posts` | Auf der Facebook-Seite veröffentlichen |
| `instagram_basic` | Verbundenes Instagram-Profikonto und Audio API |
| `instagram_content_publish` | Instagram veröffentlichen und Audio API |

Wenn die Seitenrolle über Business Manager erteilt wird, dokumentiert Meta zusätzliche Anforderungen. Bei Bedarf den Business-Rollenmodus unter **Jesusschmuck Social → Verbindungen** aktivieren und erneut verbinden; das Plugin fordert dann zusätzlich `ads_read` an. Es nimmt nicht pauschal Werbeverwaltungsrechte.

Für Zugriff außerhalb zulässiger App-Rollen können App Review, Advanced Access und Business Verification nötig sein. Ob eure konkrete App dies benötigt bzw. bereits erfüllt, lässt sich erst im App-Dashboard und über die verbundenen Konten prüfen. Meta-Seitenfreigaben (PPA), Zwei-Faktor-Anforderungen und die Seitenaufgabe `CREATE_CONTENT` oder `MANAGE` müssen erfüllt sein.

Instagram muss Business oder Creator sein und mit der gewählten Facebook-Seite verbunden sein. Optionale Produktmarkierungen brauchen ein geeignetes Business-Konto und Shop-Freischaltung; Creator ist dafür nicht zugesagt.

## 3. Geschützte Meta-Konfiguration

Bevorzugter Weg ab Version 0.1.3: **Jesusschmuck Social → Verbindungen** öffnen und dort Meta App-ID und Meta App-Secret speichern. Das App-Secret wird mit AES-256-GCM verschlüsselt; der Schlüssel wird aus den vorhandenen WordPress-Salts abgeleitet. Das Secret muss nicht in einen Chat kopiert werden.

Optional bleiben bestehende `wp-config.php`-Konstanten unterstützt und haben Vorrang, zum Beispiel:

```php
define('JSSOCIAL_APP_ID', 'EIGENE_META_APP_ID');
define('JSSOCIAL_APP_SECRET', 'EIGENES_META_APP_SECRET');
// Optional weiterhin eigener fester Verschlüsselungsschlüssel:
// define('JSSOCIAL_ENCRYPTION_KEY', '64_HEX_ZEICHEN');
```

Graph-Version, Facebook-Login-Config-ID, Business-Rollenmodus und Produktmarkierungen können in WordPress gespeichert und nach erfolgreicher privater MCP-Verbindung auch kontrolliert über MCP verwaltet werden. App-Secret wird absichtlich **nicht** als MCP-Argument akzeptiert.

`wp-config.php` über Hosting-Dateimanager/SFTP/SSH bearbeiten und nicht öffentlich bereitstellen. Kein Geheimnis wird in Status-/MCP-Antworten ausgegeben. HTTP-Debug-/Proxy-/Security-Logs anderer Software können OAuth-Daten erfassen; sensible OAuth-Endpunkte dort nicht mit vollständigen Parametern protokollieren.

## 4. Facebook Login und Zielkonto

In **Jesusschmuck Social → Verbindungen**:

1. „Mit Facebook verbinden / erneuern“ klicken.
2. In Metas Dialog selbst anmelden und die richtige Seite sowie das verbundene Instagram-Konto zulassen.
3. Zurück in WordPress die **konkrete Zielseite** aus dem Auswahlfeld speichern. Es wird keine Seite automatisch gewählt.
4. „Konten und Berechtigungen prüfen“ klicken. Fehlende Rechte werden angezeigt.
5. Eine erfolgreiche lesende Kontoprüfung bestätigt Voraussetzungen. Sie ersetzt den ersten freigegebenen Publikationstest nicht.

Der Shop-Katalog kann bereits aktiv sein, ohne dass diese eigene App Publishing-Rechte hat. Bei Fehler 190 erneut verbinden; bei 10/200 Rechte, App-Review und Seitenrolle prüfen.

## 5. Leichten Server-Runner jede Minute starten

Erforderlich, damit Termine auch ohne Besucher und ohne offenen Chat ausgeführt werden. Der eigene Worker verwendet **keinen besucherabhängigen WP-Cron**.

Beispiel für eine Cronzeile; PHP-Binary, WordPress-Pfad, Webserver-Benutzer und Logpfad lokal anpassen:

```cron
* * * * * /usr/bin/php /var/www/jesusschmuck/wp-content/plugins/jesusschmuck-social-mcp/runner.php /var/www/jesusschmuck/wp-load.php >> /var/log/jssocial-worker.log 2>&1
```

Alternative mit höherer Grundlast, falls WP-CLI eingerichtet ist:

```cron
* * * * * /usr/local/bin/wp --path=/var/www/jesusschmuck jssocial tick >> /var/log/jssocial-worker.log 2>&1
```

**Genau eine der Varianten einrichten**, nicht beide. Mit dem geeigneten Website-Benutzer ausführen, nicht pauschal als root. Logdatei außerhalb des öffentlich erreichbaren Verzeichnisses ablegen und rotieren. Die Oberfläche zeigt die tatsächlich ermittelten WordPress-Pfade an. Für Jesusschmuck.com wurde `/var/customers/webs/jesusschmuck/` als WordPress-Verzeichnis festgestellt. Den passenden PHP-CLI-Pfad und den Systembenutzer muss das Hosting bestätigen; FTP-/Froxlor-Zugang bestätigt keinen SSH-Zugang.

Seit 0.1.2 prüft `runner.php` im Leerlauf ausschließlich eine kleine lokale Statusdatei und aktualisiert das CLI-Lebenszeichen. WordPress, Datenbank, Objektcache und Meta werden dabei nicht geladen bzw. angesprochen. WordPress startet bei fälliger Arbeit, fehlendem/ungültigem Termin-Hinweis oder zur stündlichen Kontrollprüfung. Neue Freigaben, Verschiebungen, Stornos und Warteintervalle aktualisieren den Hinweis sofort. `wp jssocial tick` ist kompatibel, lädt aber WordPress bei jedem Aufruf.

Der Worker erlaubt nur CLI. Es gibt keine öffentlich aufrufbare Cron-URL mit Zugangsschlüssel. Eine Dateisperre verhindert parallele WordPress-Starts; die bestehende Datenbanksperre serialisiert weiterhin Worker und Änderungen an der Warteschlange. Maximal acht fällige Jobs pro Lauf, mit begrenztem Laufzeitbudget; Upload/Verarbeitung setzt in Folgeläufen fort.

Der Runner braucht Schreibrechte unter `wp-content/jssocial-runtime-…`. Der Ordner wird mit Modus 0700, die Dateien mit 0600 angelegt. Website und Cronjob müssen deshalb unter demselben Systembenutzer laufen. Der Zustand enthält ausschließlich Zeitwerte und Steuerinformationen, keine Zugangsdaten oder Inhalte. Bei Dateirechtfehlern meldet der Cronjob einen Fehler; neue Warteschlangenänderungen werden vor der Datenbankänderung angehalten. Fehlerprotokoll prüfen, nicht die Dateirechte pauschal für alle Benutzer öffnen.

Nach mindestens zwei regelmäßig gestarteten erfolgreichen Timer-Prüfungen (20–150 Sekunden Abstand, letzter Lauf höchstens 180 Sekunden alt) muss die Oberfläche „Worker läuft regelmäßig“ anzeigen. Bis dahin ist jede verbindliche Freigabe gesperrt. Nicht nur einmal manuell starten und dann den Cronjob vergessen.

Server-Uptime und Cronjob überwachen. Nach Ausfall werden Jobs nachgeholt. Externe Alarmierung/Monitoring ist in Version 0.1.0 nicht enthalten.

## 6. Separate MCP-Verbindung hinzufügen

Endpunkt aus dem WordPress-Menü kopieren, üblicherweise:

`https://www.jesusschmuck.com/wp-json/jssocial/v1/mcp`

Eigene neue MCP-Verbindung erstellen; vorhandene Produktkatalog-Verbindung unverändert lassen. Im WordPress-Admin unter Jesusschmuck Social → Verbindungen die **private MCP-Adresse** kopieren. In ChatGPT unter Einstellungen → Plugins → MCPs → Server hinzufügen eine separate Verbindung „Jesusschmuck Social“ anlegen und exakt diese vollständige private Adresse eintragen. Die Adresse enthält den Zugriffsschlüssel und darf nicht im Chat geteilt werden. Transport: Streamable HTTP / POST JSON-RPC.

Beim Verbindungsdialog meldest du dich als WordPress-Administrator an und bestätigst den angezeigten Client samt Rückleitungsadresse. Diese Zustimmung erlaubt die Verbindung, **noch keinen Beitrag**.

Wichtige Discovery-Pfade bei üblicher WordPress-Installation:

- `/.well-known/oauth-protected-resource/wp-json/jssocial/v1/mcp`
- `/.well-known/oauth-authorization-server/wp-json/jssocial/v1/oauth`

Die Webserver-Konfiguration muss diese Pfade an WordPress weiterreichen. Manche Server reservieren `/.well-known/` für andere Zwecke. Falls der Client die Anmeldung nicht findet: diese zwei Pfade und die REST-API prüfen; die Verbindung ist mit dem konkreten Client noch nicht live getestet. Andere Well-known-Pfade verändert das Plugin nicht.

Für Clients mit eigener Header-Konfiguration ist alternativ ein separater `JSSOCIAL_MCP_KEY` (zufällig, 64 Hex-Zeichen) in `wp-config.php` möglich. Im Client denselben Schlüssel als geschützten `Authorization: Bearer …`-Header hinterlegen. Keine Schlüssel in Querystrings, öffentliche URLs oder Chatnachrichten einbauen. Beispiel ohne geheime Werte:

```json
{
  "mcpServers": {
    "jesusschmuck-social": {
      "url": "https://www.jesusschmuck.com/wp-json/jssocial/v1/mcp",
      "headers": { "Authorization": "Bearer AUS_GESCHUETZTER_KONFIGURATION" }
    }
  }
}
```

Die private MCP-Adresse kann im WordPress-Admin über „Private Adresse erneuern“ rotiert werden. Dadurch wird nur die bisherige ChatGPT-MCP-Adresse ungültig; Meta-Tokens, Zielkonten, Jobs und aktive Termine werden nicht gelöscht. Anschließend die Social-Verbindung in ChatGPT mit der neuen Adresse aktualisieren. Für einen vollständigen Versandstopp offene Jobs stornieren bzw. den System-Cronjob pausieren.

## 7. Test-Reel vorbereiten – noch keine Veröffentlichung

Die in diesem Auftrag vorliegende Datei ist geprüft, aber **nur gestalterisch freigegeben**:

`Schmuck_der_Woche_Jesus_Armband_Schwarz_Gold(1).mp4`

Einmal über die Medienauswahl des Plugins hochladen oder über `js_social_upload_media` übernehmen. Danach dieselbe Medien-ID für beide Plattformen verwenden. Upload ist keine Social-Veröffentlichung, die WordPress-Datei liegt jedoch öffentlich in der Mediathek.

Beide Captions formulieren, tatsächlichen Produktlink für Facebook eintragen, Zielkonten prüfen, Termin wählen. Keine unbestätigte Produkt-URL erfinden. Dann **Entwurf speichern**. Erst wenn du die vollständige Vorschau ausdrücklich freigibst, darf `js_social_approve` oder der Freigabeknopf verwendet werden.

Erster Live-Test erst nach deiner gesonderten Freigabe. Instagram und Facebook getrennt beobachten: ID, endgültiger Status und Link. Bei Teil-Erfolg nur die fehlgeschlagene Plattform erneut versuchen. Bei „unklar“ zuerst Meta-Status und Konto prüfen; nicht einen neuen identischen Job anlegen, um die Sperre zu umgehen.

## 8. Audio und Produktmarkierungen optional prüfen

**Audio:** Im Reiter „Instagram Audio“ eine Suche bzw. leere Suche für Trends ausführen. Erst ein erfolgreicher kontoauthentifizierter Abruf belegt die Verfügbarkeit. Titel kann ausgewählt und – soweit geliefert – separat vorgehört werden. Fehlendes `is_ads_eligible` bleibt „nicht angegeben“. Die Eignung für Ads ist nicht gleich einer universellen kommerziellen Nutzungslizenz. Musikrechte für den konkreten organischen Werbebeitrag prüfen und Rechtequelle im Entwurf dokumentieren. Ohne Musikauswahl funktioniert derselbe Planungsablauf.

**Sound Collection:** Über den verlinkten offiziellen Katalog suchen. Die dokumentierte API für Sound-Collection-Ersatzmusik bei Reels-Ads ist eingeschränkt verfügbar, benötigt `ads_management` und ein bestehendes Reel mit erkanntem Copyrightproblem. Sie ist kein allgemeiner freier Suchkatalog für beliebige organische Posts und nicht in dieser Version integriert. Ein legitim verwendbarer Sound-Collection-Titel kann alternativ vorab in eine Videodatei eingearbeitet werden; das Plugin mischt Dateien nicht lokal.

**Produktmarkierungen:** Erst bei Bedarf Produktmarkierungen unter **Jesusschmuck Social → Verbindungen** aktivieren und erneut Facebook Login ausführen. Es werden zusätzlich `catalog_management` und `instagram_shopping_tag_products` angefordert. „Konten prüfen“ liest Eligibility und verfügbare Kataloge. Version 0.1.0 unterstützt Tags nur für JPEG-Einzelbilder, über explizite Meta-Katalog-Produkt-IDs; keine automatische WooCommerce-ID-Zuordnung und keine Suche/Produktauswahl per Shop-UI. Reel-Tags bleiben gesperrt. Facebook-Tags werden nicht übertragen.

## 9. Updates und Entfernung

Datenbank und `wp-config.php` einschließlich Verschlüsselungsschlüssel vor Änderungen sichern. Deaktivierung stoppt die Veröffentlichung, weil die Worker-Klasse dann nicht geladen wird; beim nächsten vollständigen Lauf meldet der Cronjob den Fehler. Den Cronjob bei Deaktivierung ebenfalls pausieren. Bei Reaktivierung können offene freigegebene Termine nachgeholt werden. Vor einer längeren Pause betroffene Beiträge stornieren.

Deinstallation entfernt nicht automatisch Job-Verlauf oder verschlüsselte Verbindungsdaten. Vor endgültigem Entfernen gegebenenfalls „Meta-Verbindung entfernen“, MCP-Zugänge widerrufen, Cronjob entfernen und die appbezogenen Konstanten sicher löschen. Historie erst nach eigener Sicherung bewusst löschen.
