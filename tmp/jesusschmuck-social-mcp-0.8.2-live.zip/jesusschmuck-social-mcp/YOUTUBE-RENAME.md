# Playlist-Titel ändern (0.8.1)

`js_social_youtube_prepare` akzeptiert `operation: rename_playlist` mit `request_key`, `playlist_id` und `title`. Die Vorschau enthält den bisherigen Titel, die vollständige Beschreibung, Sprache, Sichtbarkeit und ETag. Andere Änderungsfelder werden abgelehnt.

Nach ausdrücklicher Freigabe der Vorschau führt `js_social_youtube_execute` die Umbenennung aus. Kanal, Client und aktueller Playlist-Stand werden erneut geprüft. Ein bedingtes PUT aktualisiert ausschließlich snippet und bewahrt Beschreibung und Standardsprache. Status, lokale Übersetzungen, Playlist-ID und Inhalte werden nicht geschrieben. Eine anschließende Leseprüfung bestätigt Titel, Beschreibung, Sprache und Sichtbarkeit. Unklare Ergebnisse bleiben unknown und werden nicht automatisch wiederholt.

Tests: PHP-CLI mit `define("JSSOCIAL_TEST_BOOTSTRAP",true); require "tests/youtube-rename.php";` (88 Prüfungen einschließlich bestehender Upload-/Termin-Tests). Keine OAuth- oder Datenbankmigration. Vermittlungsserver 1.4.0.

Bei unknown prüft erneutes execute ausschließlich lesend den Live-Stand. Es führt niemals erneut PUT aus.
