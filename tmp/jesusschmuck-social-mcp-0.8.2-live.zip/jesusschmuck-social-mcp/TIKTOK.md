# TikTok Sandbox · 0.7.0

Anmeldung mit user.info.basic und video.upload. Verschlüsselte Zugangsdaten, Sitzungs-/State-Prüfung, Token-Erneuerung und bestätigtes Zielkonto.

## Videoübergabe

Vier MCP-Werkzeuge: js_social_tiktok_prepare, js_social_tiktok_preview, js_social_tiktok_execute und js_social_tiktok_status.

Prepare erstellt eine lokale Vorschau mit Zielkonto, Videodatei und Hash, Beschreibung zum Kopieren sowie bestätigter TikTok-Rechtebasis. Execute benötigt die tatsächliche Nutzerfreigabe dieser Vorschau. Erst dann wird die Datei mit FILE_UPLOAD in einem Chunk übertragen. Lokale MP4 aus WordPress, maximal 12 MiB, 3–900 Sekunden, 360–4096 Pixel je Seite. Plattformabhängige Einschränkungen bleiben zusätzlich möglich.

Die Beschreibung wird NICHT übertragen. Nach SEND_TO_USER_INBOX öffnet der Nutzer die TikTok-App, folgt der Postfach-Benachrichtigung und stellt das Video manuell fertig. Keine automatische Veröffentlichung, kein Direct Post und keine Terminplanung. Sandbox-Verhalten ist erst nach erfolgreichem echtem Upload bestätigt.

Nicht bestätigte Initialisierungen oder Übertragungen werden nicht erneut gesendet. Erneutes Execute derselben ID liest nur den gespeicherten Stand. Status liest TikTok, soweit eine publish_id vorliegt. Datenbankbestätigung vor Initialisierung verhindert blinde Fortsetzung nach Speicherfehlern. Token/Upload-URL erscheinen nicht in Werkzeugantworten.

## Einrichtung

Redirect-URI: https://www.jesusschmuck.com/jssocial-tiktok-callback/
Sandbox: Login Kit (Web), Content Posting API, Target User. Direct Post aus. Sandbox Client Key und Secret im WordPress-Admin unter Jesusschmuck Social → Verbindungen speichern, dann verbinden.

Die TikTok-Einstellungen leeren vor dem Lesen gezielt ihre Option-Cacheeinträge und den negativen Options-Cache. Dies behebt den live nachgewiesenen Fall vorhandener DB-Daten bei leerem get_option-Ergebnis.

## Prüfung

55 TikTok-Prüfungen einschließlich Anmeldesicherheit, Tokenrotation, Cache, Freigabe, Dateihash, Uploadziel, Doppelupload-Sperre, DB-Persistenz und Postfach-/Veröffentlichungsstatus. 74 bestehende YouTube-/Aktionsprüfungen bestanden. Echte Videoübergabe noch ausstehend.

Referenzen:
- https://developers.tiktok.com/docs/en/content-posting-api-reference-upload-video
- https://developers.tiktok.com/docs/en/content-posting-api-media-transfer-guide
- https://developers.tiktok.com/docs/en/content-posting-api-reference-get-video-status
