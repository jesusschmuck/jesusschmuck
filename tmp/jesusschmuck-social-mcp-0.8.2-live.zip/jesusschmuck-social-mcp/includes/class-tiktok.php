<?php
defined('ABSPATH') || exit;
/** TikTok authorization and verified channel access. */
final class JSSocial_TikTok {
    private const SCOPE = 'user.info.basic,video.upload';
    public static function callback(): string { return home_url('/jssocial-tiktok-callback/'); }
    private static function guard(): void {
        if (!current_user_can('manage_options') || !is_ssl()) { wp_die('Administrator-Berechtigung und HTTPS erforderlich.'); }
    }
    private static function binding(): string {
        $c = JSSocial_Config::tiktok_credentials();
        return hash('sha256', $c['client_key'].'|'.$c['client_secret'].'|'.wp_get_session_token());
    }
    private static function finish(string $message): void {
        set_transient('jssocial_flash_'.get_current_user_id(), $message, 60);
        wp_safe_redirect(admin_url('admin.php?page=jssocial&tab=setup')); exit;
    }
    public static function status(): array {
        $out = ['configured'=>false, 'connected'=>false, 'mode'=>'sandbox', 'publishing_enabled'=>false, 'upload_enabled'=>false, 'redirect_uri'=>self::callback(), 'features'=>['oauth','account_verify','inbox_upload','upload_status']];
        try {
            $k = JSSocial_Config::tiktok_credentials(); $c = JSSocial_Config::tiktok_connection();
            $out['configured'] = $k['client_key'] !== '' && $k['client_secret'] !== '';
            $out['connected'] = !empty($c['refresh_token']) && !empty($c['account']['id']);
            $out['upload_enabled'] = $out['connected'] && in_array('video.upload',explode(',',$c['scope']??''),true);
            $out['upload_limit_bytes'] = 12*1024*1024;
            $out['account'] = $c['account'] ?? null;
            $out['granted_scopes'] = explode(',', $c['scope'] ?? '');
            $out['checked_at'] = !empty($c['checked_at']) ? gmdate('c', $c['checked_at']) : null;
            $out['note'] = 'Sandbox: Videoübergabe nach Vorschau/Freigabe. Beschreibung separat kopieren; Veröffentlichung manuell in TikTok. Keine Terminplanung.';
        } catch (Throwable $e) { $out['error'] = 'TikTok-Konfiguration konnte nicht gelesen werden.'; }
        return $out;
    }
    private static function response($response): array {
        if (is_wp_error($response)) { throw new RuntimeException('TikTok ist derzeit nicht erreichbar. Verbindung wurde nicht geändert.'); }
        $status = wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);
        if ($status < 200 || $status >= 300 || !is_array($data) || (isset($data['error']) && (!is_array($data['error']) || ($data['error']['code'] ?? '') !== 'ok'))) {
            // Never expose raw provider responses, request payloads, tokens or authorization codes.
            throw new RuntimeException('TikTok-Anfrage fehlgeschlagen (HTTP '.(int)$status.'). Client-Einstellungen und erteilte Berechtigungen prüfen.');
        }
        return $data;
    }
    private static function token(array $body): array {
        $c = JSSocial_Config::tiktok_credentials();
        return self::response(wp_remote_post('https://open.tiktokapis.com/v2/oauth/token/', [
            'timeout' => 30, 'redirection' => 0,
            'headers' => ['Content-Type'=>'application/x-www-form-urlencoded'],
            'body' => http_build_query(array_merge($body, ['client_key' => $c['client_key'], 'client_secret' => $c['client_secret']]), '', '&', PHP_QUERY_RFC3986),
        ]));
    }
    private static function account(string $access_token): array {
        $data = self::response(wp_remote_get('https://open.tiktokapis.com/v2/user/info/?fields=open_id,display_name', [
            'timeout'=>30, 'redirection'=>0, 'headers'=>['Authorization'=>'Bearer '.$access_token],
        ]));
        $u = $data['data']['user'] ?? [];
        if (!is_string($u['open_id'] ?? null) || $u['open_id'] === '' || !is_string($u['display_name'] ?? null)) { throw new RuntimeException('TikTok hat kein gültiges Konto geliefert.'); }
        return ['id'=>$u['open_id'], 'title'=>$u['display_name']];
    }
    private static function validated_token(array $t): array {
        foreach (['access_token','refresh_token','open_id','scope'] as $k) {
            if (!is_string($t[$k] ?? null) || $t[$k] === '') { throw new RuntimeException('TikTok hat keinen vollständigen Kontozugriff erteilt.'); }
        }
        if (($t['token_type'] ?? '') !== 'Bearer' || !is_int($t['expires_in'] ?? null) || $t['expires_in'] <= 0 || !is_int($t['refresh_expires_in'] ?? null) || $t['refresh_expires_in'] <= 0) { throw new RuntimeException('TikTok hat eine ungültige Tokenantwort geliefert.'); }
        $scopes = array_map('trim', explode(',', $t['scope']));
        foreach (explode(',', self::SCOPE) as $scope) { if (!in_array($scope, $scopes, true)) { throw new RuntimeException('TikTok-Konto erneut verbinden und Profil- sowie Upload-Berechtigung erteilen.'); } }
        return ['access_token'=>$t['access_token'], 'refresh_token'=>$t['refresh_token'], 'open_id'=>$t['open_id'], 'scope'=>implode(',', $scopes), 'expires_at'=>time()+$t['expires_in'], 'refresh_expires_at'=>time()+$t['refresh_expires_in']];
    }
    public static function authorization_url(): string {
        $c = JSSocial_Config::tiktok_credentials();
        if ($c['client_key'] === '' || $c['client_secret'] === '') { throw new RuntimeException('TikTok Client Key und Client Secret zuerst speichern.'); }
        $state = bin2hex(random_bytes(32));
        set_transient('jssocial_tt_state_'.get_current_user_id(), ['hash' => hash('sha256', $state), 'binding' => self::binding()], 600);
        return 'https://www.tiktok.com/v2/auth/authorize/?'.http_build_query([
            'client_key' => $c['client_key'], 'redirect_uri' => self::callback(), 'response_type' => 'code',
            'scope' => self::SCOPE, 'state' => $state, 'disable_auto_auth' => 1,
        ], '', '&', PHP_QUERY_RFC3986);
    }
    public static function complete(array $query): void {
        $key = 'jssocial_tt_state_'.get_current_user_id();
        $expected = get_transient($key);
        $state = is_string($query['state'] ?? null) ? $query['state'] : '';
        if (!is_array($expected) || !hash_equals($expected['hash'], hash('sha256', $state)) || !hash_equals($expected['binding'], self::binding())) {
            throw new RuntimeException('TikTok-Anmeldung abgelaufen oder ungültig. Verbindung erneut starten.');
        }
        delete_transient($key); // One-time use, also on cancellation or token errors.
        if (isset($query['error'])) { throw new RuntimeException('TikTok-Anmeldung abgebrochen oder nicht genehmigt.'); }
        $code = $query['code'] ?? '';
        if (!is_string($code) || $code === '' || strlen($code) > 4096) { throw new RuntimeException('TikTok hat keinen gültigen Anmeldecode geliefert.'); }
        $token = self::token(['code' => $code, 'grant_type' => 'authorization_code', 'redirect_uri' => self::callback()]);
        $c = self::validated_token($token);
        $account = self::account($c['access_token']);
        if ($account['id'] !== $c['open_id']) { throw new RuntimeException('TikTok-Konto stimmt nicht mit der Anmeldung überein.'); }
        JSSocial_Config::save_tiktok_connection(array_merge($c, ['account'=>$account, 'connected_at'=>time(), 'checked_at'=>time()]));
    }
    public static function verify(): array {
        $c = JSSocial_Config::tiktok_connection();
        if (empty($c['refresh_token']) || empty($c['account']['id'])) { throw new RuntimeException('TikTok ist noch nicht verbunden.'); }
        if (($c['refresh_expires_at'] ?? 0) <= time()) { throw new RuntimeException('TikTok-Anmeldung abgelaufen. Bitte erneut verbinden.'); }
        if (empty($c['access_token']) || ($c['expires_at'] ?? 0) <= time()+60) {
            $t = self::validated_token(self::token(['grant_type'=>'refresh_token','refresh_token'=>$c['refresh_token']]));
            if ($t['open_id'] !== $c['account']['id']) { throw new RuntimeException('TikTok meldet ein anderes Konto. Bitte neu verbinden.'); }
            $c = array_merge($c, $t);
            // Persist rotating refresh tokens before a subsequent profile request can fail.
            JSSocial_Config::save_tiktok_connection($c);
        }
        $account = self::account($c['access_token']);
        if ($account['id'] !== $c['account']['id']) { throw new RuntimeException('TikTok meldet ein anderes Konto. Bitte neu verbinden.'); }
        $c['account']=$account; $c['checked_at']=time(); JSSocial_Config::save_tiktok_connection($c);
        return $account;
    }
    public static function callback_action(): void {
        self::guard(); nocache_headers(); header('Referrer-Policy: no-referrer');
        try { self::complete(wp_unslash($_GET)); self::finish('TikTok-Testkonto verbunden. Videoübergabe über ChatGPT nach Vorschau und Freigabe möglich.'); }
        catch (Throwable $e) { self::finish($e->getMessage()); }
    }
    public static function admin_action(): void {
        self::guard(); check_admin_referer('jssocial_tiktok');
        $a = wp_unslash($_POST);
        try {
            switch ($a['op'] ?? '') {
                case 'save': JSSocial_Config::save_tiktok_credentials(trim((string)($a['client_key'] ?? '')), trim((string)($a['client_secret'] ?? ''))); self::finish('TikTok-Zugangsdaten verschlüsselt gespeichert. Jetzt TikTok verbinden.'); break;
                case 'connect': wp_redirect(self::authorization_url()); exit;
                case 'verify': $c = self::verify(); self::finish('TikTok-Konto bestätigt: '.$c['title']); break;
                case 'disconnect': delete_option('jssocial_tiktok_connection'); delete_transient('jssocial_tt_state_'.get_current_user_id()); self::finish('TikTok-Verbindung lokal entfernt.'); break;
                default: throw new InvalidArgumentException('Unbekannte TikTok-Aktion.');
            }
        } catch (Throwable $e) { self::finish($e->getMessage()); }
    }
    private static function form(string $op): void {
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">'; wp_nonce_field('jssocial_tiktok');
        echo '<input type="hidden" name="action" value="jssocial_tiktok_action"><input type="hidden" name="op" value="'.esc_attr($op).'">';
    }
    public static function render_setup(): void {
        $s = self::status();
        echo '<section class="jss-card"><h2>TikTok · Sandbox-Test</h2><p>Testkonto verbinden und prüfen. Videoübergabe (MP4 bis 12 MB) über ChatGPT nach Vorschau und Freigabe. Danach TikTok-App öffnen und Postfach-Benachrichtigung bearbeiten. Beschreibung separat kopieren; keine automatische Veröffentlichung oder Planung.</p><p>Redirect-URI für TikTok Login Kit:</p><code class="jss-url">'.esc_html(self::callback()).'</code>';
        self::form('save');
        echo '<label class="jss-field">Sandbox Client Key<input name="client_key" value="'.esc_attr(JSSocial_Config::tiktok_credentials()['client_key']).'" required></label><label class="jss-field">Sandbox Client Secret<input name="client_secret" type="password" autocomplete="new-password" placeholder="Leer lassen zum Beibehalten"></label><p>Secret und Kontozugriff werden verschlüsselt gespeichert.</p><button class="button">TikTok-Konfiguration speichern</button></form>';
        if ($s['configured']) { self::form('connect'); echo '<p><button class="button button-primary">Mit TikTok verbinden</button></p></form>'; }
        if ($s['connected']) {
            echo '<p>Konto: '.esc_html($s['account']['title']).' · '.esc_html($s['account']['id']).'</p>';
            self::form('verify'); echo '<p><button class="button">TikTok-Konto prüfen</button></p></form>';
            self::form('disconnect'); echo '<button class="button">TikTok-Verbindung lokal entfernen</button></form>';
        }
        echo '</section>';
    }
}
