<?php
defined('ABSPATH') || exit;
final class JSSocial_Service {
    public static function time(string $local, string $offset = ''): int {
        if ($local === '') { return 0; }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/', $local)) { throw new InvalidArgumentException('Termin als JJJJ-MM-TTTHH:MM in Europe/Berlin angeben.'); }
        $zone = new DateTimeZone('Europe/Berlin');
        $base = DateTimeImmutable::createFromFormat('!Y-m-d\TH:i', $local, new DateTimeZone('UTC'));
        if (!$base || $base->format('Y-m-d\TH:i') !== $local) { throw new InvalidArgumentException('Ungültiges Datum.'); }
        $candidates = [];
        foreach (['+01:00' => 3600, '+02:00' => 7200] as $o => $seconds) {
            $t = $base->getTimestamp() - $seconds;
            if ((new DateTimeImmutable('@' . $t))->setTimezone($zone)->format('Y-m-d\TH:i') === $local) { $candidates[$o] = $t; }
        }
        if (!$candidates) { throw new InvalidArgumentException('Diese Uhrzeit existiert wegen der Sommerzeitumstellung nicht.'); }
        if ($offset !== '' && !isset($candidates[$offset])) { throw new InvalidArgumentException('UTC-Abweichung passt nicht zu diesem Berliner Termin.'); }
        if (count($candidates) > 1 && $offset === '') { throw new InvalidArgumentException('Diese Uhrzeit kommt zweimal vor. Bitte +02:00 (Sommerzeit) oder +01:00 (Winterzeit) wählen.'); }
        return $offset ? $candidates[$offset] : reset($candidates);
    }
    public static function local(int $ts): string { return $ts ? (new DateTimeImmutable('@' . $ts))->setTimezone(new DateTimeZone('Europe/Berlin'))->format('d.m.Y H:i P') : 'Sofort nach Freigabe / nächster Worker-Lauf'; }
    public static function asset(int $id, string $kind, array $platforms = []): array {
        $post = get_post($id); $path = get_attached_file($id);
        if (!$post || $post->post_type !== 'attachment' || !$path || !is_file($path) || is_link($path)) { throw new InvalidArgumentException('Datei muss als lokale WordPress-Mediendatei vorhanden sein.'); }
        $mime = wp_check_filetype_and_ext($path, basename($path))['type'] ?? '';
        $size = filesize($path); $url = wp_get_attachment_url($id);
        $uploads = wp_upload_dir();
        if (!str_starts_with(wp_normalize_path(realpath($path)), rtrim(wp_normalize_path(realpath($uploads['basedir'])), '/') . '/')) { throw new InvalidArgumentException('Datei liegt außerhalb des WordPress-Upload-Verzeichnisses.'); }
        if (wp_parse_url($url, PHP_URL_SCHEME) !== 'https') { throw new InvalidArgumentException('Meta benötigt eine öffentlich erreichbare HTTPS-Mediendatei.'); }
        $meta = [];
        if ($kind === 'reel') {
            if ($mime !== 'video/mp4' || $size > 300 * 1024 * 1024) { throw new InvalidArgumentException('Reels benötigen MP4, maximal 300 MB.'); }
            require_once ABSPATH . 'wp-admin/includes/media.php';
            $meta = wp_read_video_metadata($path);
            if (!$meta || empty($meta['length']) || empty($meta['width']) || empty($meta['height'])) { throw new InvalidArgumentException('Videodaten konnten nicht geprüft werden.'); }
            $max = in_array('facebook', $platforms, true) ? 90 : 900;
            if ($meta['length'] < 3 || $meta['length'] > $max) { throw new InvalidArgumentException('Videolänge muss zwischen 3 und ' . $max . ' Sekunden liegen.'); }
            if (in_array('facebook', $platforms, true) && ($meta['width'] < 540 || $meta['height'] < 960 || abs($meta['width'] / $meta['height'] - 9/16) > 0.02)) { throw new InvalidArgumentException('Facebook-Reels: mindestens 540 × 960 Pixel im Format 9:16 verwenden.'); }
        } else {
            $dims = @getimagesize($path);
            if (!$dims || $mime !== 'image/jpeg' || $dims[2] !== IMAGETYPE_JPEG || $size > 8 * 1024 * 1024) { throw new InvalidArgumentException('Bild/Cover benötigt JPEG, maximal 8 MB.'); }
            $meta = ['width' => $dims[0], 'height' => $dims[1]];
            if ($kind === 'image' && in_array('instagram', $platforms, true) && ($dims[0]/$dims[1] < 0.8 || $dims[0]/$dims[1] > 1.91)) { throw new InvalidArgumentException('Instagram-Einzelbild: Seitenverhältnis zwischen 4:5 und 1,91:1 verwenden.'); }
        }
        return ['attachment_id' => $id, 'filename' => basename($path), 'url' => $url, 'sha256' => hash_file('sha256', $path), 'bytes' => $size, 'mime' => $mime, 'width' => $meta['width'] ?? null, 'height' => $meta['height'] ?? null, 'seconds' => $meta['length'] ?? null];
    }
    public static function caption(string $text, string $platform, string $product_url, string $campaign): string {
        $text = trim($text);
        if ($text !== wp_strip_all_tags($text)) { throw new InvalidArgumentException('Captions bitte ohne HTML hinterlegen.'); }
        $text = trim($text);
        if ($platform === 'instagram') {
            if (preg_match('~(?:[a-z][a-z0-9+.-]*://|www\.|\b[\pL\d-]+\.[\pL]{2,63}\b)~iu', $text)) { throw new InvalidArgumentException('Instagram-Caption darf keine URL enthalten.'); }
            if (!preg_match('/(?:Shop.?Link|Link).*(?:Profil|Bio)|(?:Profil|Bio).*(?:Shop|Link)/iu', $text)) { $text .= "\n\nEntdecke das Schmuckstück über den Shop-Link in unserem Profil."; }
        } elseif (trim($product_url) !== '') {
            $product_url = trim($product_url);
            $u = wp_parse_url($product_url);
            if (($u['scheme'] ?? '') !== 'https' || !in_array(strtolower($u['host'] ?? ''), ['jesusschmuck.com','www.jesusschmuck.com'], true) || isset($u['user']) || isset($u['pass'])) { throw new InvalidArgumentException('Facebook benötigt einen HTTPS-Produktlink auf Jesusschmuck.com.'); }
            // Generate the one authoritative product URL rather than trusting user-supplied tracking.
            $text = preg_replace('~https?://(?:www\.)?jesusschmuck\.com[^\s]*~iu', '', $text);
            if (preg_match('~https?://|www\.~i', $text)) { throw new InvalidArgumentException('Weitere Facebook-Links bitte entfernen; Produktlink separat eintragen.'); }
            $tracked = add_query_arg(['utm_source' => 'facebook', 'utm_medium' => 'organic_social', 'utm_campaign' => $campaign], $product_url);
            $text = trim($text) . "\n\nJetzt im Shop entdecken: " . $tracked;
        }
        if (!str_contains($text, '#')) { $text .= "\n\n#Jesusschmuck #Glaubensschmuck #SchmuckMitBedeutung"; }
        if ($platform === 'instagram' && (mb_strlen($text) > 2200 || preg_match_all('/#[\pL\pN_]+/u', $text) > 30)) { throw new InvalidArgumentException('Instagram: maximal 2.200 Zeichen und 30 Hashtags.'); }
        if (mb_strlen($text) > 5000) { throw new InvalidArgumentException('Caption in Version 0.1.0 auf 5.000 Zeichen begrenzt.'); }
        return $text;
    }
    public static function payload(array $a): array {
        $allowed = ['request_key','attachment_id','kind','platforms','instagram_caption','facebook_caption','product_url','campaign','local_datetime','utc_offset','cover_id','thumb_offset','share_to_feed','audio','product_tags','facebook_attachment_id','facebook_audio_rights'];
        if (array_diff(array_keys($a), $allowed)) { throw new InvalidArgumentException('Unbekannte Entwurfsfelder.'); }
        $platforms = $a['platforms'] ?? [];
        if (!$platforms || !is_array($platforms) || array_diff($platforms, ['instagram','facebook']) || count(array_unique($platforms)) !== count($platforms)) { throw new InvalidArgumentException('Instagram, Facebook oder beide auswählen.'); }
        sort($platforms); $kind = $a['kind'] ?? 'reel';
        if (!in_array($kind, ['reel','image'], true)) { throw new InvalidArgumentException('Nur reel oder image unterstützt.'); }
        $targets = JSSocial_Config::targets();
        foreach ($platforms as $p) { if (empty($targets[$p]['id'])) { throw new InvalidArgumentException('Zielkonto fehlt: ' . $p); } }
        $due = self::time((string) ($a['local_datetime'] ?? ''), (string) ($a['utc_offset'] ?? ''));
        if ($due && $due <= time()) { throw new InvalidArgumentException('Termin muss in der Zukunft liegen; später heute ist möglich.'); }
        $asset = self::asset((int) ($a['attachment_id'] ?? 0), $kind, $platforms);
        $captions = []; $campaign = sanitize_title($a['campaign'] ?? 'schmuck-der-woche');
        if (!$campaign) { throw new InvalidArgumentException('UTM-Kampagnenname fehlt.'); }
        foreach ($platforms as $p) { $captions[$p] = self::caption((string) ($a[$p . '_caption'] ?? ''), $p, (string) ($a['product_url'] ?? ''), $campaign); }
        $options = ['share_to_feed' => (bool) ($a['share_to_feed'] ?? true)];
        if (!empty($a['facebook_attachment_id'])) {
            if ($kind !== 'reel' || !in_array('facebook', $platforms, true)) { throw new InvalidArgumentException('Separate Facebook-Datei nur für Facebook-Reels.'); }
            $options['facebook_asset'] = self::asset((int) $a['facebook_attachment_id'], 'reel', ['facebook']);
            $rights = $a['facebook_audio_rights'] ?? [];
            $options['facebook_audio_rights'] = self::rights($rights);
        } elseif (!empty($a['facebook_audio_rights'])) { throw new InvalidArgumentException('Facebook-Rechte benötigen eine separate Facebook-Datei.'); }
        if (!empty($a['cover_id'])) { $options['cover'] = self::asset((int) $a['cover_id'], 'cover'); }
        if (isset($a['thumb_offset']) && $a['thumb_offset'] !== '') {
            $n = filter_var($a['thumb_offset'], FILTER_VALIDATE_INT);
            if ($n === false || $n < 0 || $n >= ($asset['seconds'] ?? 0) * 1000) { throw new InvalidArgumentException('Cover-Zeitpunkt muss innerhalb des Videos liegen (Millisekunden).'); }
            $options['thumb_offset'] = $n;
        }
        if ((!empty($options['cover']) || isset($options['thumb_offset'])) && ($kind !== 'reel' || !in_array('instagram', $platforms, true))) { throw new InvalidArgumentException('Cover-Einstellungen gelten in 0.1.0 nur für Instagram-Reels.'); }
        if (!empty($a['audio']['audio_id'])) {
            if ($kind !== 'reel' || !in_array('instagram', $platforms, true)) { throw new InvalidArgumentException('Audio-API nur für Instagram-Reels verfügbar.'); }
            $audio = $a['audio'];
            $rights = self::rights($audio);
            $found = (new JSSocial_Meta())->audio('', 'music', (string) $audio['audio_id']);
            if (empty($found['tracks'][0])) { throw new InvalidArgumentException('Audio für dieses Konto nicht verfügbar.'); }
            $track = $found['tracks'][0];
            foreach (['audio_volume','video_volume'] as $v) { $n = filter_var($audio[$v] ?? 100, FILTER_VALIDATE_INT); if ($n === false || $n < 0 || $n > 100) { throw new InvalidArgumentException('Lautstärke muss 0–100 betragen.'); } $options['audio'][$v] = $n; }
            $options['audio']['audio_id'] = (string) $track['audio_id'];
            $options['audio']['title'] = $track['title'] ?? '';
            $options['audio']['artist'] = $track['display_artist'] ?? $track['ig_username'] ?? '';
            $options['audio']['is_ads_eligible'] = $track['is_ads_eligible'] ?? null;
            $options['audio'] += $rights;
            $options['audio']['rights_checked_at'] = gmdate('c');
        }
        if (!empty($a['product_tags'])) {
            if ($kind !== 'image') { throw new InvalidArgumentException('Produktmarkierungen in 0.1.0 nur für JPEG-Einzelbilder. Reel-Tags bleiben bis zur gesonderten API-/Kontoprüfung gesperrt.'); }
            if (!in_array('instagram', $platforms, true) || !(JSSocial_Config::product_tags_enabled())) { throw new InvalidArgumentException('Instagram-Produktmarkierungen zuerst separat konfigurieren und berechtigen.'); }
            $tags = $a['product_tags'];
            if (!is_array($tags) || count($tags) > 5) { throw new InvalidArgumentException('Maximal fünf Produktmarkierungen.'); }
            $ids = [];
            foreach ($tags as $t) {
                if (array_diff(array_keys($t), ['product_id','x','y']) || !ctype_digit((string) ($t['product_id'] ?? ''))) { throw new InvalidArgumentException('Meta-Katalog-Produkt-ID benötigt (keine WooCommerce-ID).'); }
                foreach (['x','y'] as $axis) { if (isset($t[$axis]) && ($kind !== 'image' || !is_numeric($t[$axis]) || $t[$axis] < 0 || $t[$axis] > 1)) { throw new InvalidArgumentException('Produktposition x/y nur bei Bildern zwischen 0 und 1.'); } }
                $ids[] = $t['product_id'];
            }
            if (count($ids) !== count(array_unique($ids))) { throw new InvalidArgumentException('Produktmarkierungen müssen eindeutig sein.'); }
            $options['product_tags'] = $tags;
        }
        return ['kind' => $kind, 'platforms' => $platforms, 'targets' => array_intersect_key($targets, array_flip($platforms)), 'asset' => $asset, 'captions' => $captions, 'options' => $options, 'due' => $due, 'timezone' => 'Europe/Berlin', 'local_datetime' => $a['local_datetime'] ?? '', 'utc_offset' => $a['utc_offset'] ?? ''];
    }
    public static function rights(array $input): array {
        $confirmed = ($input['rights_confirmed'] ?? false) === true;
        $basis = sanitize_textarea_field($input['rights_basis'] ?? '');
        if ($confirmed && mb_strlen($basis) < 8) { throw new InvalidArgumentException('Für bestätigte Musikrechte eine konkrete Rechtequelle / Lizenz angeben.'); }
        return ['rights_confirmed' => $confirmed, 'rights_basis' => $basis, 'rights_status' => $confirmed ? 'user_confirmed' : 'unverified'];
    }
    public static function music_blockers(array $job): array {
        $o = $job['payload']['options']; $out = [];
        foreach (['audio' => 'Instagram-Musik', 'facebook_audio_rights' => 'Facebook-Musik'] as $key => $label) {
            if (!isset($o[$key])) { continue; }
            $r = $o[$key];
            // Older drafts required a concrete rights basis at creation.
            $confirmed = $r['rights_confirmed'] ?? (!isset($r['rights_status']) && mb_strlen(trim($r['rights_basis'] ?? '')) >= 8);
            if (!$confirmed || mb_strlen(trim($r['rights_basis'] ?? '')) < 8) { $out[] = $label . ': Nutzungsrechte noch nicht bestätigt. Neuer Entwurf mit konkretem Lizenznachweis erforderlich.'; }
        }
        return $out;
    }
    public static function create(array $args): array {
        return JSSocial_Store::lock(function () use ($args) {
            $key = $args['request_key'] ?? '';
            if (!preg_match('/^[A-Za-z0-9_-]{8,64}$/', $key)) { throw new InvalidArgumentException('Eindeutigen request_key mit 8–64 Zeichen angeben und bei Wiederholung beibehalten.'); }
            $request_hash = hash('sha256', wp_json_encode($args));
            $existing = JSSocial_Store::by_key($key);
            if ($existing) { if (($existing['request_hash'] ?? '') !== $request_hash) { throw new InvalidArgumentException('request_key bereits mit anderen Daten verwendet.'); } return self::preview($existing); }
            $payload = self::payload($args);
            $job = ['request_key' => $key, 'request_hash' => $request_hash, 'revision' => 1, 'state' => 'draft', 'due' => $payload['due'], 'payload' => $payload, 'results' => [], 'approval' => null, 'audit' => []];
            foreach ($payload['platforms'] as $p) { $job['results'][$p] = ['state' => 'pending', 'stage' => 'new', 'remote_id' => '', 'published_id' => '', 'url' => '', 'error' => '', 'next_at' => 0, 'read_failures' => 0]; }
            JSSocial_Store::event($job, 'Entwurf erstellt. Keine Veröffentlichung oder Planung.');
            return self::preview(JSSocial_Store::insert($job));
        });
    }
    public static function hash(array $job): string { return hash('sha256', wp_json_encode(['id' => $job['id'], 'revision' => $job['revision'], 'payload' => $job['payload']], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); }
    public static function preview(array $job): array {
        $out = $job; $out['preview_hash'] = self::hash($job); $out['when_berlin'] = self::local($job['due']);
        $out['review_url'] = admin_url('admin.php?page=jssocial&job=' . $job['id']);
        $out['approval_text'] = 'FREIGEBEN ' . $job['id'] . ' ' . $out['preview_hash'];
        $out['warnings'] = ['Veröffentlichungsbeginn zum Termin; Meta-Verarbeitung kann mehrere Minuten dauern.', 'Die Dateivorschau enthält keine über die Instagram Audio API gewählte Musik.'];
        if (isset($job['payload']['options']['audio']) && in_array('facebook', $job['payload']['platforms'], true)) { $out['warnings'][] = isset($job['payload']['options']['facebook_asset']) ? 'Facebook verwendet die separate Datei mit eingebettetem Ton; Instagram-Audio wird nicht übertragen.' : 'Facebook verwendet ausschließlich den Ton der Hauptdatei; Instagram-Audio wird nicht übertragen.'; }
        $out['publication_blockers'] = self::music_blockers($job);
        $out['warnings'] = array_merge($out['warnings'], $out['publication_blockers']);
        return $out;
    }
    public static function assert_assets(array $job): void {
        $blockers = self::music_blockers($job);
        if ($blockers) { throw new RuntimeException(implode(' ', $blockers)); }
        $p = $job['payload']; $current = self::asset($p['asset']['attachment_id'], $p['kind'], $p['platforms']);
        if ($current['sha256'] !== $p['asset']['sha256'] || $current['url'] !== $p['asset']['url']) { throw new RuntimeException('Mediendatei seit Vorschau verändert. Neuer Entwurf und neue Freigabe nötig.'); }
        if (isset($p['options']['cover'])) { $c = $p['options']['cover']; $now = self::asset($c['attachment_id'], 'cover'); if ($now['sha256'] !== $c['sha256'] || $now['url'] !== $c['url']) { throw new RuntimeException('Cover seit Freigabe verändert.'); } }
        if (isset($p['options']['facebook_asset'])) {
            $f = $p['options']['facebook_asset']; $now = self::asset($f['attachment_id'], 'reel', ['facebook']);
            if ($now['sha256'] !== $f['sha256'] || $now['url'] !== $f['url']) { throw new RuntimeException('Facebook-Datei seit Vorschau verändert. Neuer Entwurf nötig.'); }
        }
        $targets = JSSocial_Config::targets();
        foreach ($p['platforms'] as $platform) { if ($targets[$platform]['id'] !== $p['targets'][$platform]['id']) { throw new RuntimeException('Zielkonto wurde geändert. Bestehende Freigabe gilt dafür nicht.'); } }
    }
    public static function approve(int $id, string $hash, string $confirmation, string $evidence): array {
        return JSSocial_Store::lock(function () use ($id, $hash, $confirmation, $evidence) {
            $j = JSSocial_Store::get($id);
            if (!hash_equals(self::hash($j), $hash)) { throw new InvalidArgumentException('Vorschau veraltet. Bitte erneut ansehen und freigeben.'); }
            if ($confirmation !== 'FREIGEBEN ' . $id . ' ' . $hash || mb_strlen(trim($evidence)) < 5) { throw new InvalidArgumentException('Ausdrückliche Freigabe des Nutzers und exakte Vorschau-Bestätigung erforderlich.'); }
            if ($j['approval'] && hash_equals($j['approval']['hash'], $hash)) { return self::preview($j); }
            if ($j['state'] !== 'draft') { throw new InvalidArgumentException('Nur ein Entwurf kann freigegeben werden.'); }
            if (!JSSocial_Worker::health()['healthy']) { throw new RuntimeException('Server-Worker noch nicht zuverlässig nachgewiesen. Zwei regelmäßige CLI-Läufe abwarten.'); }
            if ($j['due'] && $j['due'] <= time()) { throw new InvalidArgumentException('Termin ist inzwischen vergangen. Bitte neu auswählen.'); }
            self::assert_assets($j); $verify = (new JSSocial_Meta())->verify();
            foreach ($j['payload']['platforms'] as $p) { if (empty($verify[$p . '_ready'])) { throw new RuntimeException('Kontoprüfung nicht bestanden: ' . $p . '. Berechtigungen und Seitenrolle prüfen.'); } }
            if (!empty($j['payload']['options']['product_tags']) && array_diff(['catalog_management','instagram_shopping_tag_products'], $verify['permissions'])) { throw new RuntimeException('Produktmarkierungs-Berechtigungen fehlen.'); }
            if (!empty($j['payload']['options']['product_tags']) && empty($verify['product_tag_eligible'])) { throw new RuntimeException('Meta bestätigt für dieses Konto keine Produktmarkierungs-Berechtigung.'); }
            JSSocial_Meta::assert_schedule($verify, $j['payload']['platforms'], (int)$j['due']);
            $j['approval'] = ['hash' => $hash, 'at' => gmdate('c'), 'evidence' => sanitize_textarea_field($evidence), 'actor' => get_current_user_id() ?: 'mcp'];
            $j['state'] = 'queued'; JSSocial_Store::event($j, 'Ausdrücklich freigegeben: ' . self::local($j['due'])); JSSocial_Store::save($j);
            return self::preview($j);
        });
    }
    public static function cancel(int $id, string $hash): array {
        return JSSocial_Store::lock(function () use ($id, $hash) {
            $j = JSSocial_Store::get($id);
            if (!hash_equals(self::hash($j), $hash)) { throw new InvalidArgumentException('Vorschau veraltet.'); }
            if ($j['state'] === 'published') { throw new InvalidArgumentException('Bereits veröffentlicht; Storno löscht keine Meta-Beiträge.'); }
            $j['state'] = 'cancelled'; JSSocial_Store::event($j, 'Weitere Verarbeitung storniert. Bereits gesendete Veröffentlichungsanfragen können trotzdem abgeschlossen werden.'); JSSocial_Store::save($j); return self::preview($j);
        });
    }
    public static function reschedule(int $id, string $hash, string $local, string $offset = ''): array {
        return JSSocial_Store::lock(function () use ($id, $hash, $local, $offset) {
            $j = JSSocial_Store::get($id);
            if (!hash_equals(self::hash($j), $hash)) { throw new InvalidArgumentException('Vorschau veraltet.'); }
            if (!in_array($j['state'], ['draft','queued','cancelled'], true)) { throw new InvalidArgumentException('Gestartete Beiträge können nicht verschoben werden.'); }
            foreach ($j['results'] as $r) { if ($r['stage'] !== 'new') { throw new InvalidArgumentException('Vorbereitung auf Meta bereits gestartet. Keine Terminänderung möglich.'); } }
            $due = self::time($local, $offset);
            if ($due && $due <= time()) { throw new InvalidArgumentException('Termin liegt in der Vergangenheit.'); }
            $j['due'] = $due; $j['payload']['due'] = $due; $j['payload']['local_datetime'] = $local; $j['payload']['utc_offset'] = $offset;
            $j['revision']++; $j['state'] = 'draft'; $j['approval'] = null;
            JSSocial_Store::event($j, 'Terminänderung vorbereitet. Alter Termin aufgehoben; neuer Termin benötigt Freigabe.'); JSSocial_Store::save($j); return self::preview($j);
        });
    }
    public static function retry(int $id, string $platform): array {
        return JSSocial_Store::lock(function () use ($id, $platform) {
            $j = JSSocial_Store::get($id); $r = $j['results'][$platform] ?? [];
            if (!$j['approval'] || in_array($j['state'], ['cancelled','draft'], true)) { throw new InvalidArgumentException('Keine aktive Freigabe.'); }
            if (($r['state'] ?? '') === 'published') { return self::preview($j); }
            if (($r['state'] ?? '') !== 'failed' || !empty($r['publish_sent'])) { throw new InvalidArgumentException('Kein sicherer Neuversuch möglich. Unklare Veröffentlichungsanfragen zuerst anhand der Meta-ID prüfen; sie werden nie erneut gesendet.'); }
            $j['results'][$platform]['state'] = 'pending'; $j['results'][$platform]['error'] = ''; $j['results'][$platform]['next_at'] = 0; $j['results'][$platform]['read_failures'] = 0;
            $j['state'] = 'queued'; JSSocial_Store::event($j, 'Sicherer Neuversuch nur für ' . $platform); JSSocial_Store::save($j); return self::preview($j);
        });
    }
    public static function upload(string $filename, string $base64): array {
        if (str_starts_with($filename, '__JSS_CHUNK__')) { return self::upload_chunk($filename, $base64); }
        if (strlen($base64) > 18 * 1024 * 1024) { throw new InvalidArgumentException('MCP-Upload maximal 12 MB. Größere Dateien über WordPress-Medien hochladen.'); }
        $bytes = base64_decode($base64, true);
        if (!$bytes || strlen($bytes) > 12 * 1024 * 1024) { throw new InvalidArgumentException('Ungültiger oder zu großer Base64-Upload.'); }
        $name = sanitize_file_name($filename); $extension = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if (!in_array($extension, ['mp4','jpg','jpeg'], true)) { throw new InvalidArgumentException('Nur MP4/JPEG erlaubt.'); }
        return JSSocial_Store::lock(function () use ($name, $bytes, $extension) {
            $hash = hash('sha256', $bytes); $old = (int) get_option('jssocial_asset_' . $hash, 0);
            if ($old && is_file((string) get_attached_file($old)) && hash_file('sha256', get_attached_file($old)) === $hash) { return self::asset($old, $extension === 'mp4' ? 'reel' : 'image'); }
            $u = wp_upload_bits($name, null, $bytes);
            if (!empty($u['error'])) { throw new RuntimeException('Upload fehlgeschlagen: ' . $u['error']); }
            $check = wp_check_filetype_and_ext($u['file'], $name); $mime = $check['type'] ?? '';
            $expected = $extension === 'mp4' ? 'video/mp4' : 'image/jpeg';
            if ($mime !== $expected) { wp_delete_file($u['file']); throw new InvalidArgumentException('Dateityp ungültig.'); }
            $id = wp_insert_attachment(['post_title' => pathinfo($name, PATHINFO_FILENAME), 'post_mime_type' => $mime, 'post_status' => 'inherit'], $u['file'], 0, true);
            if (is_wp_error($id)) { wp_delete_file($u['file']); throw new RuntimeException('Mediendatei konnte nicht registriert werden.'); }
            try { $out = self::asset((int) $id, $extension === 'mp4' ? 'reel' : 'image'); }
            catch (Throwable $e) { wp_delete_attachment($id, true); throw $e; }
            require_once ABSPATH . 'wp-admin/includes/image.php';
            wp_update_attachment_metadata($id, wp_generate_attachment_metadata($id, $u['file']));
            update_option('jssocial_asset_' . $hash, (int) $id, false); return $out;
        });
    }

    private static function upload_chunk(string $marker, string $base64): array {
        if (!preg_match('~^__JSS_CHUNK__([a-f0-9]{16})__(\d{1,3})__(\d{1,3})__([a-f0-9]{64})__(.+)$~D', $marker, $m)) {
            throw new InvalidArgumentException('Ungültige Segment-Markierung.');
        }
        $session = $m[1]; $index = (int) $m[2]; $count = (int) $m[3]; $expected_hash = $m[4];
        $name = sanitize_file_name($m[5]); $extension = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if ($count < 2 || $count > 64 || $index < 0 || $index >= $count) { throw new InvalidArgumentException('Ungültige Segmentnummerierung.'); }
        if (!in_array($extension, ['mp4','jpg','jpeg'], true)) { throw new InvalidArgumentException('Nur MP4/JPEG erlaubt.'); }
        if (strlen($base64) > 750000) { throw new InvalidArgumentException('Upload-Segment ist zu groß.'); }
        $bytes = base64_decode($base64, true);
        if ($bytes === false || $bytes === '' || strlen($bytes) > 550000) { throw new InvalidArgumentException('Ungültiges Upload-Segment.'); }

        $dir = trailingslashit(get_temp_dir()) . 'jssocial-chunks';
        if (!wp_mkdir_p($dir) || !is_dir($dir)) { throw new RuntimeException('Temporäres Upload-Verzeichnis konnte nicht angelegt werden.'); }
        $base = trailingslashit($dir) . 'jss-' . $session;
        $meta_path = $base . '.json'; $part_path = $base . '.' . $index . '.part';
        $meta = ['count'=>$count,'sha256'=>$expected_hash,'filename'=>$name,'created'=>time()];

        if (is_file($meta_path)) {
            $stored = json_decode((string) file_get_contents($meta_path), true);
            if (!is_array($stored) || (int)($stored['count']??0)!==$count || (string)($stored['sha256']??'')!==$expected_hash || (string)($stored['filename']??'')!==$name) {
                throw new InvalidArgumentException('Segment-Sitzung stimmt nicht mit dem begonnenen Upload überein.');
            }
        } elseif (file_put_contents($meta_path, wp_json_encode($meta), LOCK_EX) === false) {
            throw new RuntimeException('Segment-Sitzung konnte nicht gespeichert werden.');
        }

        if (is_file($part_path)) {
            if (!hash_equals(hash('sha256', $bytes), hash_file('sha256', $part_path))) { throw new InvalidArgumentException('Segment wurde bereits mit anderem Inhalt übertragen.'); }
        } elseif (file_put_contents($part_path, $bytes, LOCK_EX) === false) {
            throw new RuntimeException('Upload-Segment konnte nicht gespeichert werden.');
        }

        $received = 0; $total = 0;
        for ($i=0; $i<$count; $i++) {
            $p = $base . '.' . $i . '.part';
            if (is_file($p)) { $received++; $total += (int) filesize($p); }
        }
        if ($total > 12 * 1024 * 1024) { self::cleanup_chunks($base, $count); throw new InvalidArgumentException('Segmentierter Upload überschreitet 12 MB.'); }
        if ($received < $count) { return ['chunked'=>true,'complete'=>false,'received_parts'=>$received,'total_parts'=>$count,'filename'=>$name]; }

        $assembled = $base . '.assembled'; $out = fopen($assembled, 'wb');
        if (!$out) { throw new RuntimeException('Segmentdatei konnte nicht zusammengesetzt werden.'); }
        try {
            for ($i=0; $i<$count; $i++) {
                $p = $base . '.' . $i . '.part'; $in = fopen($p, 'rb');
                if (!$in) { throw new RuntimeException('Upload-Segment fehlt beim Zusammensetzen.'); }
                stream_copy_to_stream($in, $out); fclose($in);
            }
        } finally { fclose($out); }
        if (!is_file($assembled) || filesize($assembled) > 12 * 1024 * 1024 || !hash_equals($expected_hash, hash_file('sha256', $assembled))) {
            @unlink($assembled); self::cleanup_chunks($base, $count); throw new InvalidArgumentException('Segmentierter Upload stimmt nicht mit der erwarteten SHA-256 überein.');
        }
        $all = file_get_contents($assembled); @unlink($assembled); self::cleanup_chunks($base, $count);
        if ($all === false) { throw new RuntimeException('Zusammengesetzte Datei konnte nicht gelesen werden.'); }
        return self::upload($name, base64_encode($all));
    }

    private static function cleanup_chunks(string $base, int $count): void {
        @unlink($base . '.json');
        for ($i=0; $i<$count; $i++) { @unlink($base . '.' . $i . '.part'); }
    }
}
