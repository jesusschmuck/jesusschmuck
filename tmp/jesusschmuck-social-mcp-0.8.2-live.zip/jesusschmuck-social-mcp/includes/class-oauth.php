<?php
defined('ABSPATH') || exit;
/** Separate MCP OAuth server. Meta Facebook Login is an independent connection. */
final class JSSocial_OAuth {
    public static function register_routes(): void {
        foreach (['register','token'] as $action) { register_rest_route('jssocial/v1','/oauth/'.$action,['methods'=>'POST','permission_callback'=>'__return_true','callback'=>[self::class,$action]]); }
        register_rest_route('jssocial/v1','/oauth/metadata',['methods'=>'GET','permission_callback'=>'__return_true','callback'=>fn()=>self::response(self::metadata())]);
        register_rest_route('jssocial/v1','/oauth/resource',['methods'=>'GET','permission_callback'=>'__return_true','callback'=>fn()=>self::response(self::resource())]);
    }
    public static function metadata(): array {
        return ['issuer'=>rest_url('jssocial/v1/oauth'),'authorization_endpoint'=>admin_url('admin-post.php?action=jssocial_mcp_authorize'),'token_endpoint'=>rest_url('jssocial/v1/oauth/token'),'registration_endpoint'=>rest_url('jssocial/v1/oauth/register'),'response_types_supported'=>['code'],'grant_types_supported'=>['authorization_code','refresh_token'],'code_challenge_methods_supported'=>['S256'],'token_endpoint_auth_methods_supported'=>['none'],'scopes_supported'=>['social:manage','offline_access']];
    }
    public static function resource(): array { return ['resource'=>rest_url('jssocial/v1/mcp'),'authorization_servers'=>[rest_url('jssocial/v1/oauth')],'scopes_supported'=>['social:manage','offline_access'],'bearer_methods_supported'=>['header']]; }
    public static function resource_url(): string {
        $u=wp_parse_url(rest_url('jssocial/v1/mcp'));
        return $u['scheme'].'://'.$u['host'].(isset($u['port'])?':'.$u['port']:'').'/.well-known/oauth-protected-resource'.$u['path'];
    }
    public static function discovery(): void {
        $path=wp_parse_url($_SERVER['REQUEST_URI']??'',PHP_URL_PATH);
        $issuer_path=wp_parse_url(rest_url('jssocial/v1/oauth'),PHP_URL_PATH);
        $resource_path=wp_parse_url(rest_url('jssocial/v1/mcp'),PHP_URL_PATH);
        $data=null;
        if ($path==='/.well-known/oauth-authorization-server'.$issuer_path) { $data=self::metadata(); }
        if ($path==='/.well-known/oauth-protected-resource'.$resource_path) { $data=self::resource(); }
        if ($data!==null) { nocache_headers(); header('Content-Type: application/json; charset=utf-8'); echo wp_json_encode($data); exit; }
    }
    private static function response(array $body,int $code=200): WP_REST_Response { return new WP_REST_Response($body,$code,['Cache-Control'=>'no-store','Pragma'=>'no-cache']); }
    private static function limit(): void {
        if (!is_ssl()) { throw new RuntimeException('HTTPS erforderlich.'); }
        $k='jssocial_rl_'.hash('sha256',($_SERVER['REMOTE_ADDR']??'unknown').wp_salt());
        $n=(int)get_transient($k); if ($n>60) { throw new RuntimeException('Zu viele Anfragen. Später erneut versuchen.'); } set_transient($k,$n+1,MINUTE_IN_SECONDS);
    }
    public static function register(WP_REST_Request $r): WP_REST_Response {
        try {
            self::limit(); $a=$r->get_json_params(); $uris=$a['redirect_uris']??[];
            if (!is_array($uris)||!$uris||count($uris)>5) { throw new InvalidArgumentException('1–5 HTTPS- oder lokale Loopback-Redirect-URIs erforderlich.'); }
            foreach ($uris as $uri) {
                if (!self::valid_redirect_uri($uri)) { throw new InvalidArgumentException('Ungültige Redirect-URI: HTTPS oder HTTP mit 127.0.0.1 beziehungsweise [::1] erforderlich.'); }
            }
            if (isset($a['token_endpoint_auth_method'])&&$a['token_endpoint_auth_method']!=='none') { throw new InvalidArgumentException('Public client mit PKCE und token_endpoint_auth_method=none verwenden.'); }
            $id=bin2hex(random_bytes(24));
            $client=['client_id'=>$id,'client_name'=>mb_substr(sanitize_text_field($a['client_name']??'MCP-Client'),0,100),'redirect_uris'=>array_values($uris),'token_endpoint_auth_method'=>'none','grant_types'=>['authorization_code','refresh_token'],'response_types'=>['code']];
            set_transient('jssocial_client_'.$id,$client,90*DAY_IN_SECONDS);
            return self::response($client,201);
        } catch (Throwable $e) { return self::response(['error'=>'invalid_client_metadata','error_description'=>$e->getMessage()],400); }
    }
    /**
     * RFC 8252 section 7.3: native clients receive the code on a local HTTP
     * listener. Only literal loopback addresses qualify; never arbitrary HTTP,
     * localhost lookalikes, credentials, fragments or browser-ambiguous URIs.
     * The authorization endpoint and token endpoint themselves stay HTTPS.
     */
    private static function valid_redirect_uri($uri): bool {
        if (!is_string($uri) || $uri === '' || strlen($uri) > 2048
            || preg_match('~[\x00-\x20\x7f\\\\]~', $uri)
            || preg_match('~%(?![0-9a-fA-F]{2})~', $uri)) { return false; }
        $u = wp_parse_url($uri);
        if (!is_array($u) || empty($u['host']) || isset($u['user'])
            || isset($u['pass']) || isset($u['fragment'])
            || (isset($u['port']) && ($u['port'] < 1 || $u['port'] > 65535))) { return false; }
        if (($u['scheme'] ?? '') === 'https') { return filter_var($uri, FILTER_VALIDATE_URL) !== false; }
        return ($u['scheme'] ?? '') === 'http'
            && in_array($u['host'], ['127.0.0.1', '[::1]'], true)
            && filter_var($uri, FILTER_VALIDATE_URL) !== false;
    }
    /**
     * Match all registered URI components exactly, with ONLY the port exception
     * for literal HTTP loopback redirects required by RFC 8252. The actual URI
     * (including the selected port) is bound to consent/code and must then match
     * exactly again at token exchange; no port exception is applied there.
     */
    private static function redirect_matches($requested, array $registered): bool {
        if (!self::valid_redirect_uri($requested)) { return false; }
        if (in_array($requested, $registered, true)) { return true; }
        $requested_parts = wp_parse_url($requested);
        if (($requested_parts['scheme'] ?? '') !== 'http'
            || !in_array($requested_parts['host'] ?? '', ['127.0.0.1', '[::1]'], true)) { return false; }
        // Strip only a literal decimal port from the already validated authority.
        // Leave path/query, host spelling and escaping untouched for exact matching.
        $without_port = static fn(string $uri): string => preg_replace(
            '~\A(http://(?:127\.0\.0\.1|\[::1\]))(?::[0-9]+)?(?=[/?]|\z)~', '$1', $uri
        );
        foreach ($registered as $uri) {
            if (self::valid_redirect_uri($uri) && $without_port($uri) === $without_port($requested)) { return true; }
        }
        return false;
    }
    private static function auth_params(array $a): array {
        $id=(string)($a['client_id']??''); $client=get_transient('jssocial_client_'.$id);
        if (!$client || !self::redirect_matches($a['redirect_uri']??'', $client['redirect_uris'])) { throw new InvalidArgumentException('Unbekannter Client oder abweichende Redirect-URI.'); }
        if (($a['response_type']??'')!=='code'||($a['code_challenge_method']??'')!=='S256'||!preg_match('/^[A-Za-z0-9_-]{43}$/',(string)($a['code_challenge']??''))) { throw new InvalidArgumentException('Authorization Code mit PKCE S256 erforderlich.'); }
        if (($a['resource']??rest_url('jssocial/v1/mcp'))!==rest_url('jssocial/v1/mcp')) { throw new InvalidArgumentException('Falsche Resource.'); }
        $requested = preg_split('/\s+/', trim((string)($a['scope']??'')), -1, PREG_SPLIT_NO_EMPTY) ?: [];
        foreach ($requested as $scope) { if (!in_array($scope,['social:manage','offline_access'],true)) { throw new InvalidArgumentException('Unbekannter Scope.'); } }
        if ($requested && !in_array('social:manage',$requested,true)) { throw new InvalidArgumentException('Scope social:manage ist erforderlich.'); }
        $scope = 'social:manage offline_access';
        if (strlen((string)($a['state']??''))>2048) { throw new InvalidArgumentException('State zu lang.'); }
        return ['client_id'=>$id,'client_name'=>$client['client_name'],'redirect_uri'=>$a['redirect_uri'],'code_challenge'=>$a['code_challenge'],'scope'=>$scope,'resource'=>rest_url('jssocial/v1/mcp'),'state'=>(string)($a['state']??'')];
    }
    public static function login(): void {
        $uri=admin_url('admin-post.php').'?'.http_build_query(wp_unslash($_GET));
        wp_safe_redirect(wp_login_url($uri)); exit;
    }
    public static function authorize(): void {
        if (!current_user_can('manage_options')||!is_ssl()) { wp_die('Administrator und HTTPS erforderlich.'); }
        try { $a=self::auth_params(wp_unslash($_GET)); } catch (Throwable $e) { wp_die(esc_html($e->getMessage())); }
        $ticket=bin2hex(random_bytes(24)); $a['user_id']=get_current_user_id();
        set_transient('jssocial_consent_'.$ticket,$a,10*MINUTE_IN_SECONDS);
        nocache_headers(); header('Referrer-Policy: no-referrer');
        echo '<!doctype html><html lang="de"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Social MCP verbinden</title><body style="font:18px system-ui;max-width:680px;margin:60px auto;padding:24px"><h1>Jesusschmuck Social MCP verbinden</h1><p>Client: <strong>'.esc_html($a['client_name']).'</strong></p><p>Rückleitung: <code>'.esc_html($a['redirect_uri']).'</code></p><p>Dieser Client kann Social-Entwürfe und Medien verwalten und nach deiner ausdrücklichen Freigabe veröffentlichen oder planen. Meta-Zugangsdaten werden nicht an den Client gegeben.</p><p>Diese Verbindung ist keine Freigabe eines Beitrags.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        wp_nonce_field('jssocial_mcp_consent');
        echo '<input type="hidden" name="action" value="jssocial_mcp_consent"><input type="hidden" name="ticket" value="'.esc_attr($ticket).'"><button name="allow" value="yes">Diesen Client verbinden</button> <button name="allow" value="no">Abbrechen</button></form></body></html>'; exit;
    }
    public static function consent(): void {
        if (!current_user_can('manage_options')||!is_ssl()) { wp_die('Keine Berechtigung.'); } check_admin_referer('jssocial_mcp_consent');
        $ticket=sanitize_key(wp_unslash($_POST['ticket']??'')); $a=get_transient('jssocial_consent_'.$ticket); delete_transient('jssocial_consent_'.$ticket);
        if (!$a||$a['user_id']!==get_current_user_id()) { wp_die('Anfrage abgelaufen.'); }
        if (($_POST['allow']??'')==='yes') {
            $code=bin2hex(random_bytes(32)); $a['epoch']=(int)get_option('jssocial_oauth_epoch',0);
            set_transient('jssocial_code_'.hash('sha256',$code),$a,5*MINUTE_IN_SECONDS); $q=['code'=>$code,'state'=>$a['state']];
        } else { $q=['error'=>'access_denied','state'=>$a['state']]; }
        // Exact redirect previously validated against the registered client and displayed in consent.
        wp_redirect(add_query_arg($q,$a['redirect_uri'])); exit;
    }
    private static function issue(array $grant): array {
        $access=bin2hex(random_bytes(32)); $refresh=bin2hex(random_bytes(32));
        set_transient('jssocial_access_'.hash('sha256',$access),$grant,HOUR_IN_SECONDS);
        set_transient('jssocial_refresh_'.hash('sha256',$refresh),$grant,30*DAY_IN_SECONDS);
        return ['access_token'=>$access,'token_type'=>'Bearer','expires_in'=>HOUR_IN_SECONDS,'refresh_token'=>$refresh,'scope'=>(string)($grant['scope']??'social:manage offline_access')];
    }
    public static function token(WP_REST_Request $r): WP_REST_Response {
        try {
            self::limit(); $a=$r->get_body_params();
            $out=JSSocial_Store::lock(function () use ($a) {
                $refresh=($a['grant_type']??'')==='refresh_token';
                if (!$refresh&&($a['grant_type']??'')!=='authorization_code') { throw new InvalidArgumentException('Nicht unterstützter grant_type.'); }
                $raw=(string)($a[$refresh?'refresh_token':'code']??''); $key=($refresh?'jssocial_refresh_':'jssocial_code_').hash('sha256',$raw); $g=get_transient($key);
                if (!$g||!hash_equals($g['client_id'],(string)($a['client_id']??''))||!user_can($g['user_id'],'manage_options')||($g['epoch']??-1)!==(int)get_option('jssocial_oauth_epoch',0)) { throw new InvalidArgumentException('Grant ungültig, abgelaufen oder widerrufen.'); }
                if (isset($a['resource'])&&$a['resource']!==$g['resource']) { throw new InvalidArgumentException('Resource stimmt nicht überein.'); }
                if (!$refresh) {
                    $verifier=(string)($a['code_verifier']??'');
                    if (!preg_match('/^[A-Za-z0-9._~-]{43,128}$/',$verifier)||!hash_equals($g['code_challenge'],rtrim(strtr(base64_encode(hash('sha256',$verifier,true)),'+/','-_'),'='))||($a['redirect_uri']??'')!==$g['redirect_uri']) { throw new InvalidArgumentException('PKCE oder Redirect-URI stimmt nicht überein.'); }
                }
                delete_transient($key); return self::issue($g);
            });
            return self::response($out);
        } catch (Throwable $e) { return self::response(['error'=>'invalid_grant','error_description'=>$e->getMessage()],400); }
    }
    public static function grant(string $token): array {
        $g=get_transient('jssocial_access_'.hash('sha256',$token));
        if (!$g || ($g['epoch']??-1)!==(int)get_option('jssocial_oauth_epoch',0) || ($g['resource']??'')!==rest_url('jssocial/v1/mcp') || !user_can($g['user_id'],'manage_options')) { return []; }
        return $g;
    }
    public static function valid(string $token): bool { return (bool) self::grant($token); }
    public static function diagnostics(): array {
        global $wpdb;
        $current_epoch = (int) get_option('jssocial_oauth_epoch', 0);
        $resource = rest_url('jssocial/v1/mcp');
        $rows = [];
        foreach (['access', 'refresh'] as $type) {
            $prefix = '_transient_jssocial_' . $type . '_';
            $like = $wpdb->esc_like($prefix) . '%';
            $names = $wpdb->get_col($wpdb->prepare(
                "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s ORDER BY option_id DESC LIMIT 50",
                $like
            ));
            foreach ((array) $names as $option_name) {
                $key = substr((string) $option_name, strlen('_transient_'));
                $grant = get_transient($key);
                if (!is_array($grant)) { continue; }
                $uid = (int) ($grant['user_id'] ?? 0);
                $user = $uid > 0 ? get_userdata($uid) : false;
                $expires = (int) get_option('_transient_timeout_' . $key, 0);
                $epoch_matches = (int) ($grant['epoch'] ?? -1) === $current_epoch;
                $resource_matches = (string) ($grant['resource'] ?? '') === $resource;
                $admin = $uid > 0 && user_can($uid, 'manage_options');
                $rows[] = [
                    'type' => $type,
                    'client_name' => mb_substr(sanitize_text_field((string) ($grant['client_name'] ?? '')), 0, 100),
                    'user_id' => $uid,
                    'user_email' => $user ? sanitize_email((string) $user->user_email) : '',
                    'roles' => $user ? array_values((array) $user->roles) : [],
                    'manage_options' => $admin,
                    'epoch' => (int) ($grant['epoch'] ?? -1),
                    'epoch_matches' => $epoch_matches,
                    'resource_matches' => $resource_matches,
                    'expires_at_utc' => $expires > 0 ? gmdate('c', $expires) : null,
                    'valid_now' => $admin && $epoch_matches && $resource_matches && ($expires === 0 || $expires > time()),
                ];
            }
        }
        return [
            'available' => true,
            'current_epoch' => $current_epoch,
            'active_grant_count' => count($rows),
            'grants' => $rows,
            'note' => 'Sanitisierte Diagnose: keine OAuth-Tokens oder Token-Hashes enthalten.',
        ];
    }
}
