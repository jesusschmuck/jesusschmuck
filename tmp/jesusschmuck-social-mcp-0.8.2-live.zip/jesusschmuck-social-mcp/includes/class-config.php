<?php
defined('ABSPATH') || exit;
final class JSSocial_Config {
    private const SECRET_AAD = 'jssocial-v1';

    public static function app_id(): string {
        if (defined('JSSOCIAL_APP_ID') && JSSOCIAL_APP_ID) { return trim((string) JSSOCIAL_APP_ID); }
        return trim((string) get_option('jssocial_app_id', ''));
    }
    public static function app_secret(): string {
        if (defined('JSSOCIAL_APP_SECRET') && JSSOCIAL_APP_SECRET) { return (string) JSSOCIAL_APP_SECRET; }
        return self::read_secret_option('jssocial_app_secret');
    }
    public static function fb_config_id(): string {
        if (defined('JSSOCIAL_FB_CONFIG_ID') && JSSOCIAL_FB_CONFIG_ID) { return trim((string) JSSOCIAL_FB_CONFIG_ID); }
        return trim((string) get_option('jssocial_fb_config_id', ''));
    }
    public static function business_role_access(): bool {
        if (defined('JSSOCIAL_BUSINESS_ROLE_ACCESS')) { return (bool) JSSOCIAL_BUSINESS_ROLE_ACCESS; }
        return (bool) get_option('jssocial_business_role_access', false);
    }
    public static function product_tags_enabled(): bool {
        if (defined('JSSOCIAL_PRODUCT_TAGS')) { return (bool) JSSOCIAL_PRODUCT_TAGS; }
        return (bool) get_option('jssocial_product_tags', false);
    }
    public static function version(): string {
        $v = defined('JSSOCIAL_GRAPH_VERSION') && JSSOCIAL_GRAPH_VERSION ? (string) JSSOCIAL_GRAPH_VERSION : (string) get_option('jssocial_graph_version', 'v25.0');
        if (!preg_match('/^v[0-9]+\.0$/', $v)) { throw new RuntimeException('Ungültige Graph-API-Version.'); }
        return $v;
    }
    private static function key(): string {
        if (!function_exists('openssl_encrypt')) { throw new RuntimeException('PHP OpenSSL fehlt.'); }
        if (defined('JSSOCIAL_ENCRYPTION_KEY') && preg_match('/^[a-f0-9]{64}$/i', (string) JSSOCIAL_ENCRYPTION_KEY)) {
            return hex2bin((string) JSSOCIAL_ENCRYPTION_KEY);
        }
        if (!function_exists('wp_salt')) { throw new RuntimeException('WordPress-Sicherheitsschlüssel sind noch nicht verfügbar.'); }
        // Keine separate wp-config-Konstante mehr erforderlich. Der Schlüssel bleibt serverseitig
        // und wird deterministisch aus den vorhandenen WordPress-Salts abgeleitet.
        return hash_hmac('sha256', 'jesusschmuck-social|' . home_url(), wp_salt(), true);
    }
    private static function encrypt_secret(string $plain): string {
        if ($plain === '') { return ''; }
        $iv = random_bytes(12); $tag = '';
        $cipher = openssl_encrypt($plain, 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, $iv, $tag, self::SECRET_AAD);
        if ($cipher === false) { throw new RuntimeException('Verschlüsselung fehlgeschlagen.'); }
        return base64_encode($iv . $tag . $cipher);
    }
    private static function decrypt_secret(string $encoded): string {
        if ($encoded === '') { return ''; }
        $raw = base64_decode($encoded, true);
        if (!$raw || strlen($raw) < 29) { throw new RuntimeException('Geschützte Konfiguration ist beschädigt.'); }
        $plain = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16), self::SECRET_AAD);
        if ($plain === false) { throw new RuntimeException('Geschützte Konfiguration kann nicht entschlüsselt werden. WordPress-Salts/Schlüssel prüfen.'); }
        return $plain;
    }
    private static function read_secret_option(string $name): string {
        return self::decrypt_secret((string) get_option($name, ''));
    }
    private static function write_secret_option(string $name, string $plain): void {
        $encoded = self::encrypt_secret($plain);
        if ($encoded === '') { delete_option($name); return; }
        update_option($name, $encoded, false);
        if ((string) get_option($name, '') !== $encoded) { throw new RuntimeException('Geschützte Einstellung konnte nicht gespeichert werden.'); }
    }
    public static function configured(): bool {
        try { self::key(); return (bool) (self::app_id() && self::app_secret()); } catch (Throwable $e) { return false; }
    }
    public static function configuration_sources(): array {
        return [
            'app_id' => defined('JSSOCIAL_APP_ID') && JSSOCIAL_APP_ID ? 'wp-config' : (get_option('jssocial_app_id', '') !== '' ? 'wordpress' : 'missing'),
            'app_secret' => defined('JSSOCIAL_APP_SECRET') && JSSOCIAL_APP_SECRET ? 'wp-config' : (get_option('jssocial_app_secret', '') !== '' ? 'wordpress_encrypted' : 'missing'),
            'encryption_key' => defined('JSSOCIAL_ENCRYPTION_KEY') && preg_match('/^[a-f0-9]{64}$/i', (string) JSSOCIAL_ENCRYPTION_KEY) ? 'wp-config' : 'wordpress_salts',
            'graph_version' => defined('JSSOCIAL_GRAPH_VERSION') && JSSOCIAL_GRAPH_VERSION ? 'wp-config' : 'wordpress',
            'fb_config_id' => defined('JSSOCIAL_FB_CONFIG_ID') && JSSOCIAL_FB_CONFIG_ID ? 'wp-config' : (get_option('jssocial_fb_config_id', '') !== '' ? 'wordpress' : 'unset'),
            'business_role_access' => defined('JSSOCIAL_BUSINESS_ROLE_ACCESS') ? 'wp-config' : 'wordpress',
            'product_tags' => defined('JSSOCIAL_PRODUCT_TAGS') ? 'wp-config' : 'wordpress',
        ];
    }
    public static function editable_settings(): array {
        return [
            'app_id' => self::app_id(),
            'app_secret_present' => self::app_secret() !== '',
            'fb_config_id' => self::fb_config_id(),
            'graph_version' => self::version(),
            'business_role_access' => self::business_role_access(),
            'product_tags' => self::product_tags_enabled(),
            'sources' => self::configuration_sources(),
        ];
    }
    /** Save Meta app credentials from WordPress admin only. Empty secret keeps the current one. */
    public static function save_meta_settings(array $values): array {
        $old_id = self::app_id(); $old_secret = self::app_secret();
        $app_id = trim((string) ($values['app_id'] ?? $old_id));
        if ($app_id !== '' && !preg_match('/^[0-9]{5,40}$/', $app_id)) { throw new InvalidArgumentException('Meta-App-ID hat ein ungültiges Format.'); }
        $secret_supplied = array_key_exists('app_secret', $values) && (string) $values['app_secret'] !== '';
        $app_secret = $secret_supplied ? trim((string) $values['app_secret']) : $old_secret;
        if ($secret_supplied && (strlen($app_secret) < 16 || strlen($app_secret) > 200)) { throw new InvalidArgumentException('Meta-App-Secret hat ein ungültiges Format.'); }
        if (!defined('JSSOCIAL_APP_ID')) { $app_id === '' ? delete_option('jssocial_app_id') : update_option('jssocial_app_id', $app_id, false); }
        if (!defined('JSSOCIAL_APP_SECRET') && $secret_supplied) { self::write_secret_option('jssocial_app_secret', $app_secret); }
        self::save_operational_settings($values);
        $changed = ($old_id !== self::app_id()) || ($old_secret !== self::app_secret());
        if ($changed) {
            // Tokens belong to the Meta app they were minted for. Keep jobs/history, but require a clean reconnect.
            delete_option('jssocial_connection'); delete_option('jssocial_page'); delete_option('jssocial_verified');
        }
        return ['saved' => true, 'credentials_changed' => $changed, 'configured' => self::configured(), 'settings' => self::editable_settings()];
    }
    /** Operational, non-secret settings are safe to manage over MCP after administrator OAuth. */
    public static function save_operational_settings(array $values): array {
        if (array_key_exists('graph_version', $values) && !defined('JSSOCIAL_GRAPH_VERSION')) {
            $v = trim((string) $values['graph_version']); if (!preg_match('/^v[0-9]+\.0$/', $v)) { throw new InvalidArgumentException('Ungültige Graph-API-Version.'); } update_option('jssocial_graph_version', $v, false);
        }
        if (array_key_exists('fb_config_id', $values) && !defined('JSSOCIAL_FB_CONFIG_ID')) {
            $v = trim((string) $values['fb_config_id']); if (strlen($v) > 100 || ($v !== '' && !preg_match('/^[A-Za-z0-9_-]+$/', $v))) { throw new InvalidArgumentException('Ungültige Facebook-Login-Konfigurations-ID.'); }
            $v === '' ? delete_option('jssocial_fb_config_id') : update_option('jssocial_fb_config_id', $v, false);
        }
        foreach (['business_role_access' => 'JSSOCIAL_BUSINESS_ROLE_ACCESS', 'product_tags' => 'JSSOCIAL_PRODUCT_TAGS'] as $field => $constant) {
            if (array_key_exists($field, $values) && !defined($constant)) { update_option('jssocial_' . $field, (bool) $values[$field], false); }
        }
        delete_option('jssocial_verified');
        return ['saved' => true, 'settings' => self::editable_settings(), 'note' => 'wp-config-Konstanten haben weiterhin Vorrang und können per MCP nicht überschrieben werden.'];
    }
    public static function connection(): array {
        $encoded = get_option('jssocial_connection', '');
        if (!$encoded) { return []; }
        $plain = self::decrypt_secret((string) $encoded);
        return json_decode($plain, true, 512, JSON_THROW_ON_ERROR);
    }
    public static function save_connection(array $value): void {
        $encoded = self::encrypt_secret(wp_json_encode($value));
        update_option('jssocial_connection', $encoded, false);
        if (get_option('jssocial_connection') !== $encoded) { throw new RuntimeException('Verbindung konnte nicht gespeichert werden.'); }
    }
    public static function youtube_credentials(): array {
        return ['client_id' => (string) get_option('jssocial_youtube_client_id', ''), 'client_secret' => self::read_secret_option('jssocial_youtube_client_secret')];
    }
    public static function save_youtube_credentials(string $id, string $secret): void {
        $old = self::youtube_credentials();
        if (!preg_match('/^[A-Za-z0-9._-]+\.apps\.googleusercontent\.com$/D', $id) || strlen($id) > 250) { throw new InvalidArgumentException('Ungültige Google-Client-ID.'); }
        $secret_supplied = $secret !== '';
        $secret = $secret_supplied ? $secret : $old['client_secret'];
        if (strlen($secret) < 16 || strlen($secret) > 250 || preg_match('/[\s\x00-\x1f]/', $secret)) { throw new InvalidArgumentException('Ungültiger Google-Clientschlüssel.'); }
        self::write_secret_option('jssocial_youtube_client_secret', $secret);
        update_option('jssocial_youtube_client_id', $id, false);
        if ((string)get_option('jssocial_youtube_client_id', '') !== $id) { throw new RuntimeException('Google-Client-ID konnte nicht gespeichert werden.'); }
        if ($id !== $old['client_id'] || $secret !== $old['client_secret']) { delete_option('jssocial_youtube_connection'); }
    }
    public static function youtube_connection(): array {
        $value = self::read_secret_option('jssocial_youtube_connection');
        return $value === '' ? [] : json_decode($value, true, 32, JSON_THROW_ON_ERROR);
    }
    public static function save_youtube_connection(array $connection): void {
        self::write_secret_option('jssocial_youtube_connection', wp_json_encode($connection));
    }
    private static function clear_tiktok_credentials_cache(): void {
        // These options are non-autoloaded. Redis can retain a stale negative lookup
        // across requests even while the option exists in the database.
        wp_cache_delete('notoptions', 'options');
        foreach (['jssocial_tiktok_credentials_v2', 'jssocial_tiktok_client_key', 'jssocial_tiktok_client_secret'] as $name) {
            wp_cache_delete($name, 'options');
        }
    }
    public static function tiktok_credentials(): array {
        self::clear_tiktok_credentials_cache();
        $bundle = self::read_secret_option('jssocial_tiktok_credentials_v2');
        if ($bundle !== '') { return json_decode($bundle, true, 8, JSON_THROW_ON_ERROR); }
        return ['client_key' => (string) get_option('jssocial_tiktok_client_key', ''), 'client_secret' => self::read_secret_option('jssocial_tiktok_client_secret')];
    }
    public static function save_tiktok_credentials(string $id, string $secret): void {
        $old = self::tiktok_credentials();
        if (!preg_match('/^[A-Za-z0-9_-]{5,250}$/D', $id) || strlen($id) > 250) { throw new InvalidArgumentException('Ungültige TikTok-Client-ID.'); }
        $secret_supplied = $secret !== '';
        $secret = $secret_supplied ? $secret : $old['client_secret'];
        if (strlen($secret) < 16 || strlen($secret) > 250 || preg_match('/[\s\x00-\x1f]/', $secret)) { throw new InvalidArgumentException('Ungültiger TikTok-Clientschlüssel.'); }
        // One encrypted, verified write prevents partially saved credential pairs.
        self::write_secret_option('jssocial_tiktok_credentials_v2', wp_json_encode(['client_key' => $id, 'client_secret' => $secret]));
        $saved = self::tiktok_credentials();
        if ($saved['client_key'] !== $id || $saved['client_secret'] !== $secret) { throw new RuntimeException('TikTok-Zugangsdaten konnten nicht vollständig gespeichert werden.'); }
        if ($id !== $old['client_key'] || $secret !== $old['client_secret']) { delete_option('jssocial_tiktok_connection'); }
    }
    public static function tiktok_connection(): array {
        wp_cache_delete('notoptions', 'options'); wp_cache_delete('jssocial_tiktok_connection', 'options');
        $value = self::read_secret_option('jssocial_tiktok_connection');
        return $value === '' ? [] : json_decode($value, true, 32, JSON_THROW_ON_ERROR);
    }
    public static function save_tiktok_connection(array $connection): void {
        self::write_secret_option('jssocial_tiktok_connection', wp_json_encode($connection));
    }
    public static function tiktok_operation(string $id, ?array $value = null): array {
        if (!preg_match('/^[a-f0-9]{64}$/D', $id)) { throw new InvalidArgumentException('Ungültige TikTok-Auftrags-ID.'); }
        $key='jssocial_tt_op_'.$id;
        wp_cache_delete('notoptions','options'); wp_cache_delete($key,'options');
        if ($value !== null) {
            self::write_secret_option($key,wp_json_encode($value));
            // Cache success is insufficient before uploads: confirm durable DB storage.
            global $wpdb;
            $raw=(string)$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name = %s",$key));
            if (self::decrypt_secret($raw)!==wp_json_encode($value)) { throw new RuntimeException('TikTok-Auftrag nicht dauerhaft gespeichert. Keine weitere Übertragung.'); }
        }
        $plain=self::read_secret_option($key);
        return $plain===''?[]:json_decode($plain,true,32,JSON_THROW_ON_ERROR);
    }
    public static function youtube_operation(string $id, ?array $value = null): array {
        if (!preg_match('/^[a-f0-9]{64}$/', $id)) { throw new InvalidArgumentException('Ungültige YouTube-Auftrags-ID.'); }
        $key = 'jssocial_yt_op_'.$id;
        if ($value !== null) { self::write_secret_option($key, wp_json_encode($value)); }
        return json_decode(self::read_secret_option($key), true) ?: [];
    }
    public static function scopes(): array {
        $s = ['pages_show_list', 'pages_read_engagement', 'pages_manage_posts', 'instagram_basic', 'instagram_content_publish'];
        if (self::business_role_access()) { $s[] = 'ads_read'; }
        if (self::product_tags_enabled()) { $s = array_merge($s, ['catalog_management', 'instagram_shopping_tag_products']); }
        return array_values(array_unique($s));
    }
    public static function callback(): string { return admin_url('admin-post.php?action=jssocial_oauth'); }
    public static function selected(): array {
        $c = self::connection(); $id = get_option('jssocial_page', '');
        foreach ($c['pages'] ?? [] as $page) { if ((string) ($page['id'] ?? '') === (string) $id) { return $page; } }
        throw new RuntimeException('Noch keine Facebook-Seite als Ziel ausgewählt.');
    }
    public static function available_targets(): array {
        $c = self::connection(); $selected = (string) get_option('jssocial_page', ''); $out = [];
        foreach ($c['pages'] ?? [] as $p) {
            if (empty($p['id'])) { continue; }
            $out[] = [
                'facebook_id' => (string) $p['id'], 'facebook_name' => (string) ($p['name'] ?? ''),
                'instagram_id' => (string) ($p['instagram_business_account']['id'] ?? ''),
                'instagram_username' => (string) ($p['instagram_business_account']['username'] ?? ''),
                'selected' => (string) $p['id'] === $selected,
            ];
        }
        return $out;
    }
    public static function select_target(string $page_id): array {
        $page_id = trim($page_id); if ($page_id === '') { throw new InvalidArgumentException('page_id fehlt.'); }
        $ids = array_column(self::available_targets(), 'facebook_id');
        if (!in_array($page_id, $ids, true)) { throw new RuntimeException('Diese Facebook-Seite gehört nicht zur verbundenen Meta-Auswahl.'); }
        update_option('jssocial_page', $page_id, false); delete_option('jssocial_verified');
        return ['saved' => true, 'selected_page_id' => $page_id, 'targets' => self::targets()];
    }
    public static function targets(): array {
        $p = self::selected();
        return ['facebook' => ['id' => $p['id'], 'name' => $p['name']], 'instagram' => ['id' => $p['instagram_business_account']['id'] ?? '', 'name' => $p['instagram_business_account']['username'] ?? 'Nicht verbunden']];
    }
    public static function setup_steps(): array {
        $steps = [];
        if (!self::configured()) { $steps[] = ['owner' => 'user', 'action' => 'Meta-App-ID und Meta-App-Secret einmalig unter Jesusschmuck Social → Verbindungen speichern. Das Secret nicht im Chat senden.']; }
        $c = [];
        try { $c = self::connection(); } catch (Throwable $e) { $steps[] = ['owner' => 'user', 'action' => 'Geschützte Meta-Konfiguration prüfen: ' . $e->getMessage()]; }
        if (self::configured() && empty($c['user_token'])) { $steps[] = ['owner' => 'user', 'action' => 'Facebook/Meta einmal im WordPress-Dialog autorisieren.']; }
        if (!empty($c['user_token']) && !array_filter(self::available_targets(), fn($t) => $t['selected'])) { $steps[] = ['owner' => 'assistant', 'action' => 'Zielseite über js_social_select_target setzen.']; }
        try { $worker = JSSocial_Worker::health(); if (empty($worker['healthy'])) { $steps[] = ['owner' => 'hosting', 'action' => 'Server-Cron/CLI-Runner prüfen, bis der Worker regelmäßig als gesund erkannt wird.']; } } catch (Throwable $e) { $steps[] = ['owner' => 'hosting', 'action' => 'Worker prüfen: ' . $e->getMessage()]; }
        return $steps;
    }
    public static function public_status(): array {
        $out = [
            'version' => JSSOCIAL_VERSION, 'configured' => self::configured(), 'configuration' => self::editable_settings(),
            'timezone' => 'Europe/Berlin', 'graph_version' => self::version(), 'mcp_endpoint' => rest_url('jssocial/v1/mcp'),
            'mcp_authentication' => 'private-url-token',
            'worker' => JSSocial_Worker::health(), 'connected' => false,
        ];
        try {
            $c = self::connection(); $out['connected'] = !empty($c['user_token']);
            $out['token_expires_at'] = !empty($c['expires_at']) ? gmdate('c', $c['expires_at']) : null;
            $out['token_expires_at_note'] = 'Gespeicherter Benutzer-Login-Ablauf, nicht der Seitenzugang. Null bedeutet unbekannt. Aktuelle plattformspezifische Prüfung unter verification.token_health.';
            $out['granted_permissions'] = $c['permissions'] ?? [];
            $out['available_targets'] = self::available_targets();
            try { $out['targets'] = self::targets(); } catch (Throwable $e) { $out['target_message'] = $e->getMessage(); }
            $out['verification'] = get_option('jssocial_verified', []);
        } catch (Throwable $e) { $out['setup_message'] = $e->getMessage(); }
        $out['setup_steps'] = self::setup_steps();
        try { $out['mcp_oauth_diagnostics'] = JSSocial_OAuth::diagnostics(); }
        catch (Throwable $e) { $out['mcp_oauth_diagnostics'] = ['available' => false, 'message' => 'OAuth-Diagnose konnte nicht gelesen werden.']; }
        $out['youtube'] = JSSocial_YouTube::status();
        $out['tiktok'] = JSSocial_TikTok::status();
        $out['audio'] = ['instagram' => 'API implementiert; Verfügbarkeit durch Suche mit verbundenem Konto prüfen.', 'facebook' => 'Keine Übernahme des Instagram-API-Titels. Nur Ton der hochgeladenen Datei.', 'mixed_preview' => false, 'commercial_rights' => 'Titelverfügbarkeit und is_ads_eligible sind keine pauschale Lizenz für kommerzielle Nutzung.'];
        $out['limitations'] = ['Ein Facebook-Seiten-/Instagram-Kontopaar pro Installation.', 'Einzelbilder (JPEG) und Reels; keine Karussells oder Stories.', 'Facebook-Cover, Facebook-Produktmarkierungen und Business-Suite-Effekte werden nicht übertragen.'];
        return $out;
    }
}
