<?php
defined('ABSPATH') || exit;
final class JSSocial_Admin {
    public static function enqueue(): void {
        wp_enqueue_media();
        wp_enqueue_style('jssocial',plugins_url('../assets/admin.css',__FILE__),[],JSSOCIAL_VERSION);
        wp_enqueue_script('jssocial',plugins_url('../assets/admin.js',__FILE__),['jquery','media-views'],JSSOCIAL_VERSION,true);
    }
    private static function guard(): void { if (!current_user_can('manage_options')||!is_ssl()) { wp_die('Administrator-Berechtigung und HTTPS erforderlich.'); } }
    private static function flash(string $message): void { set_transient('jssocial_flash_'.get_current_user_id(),$message,60); }
    private static function redirect(string $tab='queue',int $id=0): void { wp_safe_redirect(add_query_arg(array_filter(['page'=>'jssocial','tab'=>$tab,'job'=>$id]),admin_url('admin.php'))); exit; }
    private static function start(string $op): void {
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">'; wp_nonce_field('jssocial_action');
        echo '<input type="hidden" name="action" value="jssocial_action"><input type="hidden" name="op" value="'.esc_attr($op).'">';
    }
    private static function hidden(string $k,$v): void { echo '<input type="hidden" name="'.esc_attr($k).'" value="'.esc_attr((string)$v).'">'; }
    public static function action(): void {
        self::guard(); check_admin_referer('jssocial_action'); $a=wp_unslash($_POST); $op=$a['op']??''; $id=(int)($a['job_id']??0); $tab='queue';
        try {
            switch ($op) {
                case 'save_settings':
                    $settings=[
                        'app_id'=>(string)($a['app_id']??''),
                        'app_secret'=>(string)($a['app_secret']??''),
                        'fb_config_id'=>(string)($a['fb_config_id']??''),
                        'graph_version'=>(string)($a['graph_version']??'v25.0'),
                        'business_role_access'=>!empty($a['business_role_access']),
                        'product_tags'=>!empty($a['product_tags_enabled']),
                    ];
                    $out=JSSocial_Config::save_meta_settings($settings);
                    self::flash('Einstellungen gespeichert.'.($out['credentials_changed']?' Die Meta-Verbindung wurde wegen geänderter App-Zugangsdaten getrennt und muss neu autorisiert werden.':''));
                    $tab='setup'; break;
                case 'connect':
                    if (!JSSocial_Config::configured()) { throw new RuntimeException('Meta App-ID und App-Secret zuerst unter Jesusschmuck Social → Verbindungen speichern.'); }
                    $state=bin2hex(random_bytes(32)); set_transient('jssocial_fb_state_'.get_current_user_id(),hash('sha256',$state),10*MINUTE_IN_SECONDS);
                    $q=['client_id'=>JSSocial_Config::app_id(),'redirect_uri'=>JSSocial_Config::callback(),'response_type'=>'code','state'=>$state,'scope'=>implode(',',JSSocial_Config::scopes())];
                    if (JSSocial_Config::fb_config_id()) { $q['config_id']=JSSocial_Config::fb_config_id(); }
                    wp_redirect(add_query_arg($q,'https://www.facebook.com/'.JSSocial_Config::version().'/dialog/oauth')); exit;
                case 'disconnect':
                    delete_option('jssocial_connection'); delete_option('jssocial_verified'); self::flash('Meta-Verbindung lokal entfernt. Offene Jobs werden vor Veröffentlichung angehalten.'); $tab='setup'; break;
                case 'select':
                    $c=JSSocial_Config::connection(); $selected=(string)($a['page_id']??'');
                    if (!in_array($selected,array_column($c['pages']??[],'id'),true)) { throw new RuntimeException('Seite gehört nicht zur verbundenen Auswahl.'); }
                    update_option('jssocial_page',$selected,false); delete_option('jssocial_verified'); self::flash('Zielseite gewählt. Bestehende Jobs bleiben an ihre alten Ziel-IDs gebunden.'); $tab='setup'; break;
                case 'verify':
                    $out=(new JSSocial_Meta())->verify(); self::flash('Kontoprüfung: Facebook '.($out['facebook_ready']?'bereit':'nicht bereit').', Instagram '.($out['instagram_ready']?'bereit':'nicht bereit').'. Fehlende Rechte: '.implode(', ',$out['missing_permissions'])); $tab='setup'; break;
                case 'mcp_regenerate':
                    JSSocial_MCP::regenerate_token(); self::flash('Private MCP-Adresse erneuert.'); $tab='setup'; break;
                case 'mcp_revoke_oauth':
                    update_option('jssocial_oauth_epoch',(int)get_option('jssocial_oauth_epoch',0)+1,false); self::flash('Alle MCP-OAuth-Zugänge widerrufen.'); $tab='setup'; break;
                case 'create':
                    $args=['request_key'=>(string)$a['request_key'],'attachment_id'=>(int)($a['attachment_id']??0),'kind'=>$a['kind']??'reel','platforms'=>$a['platforms']??[],'instagram_caption'=>$a['instagram_caption']??'','facebook_caption'=>$a['facebook_caption']??'','product_url'=>$a['product_url']??'','campaign'=>$a['campaign']??'schmuck-der-woche','local_datetime'=>$a['local_datetime']??'','utc_offset'=>$a['utc_offset']??'','share_to_feed'=>isset($a['share_to_feed'])];
                    if (!empty($a['cover_id'])) { $args['cover_id']=(int)$a['cover_id']; }
                    if (isset($a['thumb_offset'])&&$a['thumb_offset']!=='') { $args['thumb_offset']=(int)$a['thumb_offset']; }
                    if (!empty($a['facebook_attachment_id'])) { $args['facebook_attachment_id']=(int)$a['facebook_attachment_id']; $args['facebook_audio_rights']=['rights_confirmed'=>isset($a['facebook_rights_confirmed']),'rights_basis'=>$a['facebook_rights_basis']??'']; }
                    if (!empty($a['audio_id'])) { $args['audio']=['audio_id'=>$a['audio_id'],'audio_volume'=>(int)($a['audio_volume']??100),'video_volume'=>(int)($a['video_volume']??100),'rights_confirmed'=>isset($a['rights_confirmed']),'rights_basis'=>$a['rights_basis']??'']; }
                    if (!empty($a['product_tags'])) { $args['product_tags']=json_decode($a['product_tags'],true,16,JSON_THROW_ON_ERROR); }
                    $j=JSSocial_Service::create($args); $id=$j['id']; self::flash('Entwurf gespeichert. Bitte vollständige Vorschau prüfen. Noch keine Freigabe.'); break;
                case 'approve':
                    if (empty($a['explicit_approval'])) { throw new RuntimeException('Ausdrückliche Freigabe bitte bestätigen.'); }
                    JSSocial_Service::approve($id,$a['preview_hash']??'',$a['confirmation']??'','Ausdrückliche WordPress-Freigabe durch Administrator '.get_current_user_id().' nach Vorschau.'); self::flash('Freigegeben. Der Server-Worker führt den Beitrag zum angezeigten Termin aus.'); break;
                case 'cancel': JSSocial_Service::cancel($id,$a['preview_hash']??''); self::flash('Weitere Verarbeitung storniert. Bereits gesendete Anfragen und veröffentlichte Beiträge können bestehen bleiben.'); break;
                case 'reschedule': JSSocial_Service::reschedule($id,$a['preview_hash']??'',$a['local_datetime']??'',$a['utc_offset']??''); self::flash('Alter Termin aufgehoben. Neuen Termin bitte in der Vorschau freigeben.'); break;
                case 'retry': JSSocial_Service::retry($id,$a['platform']??''); self::flash('Sicherer Neuversuch für die ausgewählte Plattform vorgemerkt.'); break;
                case 'reconcile': JSSocial_Worker::reconcile($id); self::flash('Meta-Status erneut abgefragt.'); break;
                case 'audio':
                    $out=(new JSSocial_Meta())->audio(trim($a['query']??''),$a['audio_type']??'music'); set_transient('jssocial_audio_'.get_current_user_id(),$out,20*MINUTE_IN_SECONDS); $tab='audio'; self::flash('Audio-Katalog für das verbundene Instagram-Konto abgerufen.'); break;
                default: throw new InvalidArgumentException('Unbekannte Aktion.');
            }
        } catch (Throwable $e) { self::flash('Hinweis: '.$e->getMessage()); $tab=in_array($op,['save_settings','connect','select','verify','disconnect','mcp_regenerate','mcp_revoke_oauth'],true)?'setup':($op==='audio'?'audio':'queue'); }
        self::redirect($tab,$id);
    }
    public static function oauth(): void {
        self::guard();
        try {
            $state=(string)($_GET['state']??''); $expected=get_transient('jssocial_fb_state_'.get_current_user_id()); delete_transient('jssocial_fb_state_'.get_current_user_id());
            if (!$expected||!hash_equals($expected,hash('sha256',$state))) { throw new RuntimeException('Login-Anfrage abgelaufen oder ungültig.'); }
            $code=(string)($_GET['code']??''); if (!$code) { throw new RuntimeException('Facebook Login abgebrochen oder nicht genehmigt.'); }
            $api=new JSSocial_Meta();
            $t=$api->request('GET','oauth/access_token',['client_id'=>JSSocial_Config::app_id(),'client_secret'=>JSSocial_Config::app_secret(),'redirect_uri'=>JSSocial_Config::callback(),'code'=>$code]);
            if (empty($t['access_token'])) { throw new RuntimeException('Facebook hat keinen User-Zugriff erteilt.'); }
            $t=$api->request('GET','oauth/access_token',['grant_type'=>'fb_exchange_token','client_id'=>JSSocial_Config::app_id(),'client_secret'=>JSSocial_Config::app_secret(),'fb_exchange_token'=>$t['access_token']]);
            if (empty($t['access_token'])) { throw new RuntimeException('Langlebiger Meta-Zugriff konnte nicht eingerichtet werden.'); }
            $token=$t['access_token']; $pages=[]; $after='';
            for ($i=0;$i<10;$i++) {
                $q=['fields'=>'id,name,access_token,tasks,instagram_business_account{id,username}','limit'=>100]; if ($after) { $q['after']=$after; }
                $r=$api->request('GET','me/accounts',$q,$token); $pages=array_merge($pages,$r['data']??[]);
                if (empty($r['paging']['next'])) { $after=''; break; } $after=$r['paging']['cursors']['after']??''; if (!$after) { throw new RuntimeException('Seitenliste konnte nicht vollständig geladen werden.'); }
            }
            if ($after) { throw new RuntimeException('Zu viele Seiten. Meta-App-Auswahl auf relevante Seiten eingrenzen.'); }
            $pages=array_values(array_filter($pages,fn($p)=>!empty($p['id'])&&!empty($p['access_token'])));
            $perm=$api->request('GET','me/permissions',[],$token);
            $permissions=array_column(array_filter($perm['data']??[],fn($p)=>($p['status']??'')==='granted'),'permission');
            JSSocial_Config::save_connection(['user_token'=>$token,'expires_at'=>!empty($t['expires_in'])?time()+(int)$t['expires_in']:0,'permissions'=>$permissions,'pages'=>$pages,'connected_at'=>time()]);
            delete_option('jssocial_verified'); self::flash('Facebook Login verbunden. Jetzt die konkrete Zielseite auswählen und Konten prüfen.');
        } catch (Throwable $e) { self::flash('Verbindung nicht abgeschlossen: '.$e->getMessage()); }
        self::redirect('setup');
    }
    private static function field(string $label,string $name,string $type='text',string $value=''): void { echo '<label class="jss-field">'.esc_html($label).'<input type="'.esc_attr($type).'" name="'.esc_attr($name).'" id="'.esc_attr($name).'" value="'.esc_attr($value).'"></label>'; }
    private static function date_fields(): void {
        self::field('Datum und Uhrzeit · Europe/Berlin (leer = sofort)','local_datetime','datetime-local');
        echo '<label class="jss-field">Sommer-/Winterzeit<select name="utc_offset"><option value="">Automatisch</option><option value="+02:00">+02:00 · Sommerzeit</option><option value="+01:00">+01:00 · Winterzeit</option></select></label><p class="description">Auch später am heutigen Tag möglich. Bei der doppelt vorkommenden Herbst-Uhrzeit bitte die gewünschte Abweichung auswählen.</p>';
    }
    public static function render(): void {
        if (!current_user_can('manage_options')) { return; }
        $tab=sanitize_key($_GET['tab']??'queue'); $job=(int)($_GET['job']??0);
        echo '<div class="wrap jss"><div class="jss-heading"><div><span class="jss-eyebrow">JESUSSCHMUCK.COM</span><h1>Social Studio</h1><p>Ein Inhalt. Zwei Plattformen. Deine Freigabe.</p></div><span class="jss-badge">Version '.esc_html(JSSOCIAL_VERSION).'</span></div>';
        $flash=get_transient('jssocial_flash_'.get_current_user_id()); if ($flash) { delete_transient('jssocial_flash_'.get_current_user_id()); echo '<div class="notice notice-info"><p>'.esc_html($flash).'</p></div>'; }
        echo '<nav class="nav-tab-wrapper">'; foreach (['queue'=>'Beiträge & Termine','compose'=>'Neuer Entwurf','audio'=>'Instagram Audio','setup'=>'Verbindungen'] as $k=>$label) { echo '<a class="nav-tab '.($tab===$k?'nav-tab-active':'').'" href="'.esc_url(admin_url('admin.php?page=jssocial&tab='.$k)).'">'.esc_html($label).'</a>'; } echo '</nav>';
        try {
            if ($job) { self::review(JSSocial_Service::preview(JSSocial_Store::get($job))); }
            elseif ($tab==='setup') { self::setup(); }
            elseif ($tab==='compose') { self::compose(); }
            elseif ($tab==='audio') { self::audio(); }
            else { self::queue(); }
        } catch (Throwable $e) { echo '<div class="jss-card"><p>'.esc_html($e->getMessage()).'</p><a href="'.esc_url(admin_url('admin.php?page=jssocial&tab=setup')).'">Verbindungen einrichten</a></div>'; }
        echo '</div>';
    }
    private static function setup(): void {
        $status=JSSocial_Config::public_status();
        $settings=JSSocial_Config::editable_settings();
        echo '<div class="jss-grid"><section class="jss-card"><h2>1 · Meta über Facebook Login</h2><p>Ein Instagram-Business-/Creator-Konto mit verbundener Facebook-Seite wird benötigt. Private Facebook-Profile sind kein Veröffentlichungsziel.</p><p>Geschützte Konfiguration: <strong>'.($status['configured']?'vorhanden':'fehlt noch').'</strong></p>';
        self::start('save_settings');
        self::field('Meta App-ID','app_id','text',$settings['app_id']);
        echo '<label class="jss-field">Meta App-Secret<input type="password" name="app_secret" value="" autocomplete="new-password" placeholder="'.($settings['app_secret_present']?'Gespeichert – leer lassen zum Beibehalten':'Einmalig hier eintragen').'"></label>';
        self::field('Facebook Login Config-ID (optional)','fb_config_id','text',$settings['fb_config_id']);
        self::field('Meta Graph API Version','graph_version','text',$settings['graph_version']);
        echo '<p><label><input type="checkbox" name="business_role_access" value="1" '.checked($settings['business_role_access'],true,false).'> Zusätzliche Business-Rollen-Prüfung (<code>ads_read</code>) aktivieren</label></p>';
        echo '<p><label><input type="checkbox" name="product_tags_enabled" value="1" '.checked($settings['product_tags'],true,false).'> Instagram-Produktmarkierungen aktivieren</label></p>';
        echo '<p class="description">App-Secret wird verschlüsselt gespeichert. Ein eigener Verschlüsselungsschlüssel in <code>wp-config.php</code> ist nicht mehr nötig; vorhandene Konstanten bleiben aus Kompatibilitätsgründen vorrangig. Secret nicht im Chat senden.</p><p><button class="button">Meta-Konfiguration speichern</button></p></form>';
        echo '<p>Facebook-Redirect-URI:</p><code class="jss-url">'.esc_html(JSSocial_Config::callback()).'</code>';
        self::start('connect'); echo '<p><button class="button button-primary">Mit Facebook verbinden / erneuern</button></p></form>';
        $c=JSSocial_Config::connection();
        if (!empty($c['pages'])) {
            self::start('select'); echo '<label>Zielseite <select name="page_id">';
            foreach ($c['pages'] as $p) { echo '<option value="'.esc_attr($p['id']).'" '.selected(get_option('jssocial_page',''),$p['id'],false).'>'.esc_html($p['name'].' · '.($p['instagram_business_account']['username']??'kein Instagram')).'</option>'; }
            echo '</select></label> <button class="button">Ziel speichern</button></form>';
            self::start('verify'); echo '<p><button class="button">Konten und Berechtigungen prüfen</button></p></form>';
            self::start('disconnect'); echo '<button class="button">Meta-Verbindung entfernen</button></form>';
        }
        echo '<p>Gespeicherter Benutzer-Login-Ablauf: '.esc_html($status['token_expires_at']??'unbekannt').'</p><p>Dies ist nicht der Ablauf des Seitenzugangs. Konten prüfen ermittelt die aktuelle Gültigkeit getrennt bei Meta; kein gemeldetes Ablaufdatum ist nicht automatisch unbegrenzte Gültigkeit.</p>';
        foreach (($status['verification']['token_health'] ?? []) as $kind => $health) {
            $label = $kind === 'page' ? 'Facebook-Seitenzugang' : 'Instagram-Benutzerzugang';
            $expiry = ($health['expiry_status'] ?? 'unknown') === 'no_fixed_expiry' ? 'kein festes Ablaufdatum von Meta gemeldet' : (!empty($health['expires_at']) ? gmdate('c', $health['expires_at']) : 'unbekannt');
            echo '<p>'.esc_html($label.': '.(!empty($health['valid'])?'gültig':'ungültig').' · '.$expiry.' · geprüft '.gmdate('c', $health['checked_at'])).'</p>';
        }
        echo '<p>Eine Shop-/Katalog-Verbindung erteilt nicht automatisch Publishing-Rechte.</p></section>';
        JSSocial_YouTube::render_setup();
        JSSocial_TikTok::render_setup();
        $worker=$status['worker'];
        echo '<section class="jss-card"><h2>2 · Server-Zeitsteuerung</h2><p class="jss-status">'.($worker['healthy']?'Worker läuft regelmäßig':'Worker noch nicht nachgewiesen').'</p><p>Letzte Timer-Prüfung: '.esc_html($worker['last_run_utc']??'noch keine').'<br>Letzter vollständiger Runner-Lauf: '.esc_html($worker['last_full_run_utc']??'noch keiner').'<br>Nächste Arbeit (UTC): '.esc_html($worker['next_work_utc']??'keine bekannt').'</p><p>Der leichte Runner wird jede Minute gestartet. Im Leerlauf liest und aktualisiert er nur eine kleine lokale Statusdatei. WordPress startet erst bei fälliger Arbeit oder zur stündlichen Kontrollprüfung. Zwei regelmäßige erfolgreiche Prüfungen sind vor einer Freigabe erforderlich.</p><pre>'.esc_html('/PFAD/ZUR/PHP-CLI '.escapeshellarg(JSSOCIAL_DIR.'runner.php').' '.escapeshellarg(ABSPATH.'wp-load.php')).'</pre><p>Diese WordPress-Pfade sind bereits eingesetzt. Das Hosting muss den PHP-CLI-Pfad bestätigen und den Cronjob unter demselben Systembenutzer wie die Website einrichten. Laufzeitdaten liegen außerhalb des Pluginordners unter <code>wp-content/jssocial-runtime-…</code>.</p><p>Die Alternative <code>wp jssocial tick</code> lädt WordPress bei jedem Aufruf; für geringe Last den oben gezeigten Runner verwenden. Nur einen Cronjob einrichten.</p>';
        if (!empty($worker['last_runner_failed'])) { echo '<p><strong>Der letzte Runner-Aufruf ist fehlgeschlagen.</strong> Cron-Fehlerprotokoll, PHP-CLI und Dateirechte prüfen.</p>'; }
        echo '<p>Der Versand beginnt beim nächsten fälligen Worker-Lauf. Meta-Verarbeitung kann anschließend mehrere Minuten dauern. Serverausfälle können Veröffentlichungen verzögern.</p></section>';
        $private_mcp = JSSocial_MCP::private_url();
        echo '<section class="jss-card"><h2>3 · Eigene MCP-Anbindung</h2><p>Diese Verbindung ist vollständig getrennt vom Jesusschmuck Produktkatalog.</p><p><strong>Für ChatGPT Sites/Web:</strong> <code>'.esc_html(rest_url('jssocial/v1/mcp')).'</code> verwenden. OAuth 2.0 + PKCE wird automatisch erkannt; keine Zugangsdaten in den Chat schreiben.</p>'; self::start('mcp_revoke_oauth'); echo '<button class="button">MCP-OAuth-Zugänge widerrufen</button></form><hr>';
        echo '<label class="jss-field">Private MCP-Adresse<input id="jss-mcp-url" type="password" class="large-text code" readonly value="'.esc_attr($private_mcp).'"></label>';
        echo '<p><button type="button" class="button" id="jss-mcp-copy">Adresse kopieren</button></p>';
        echo '<p class="description">Wie ein Passwort behandeln. Die vollständige Adresse ausschließlich in ChatGPT → Einstellungen → Plugins → MCPs → Server hinzufügen bzw. beim Aktualisieren dieser Social-Verbindung eintragen; nicht im Chat posten.</p>';
        self::start('mcp_regenerate'); echo '<button class="button" onclick="return confirm(\'Die bisherige ChatGPT-Social-Verbindung wird damit ungültig. Wirklich erneuern?\')">Private Adresse erneuern</button></form>';
        echo '<script>(function(){const i=document.getElementById("jss-mcp-url"),b=document.getElementById("jss-mcp-copy");if(!i||!b)return;b.addEventListener("click",async function(){i.type="text";i.select();try{await navigator.clipboard.writeText(i.value);}catch(e){document.execCommand("copy");}b.textContent="Kopiert";setTimeout(function(){i.type="password";b.textContent="Adresse kopieren";},2000);});})();</script></section>';
        echo '<section class="jss-card"><h2>Verfügbarkeit</h2><pre>'.esc_html(wp_json_encode($status,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)).'</pre><p>Audio-Katalog, Produktmarkierungen und tatsächliche Veröffentlichungsrechte sind erst nach Kontoprüfung bzw. Live-Test bestätigt.</p></section></div>';
    }
    private static function compose(): void {
        $targets=JSSocial_Config::targets();
        echo '<section class="jss-card"><h2>Unverbindlichen Entwurf vorbereiten</h2>'; self::start('create'); self::hidden('request_key',wp_generate_uuid4());
        echo '<div class="jss-grid"><div><label class="jss-field">Format<select name="kind"><option value="reel">Reel · MP4</option><option value="image">Bildbeitrag · JPEG</option></select></label>';
        self::field('Mediendatei · WordPress-ID','attachment_id','number'); echo '<button type="button" class="button jss-media" data-target="attachment_id">Eine Datei auswählen oder hochladen</button><p class="description">Diese Datei wird für beide Plattformen verwendet.</p>';
        echo '<details><summary>Separate Facebook-Version mit eingebetteter Musik</summary>';
        self::field('Facebook-Reel · WordPress-Medien-ID (optional)','facebook_attachment_id','number');
        echo '<button type="button" class="button jss-media" data-target="facebook_attachment_id">Facebook-Reel auswählen</button><p>Eine fertig vertonte MP4 auswählen. Instagram-Musik wird nicht automatisch übertragen oder in die Datei gemischt. Ohne separate Datei wird die Hauptdatei verwendet.</p><label><input type="checkbox" name="facebook_rights_confirmed"> Musikrechte für diese Facebook-Version geprüft</label>';
        self::field('Facebook: konkrete Rechtequelle / Lizenznachweis','facebook_rights_basis'); echo '</details>';
        foreach ($targets as $p=>$t) { echo '<p><label><input type="checkbox" name="platforms[]" value="'.esc_attr($p).'" '.($t['id']?'checked':'disabled').'> '.esc_html(ucfirst($p).' · '.$t['name'].' · '.$t['id']).'</label></p>'; }
        self::date_fields(); echo '</div><div>';
        foreach (['instagram'=>'Instagram: keine URL; Shop-Link im Profil','facebook'=>'Facebook: Originaltext; optionaler Shop-Link wird ergänzt'] as $p=>$l) { echo '<label class="jss-field">'.esc_html($l).'<textarea name="'.esc_attr($p.'_caption').'" rows="6"></textarea></label>'; }
        self::field('Shop-Link für Facebook (optional; leer = kein zusätzlicher Werbeaufruf)','product_url','url'); self::field('UTM-Kampagne','campaign','text','schmuck-der-woche'); echo '</div></div>';
        echo '<details><summary>Instagram-Einstellungen</summary><label><input type="checkbox" name="share_to_feed" checked> Reel auch für den Feed freigeben</label>';
        self::field('Cover · JPEG-Medien-ID (optional)','cover_id','number'); echo '<button type="button" class="button jss-media" data-target="cover_id">Cover wählen</button>'; self::field('Oder Video-Cover bei Millisekunde (optional)','thumb_offset','number');
        echo '<p>Eigenes Cover hat Vorrang vor dem Video-Zeitpunkt. Diese Auswahl gilt nur für Instagram. Facebook nutzt seine automatische Cover-Auswahl.</p>';
        if (JSSocial_Config::product_tags_enabled()) { echo '<label class="jss-field">Meta-Produktmarkierungen als JSON (optional)<textarea name="product_tags" placeholder="[{&quot;product_id&quot;:&quot;META_PRODUKT_ID&quot;}]"></textarea></label><p>Erfordert freigeschalteten Instagram-Shop und zusätzliche Rechte. WooCommerce-IDs sind keine Meta-Produkt-IDs. Facebook-Tags werden nicht übertragen.</p>'; }
        echo '</details><details '.(!empty($_GET['audio_id'])?'open':'').'><summary>Instagram-Musik aus der Audio API</summary>';
        self::field('Audio-ID (aus „Instagram Audio“)','audio_id','text',sanitize_text_field($_GET['audio_id']??'')); self::field('Musiklautstärke · 0 bis 100','audio_volume','number','80'); self::field('Originalton · 0 bis 100','video_volume','number','50');
        echo '<label><input type="checkbox" name="rights_confirmed"> Kommerzielle Nutzung dieses konkreten Titels für diesen Beitrag geprüft.</label>'; self::field('Konkrete Rechtequelle / Lizenznachweis','rights_basis');
        echo '<p>Kein fertiges Mix-Vorhören verfügbar. Facebook erhält nur den Originalton der Datei. Ein verfügbarer oder angesagter Titel ist nicht automatisch kommerziell nutzbar. Ohne gewählten Titel bleibt die Terminplanung vollständig nutzbar.</p></details><p><button class="button button-primary button-hero">Entwurf speichern & Vorschau öffnen</button></p></form></section>';
    }
    private static function queue(): void {
        $jobs=JSSocial_Store::listing(30,(int)($_GET['before']??0));
        echo '<section class="jss-card"><h2>Beiträge & Termine</h2><p>Alle Zeiten: Europe/Berlin. Entwürfe sind noch nicht eingeplant.</p><table class="widefat striped"><thead><tr><th>Beitrag</th><th>Termin</th><th>Status</th><th>Plattformen</th></tr></thead><tbody>';
        foreach ($jobs as $j) {
            echo '<tr><td><a href="'.esc_url(admin_url('admin.php?page=jssocial&job='.$j['id'])).'">#'.(int)$j['id'].' · '.esc_html($j['payload']['asset']['filename']).'</a></td><td>'.esc_html(JSSocial_Service::local($j['due'])).'</td><td>'.esc_html(self::state($j['state'])).'</td><td>';
            foreach ($j['results'] as $p=>$r) { echo '<div>'.esc_html(ucfirst($p).': '.self::state($r['state'])).($r['url']?' · <a target="_blank" rel="noopener" href="'.esc_url($r['url']).'">Beitrag öffnen</a>':'').'</div>'; } echo '</td></tr>';
        }
        if (!$jobs) { echo '<tr><td colspan="4">Noch keine Beiträge. Zuerst Verbindung und Worker einrichten.</td></tr>'; }
        echo '</tbody></table>'; if (count($jobs)===30) { echo '<p><a href="'.esc_url(admin_url('admin.php?page=jssocial&before='.end($jobs)['id'])).'">Ältere Beiträge</a></p>'; } echo '</section>';
    }
    public static function state(string $s): string { return ['draft'=>'Entwurf · keine Freigabe','queued'=>'Freigegeben / eingeplant','running'=>'Verarbeitung läuft','published'=>'Veröffentlicht','partial'=>'Teilweise veröffentlicht','failed'=>'Fehlgeschlagen','unknown'=>'Unklar · manuell prüfen','held'=>'Angehalten','cancelled'=>'Storniert','pending'=>'Wartet','processing'=>'Meta verarbeitet','verifying'=>'Veröffentlichung wird geprüft'][$s]??$s; }
    private static function review(array $j): void {
        $d=$j['payload'];
        echo '<div class="jss-grid"><section class="jss-card"><h2>Vorschau #'.(int)$j['id'].'</h2><p class="jss-status">'.esc_html(self::state($j['state'])).'</p>';
        if ($d['kind']==='reel') { echo '<video class="jss-preview" controls preload="metadata" src="'.esc_url($d['asset']['url']).'"></video>'; }
        else { echo '<img class="jss-preview" alt="Beitragsvorschau" src="'.esc_url($d['asset']['url']).'">'; }
        echo '<p>'.esc_html($d['asset']['filename']).'<br>'.esc_html($d['asset']['width'].' × '.$d['asset']['height'].' · '.($d['asset']['seconds']??'—').' Sekunden · '.size_format($d['asset']['bytes'])).'</p><p><strong>Termin:</strong> '.esc_html($j['when_berlin']).'</p>';
        if (!empty($d['options']['cover'])) { echo '<p>Instagram-Cover:</p><img class="jss-cover" alt="Instagram-Cover" src="'.esc_url($d['options']['cover']['url']).'">'; }
        if (!empty($d['options']['facebook_asset'])) { echo '<p>Separate Facebook-Version:</p><video class="jss-preview" controls preload="metadata" src="'.esc_url($d['options']['facebook_asset']['url']).'"></video>'; }
        foreach ($j['warnings'] as $w) { echo '<p class="description">'.esc_html($w).'</p>'; }
        echo '</section><section class="jss-card"><h2>Ziele & Texte</h2>';
        foreach ($d['platforms'] as $p) {
            $r=$j['results'][$p]; echo '<h3>'.esc_html(ucfirst($p).' · '.$d['targets'][$p]['name'].' · '.$d['targets'][$p]['id']).'</h3><div class="jss-caption">'.esc_html($d['captions'][$p]).'</div><p><strong>'.esc_html(self::state($r['state'])).'</strong></p>';
            if ($r['error']) { echo '<p class="jss-error">'.esc_html($r['error']).'</p>'; }
            if ($r['url']) { echo '<p><a target="_blank" rel="noopener" href="'.esc_url($r['url']).'">Veröffentlichten Beitrag öffnen</a></p>'; }
            if ($r['remote_id']) { echo '<p>Meta-ID: <code>'.esc_html($r['remote_id']).'</code></p>'; }
            if ($r['state']==='failed'&&empty($r['publish_sent'])&&$j['state']!=='cancelled') { self::start('retry'); self::hidden('job_id',$j['id']); self::hidden('platform',$p); echo '<button class="button">Nur '.esc_html(ucfirst($p)).' erneut versuchen</button></form>'; }
        }
        echo '<h3>Veröffentlichungseinstellungen</h3><pre>'.esc_html(wp_json_encode($d['options'],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)).'</pre><p>Facebook: Ton der separaten Facebook-Datei, falls gewählt, sonst der Hauptdatei; automatische Cover-Auswahl. Keine automatische Produktmarkierung. Remix-/Kommentareinstellungen richten sich nach dem jeweiligen Konto.</p></section></div>';
        echo '<section class="jss-card"><h2>Freigabe & Verwaltung</h2>';
        if ($j['state']==='draft' && empty($j['publication_blockers'])) {
            self::start('approve'); self::hidden('job_id',$j['id']); self::hidden('preview_hash',$j['preview_hash']); self::hidden('confirmation',$j['approval_text']);
            echo '<p><label><input type="checkbox" name="explicit_approval" required> Ich habe Datei, Konten, Texte, Einstellungen und Termin geprüft und gebe genau diesen Beitrag ausdrücklich zur Veröffentlichung frei. Bei einem Termin autorisiere ich die automatische Veröffentlichung ohne erneute Rückfrage.</label></p><button class="button button-primary">'.($j['due']?'Verbindlich für diesen Termin freigeben':'Jetzt zur Veröffentlichung freigeben').'</button></form>';
        }
        if (in_array($j['state'],['draft','queued','cancelled'],true)) { self::start('reschedule'); self::hidden('job_id',$j['id']); self::hidden('preview_hash',$j['preview_hash']); echo '<h3>Termin ändern</h3>'; self::date_fields(); echo '<button class="button">Alten Termin aufheben & neuen Entwurf vorbereiten</button></form>'; }
        if (!in_array($j['state'],['published','cancelled'],true)) { self::start('cancel'); self::hidden('job_id',$j['id']); self::hidden('preview_hash',$j['preview_hash']); echo '<p><button class="button">Weitere Verarbeitung stornieren</button></p></form>'; }
        self::start('reconcile'); self::hidden('job_id',$j['id']); echo '<p><button class="button">Meta-Status / Beitragslinks erneut prüfen</button></p></form><details><summary>Prüfwert & Verlauf</summary><code>'.esc_html($j['preview_hash']).'</code><pre>'.esc_html(wp_json_encode($j['audit'],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)).'</pre></details></section>';
    }
    private static function audio(): void {
        echo '<section class="jss-card"><h2>Instagram Audio</h2><p>Suche leer lassen, um angesagte Titel des für dein Konto verfügbaren API-Katalogs abzurufen. Die Auswahl kann von der Instagram-App abweichen.</p>'; self::start('audio');
        self::field('Titel, Künstler oder Suchbegriff (optional)','query'); echo '<select name="audio_type"><option value="music">Musik</option><option value="original_sound">Originalsounds</option></select> <button class="button button-primary">Katalog abrufen</button></form><p><a href="https://www.facebook.com/sound/collection/" target="_blank" rel="noopener">Meta Sound Collection öffnen</a> · Lizenzbedingungen für den konkreten Einsatz prüfen. Die separate Audio-Ersetzung für Ads ist eine eingeschränkt freigegebene Marketing-API-Funktion und nicht Teil dieser Version.</p><p>Instagram-Audio wird nicht auf Facebook übertragen. Vorhören betrifft den Titel allein; eine Reel-Mix-Vorschau unterstützt die API nicht.</p></section>';
        $r=get_transient('jssocial_audio_'.get_current_user_id());
        if (!$r) { return; } echo '<div class="jss-grid">';
        foreach ($r['tracks'] as $t) {
            echo '<section class="jss-card"><h3>'.esc_html($t['title']??'Audio').'</h3><p>'.esc_html($t['display_artist']??$t['ig_username']??'').'</p><p>ID: '.esc_html($t['audio_id']).' · Ads-Flag: '.(!array_key_exists('is_ads_eligible',$t)||$t['is_ads_eligible']===null?'nicht angegeben':($t['is_ads_eligible']?'ja':'nein')).'</p>';
            if (!empty($t['download_url'])&&wp_parse_url($t['download_url'],PHP_URL_SCHEME)==='https') { echo '<audio controls preload="none" src="'.esc_url($t['download_url']).'"></audio><p class="description">Vorhör-Link ist temporär; bei Ablauf erneut suchen.</p>'; }
            elseif (!empty($t['on_platform_audio_preview_link'])) { echo '<a target="_blank" rel="noopener" href="'.esc_url($t['on_platform_audio_preview_link']).'">Auf Instagram vorhören</a>'; }
            else { echo '<p>Für diesen Titel keine Vorschau verfügbar.</p>'; }
            echo '<p><a class="button" href="'.esc_url(add_query_arg(['page'=>'jssocial','tab'=>'compose','audio_id'=>$t['audio_id']],admin_url('admin.php'))).'">Für neuen Entwurf auswählen</a></p><p class="description">Rechtestatus: ungeprüft. Auswahl im Entwurf möglich; Veröffentlichung erst mit konkretem Lizenznachweis. Ein Ads-Flag ersetzt keine Lizenz.</p></section>';
        }
        if (!$r['tracks']) { echo '<section class="jss-card">Keine Titel für diese Abfrage verfügbar. Eine leere Antwort beweist keine allgemeine Kontofreischaltung.</section>'; }
        echo '</div>';
    }
}
