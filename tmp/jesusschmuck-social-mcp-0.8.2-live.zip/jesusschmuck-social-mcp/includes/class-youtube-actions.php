<?php
defined('ABSPATH') || exit;
/** Explicitly approved YouTube operations; native YouTube scheduling, no blind retries. */
final class JSSocial_YouTube_Actions {
    private const API = 'https://www.googleapis.com/youtube/v3/';
    private static function locked(callable $fn): array {
        global $wpdb;
        $key = 'jssocial_yt_'.substr(hash('sha256', $wpdb->prefix), 0, 32);
        if ((string)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 0)', $key)) !== '1') { throw new RuntimeException('YouTube wird gerade bearbeitet. Später denselben Auftrag erneut lesen.'); }
        try { return $fn(); } finally { $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $key)); }
    }
    private static function request(array $c, string $method, string $url, ?array $body = null, array $headers = []): array {
        $a = ['method'=>$method, 'timeout'=>30, 'redirection'=>0, 'headers'=>['Authorization'=>'Bearer '.$c['access_token']]];
        $a['headers'] += $headers;
        if ($body !== null) { $a['headers']['Content-Type']='application/json'; $a['body']=wp_json_encode($body); }
        $r = wp_remote_request($url, $a);
        if (is_wp_error($r)) { throw new RuntimeException('YouTube-Antwort fehlt; mögliche Schreibwirkung bleibt ungeklärt. Nicht als neuen Auftrag wiederholen.'); }
        $status = wp_remote_retrieve_response_code($r); $data = json_decode(wp_remote_retrieve_body($r), true);
        if ($status < 200 || $status >= 300 || !is_array($data) || isset($data['error'])) { throw new RuntimeException('YouTube-Anfrage fehlgeschlagen (HTTP '.(int)$status.'). Schreibwirkung gegebenenfalls ungeklärt; Status lesen.'); }
        return $data;
    }
    private static function api(array $c, string $resource, array $query): array {
        return self::request($c, 'GET', self::API.$resource.'?'.http_build_query($query, '', '&', PHP_QUERY_RFC3986));
    }
    private static function owned(array $c, string $resource, string $id): array {
        $d=self::api($c,$resource,['part'=>'snippet,status','id'=>$id]); $x=$d['items'][0]??[];
        if (($x['id']??'')!==$id || ($x['snippet']['channelId']??'')!==$c['channel']['id']) { throw new RuntimeException('Video/Playlist gehört nicht eindeutig zum verbundenen Kanal.'); }
        return $x;
    }
    private static function playlist_snapshot(array $x): array {
        return ['id'=>$x['id'],'title'=>$x['snippet']['title'],'description'=>$x['snippet']['description']??'','default_language'=>$x['snippet']['defaultLanguage']??null,'privacy'=>$x['status']['privacyStatus']??null,'etag'=>$x['etag']??null];
    }
    public static function listing(array $a): array {
        $c=JSSocial_YouTube::access(); $q=['part'=>'snippet,status','maxResults'=>50];
        if (!empty($a['page_token'])) { $q['pageToken']=$a['page_token']; }
        $resource=$a['resource'];
        if ($resource==='playlists') { $q['mine']='true'; }
        elseif ($resource==='uploads') {
            $d=self::api($c,'channels',['part'=>'contentDetails','mine'=>'true']);
            $uploads=$d['items'][0]['contentDetails']['relatedPlaylists']['uploads']??'';
            if ($uploads==='') { throw new RuntimeException('Upload-Playlist des Kanals fehlt.'); }
            $resource='playlistItems'; $q['playlistId']=$uploads; $q['part']='snippet,status,contentDetails';
        } elseif ($resource==='playlist_items') {
            self::owned($c,'playlists',$a['playlist_id']??'');
            $resource='playlistItems'; $q['playlistId']=$a['playlist_id']; $q['part']='snippet,status,contentDetails';
        } elseif ($resource==='video') {
            $x=self::owned($c,'videos',$a['video_id']??'');
            return ['channel'=>$c['channel'],'items'=>[self::video_result($x)]];
        } else { throw new InvalidArgumentException('Unbekannte YouTube-Leseaktion.'); }
        $d=self::api($c,$resource,$q);
        return ['channel'=>$c['channel'],'items'=>$d['items']??[], 'next_page_token'=>$d['nextPageToken']??null];
    }
    private static function text(string $s, int $max, bool $required=false): string {
        $s=trim($s);
        if (($required && $s==='') || strlen($s)>$max || preg_match('/[<>\x00]/', $s)) { throw new InvalidArgumentException('Titel/Beschreibung leer, zu lang oder mit unzulässigen Zeichen.'); }
        return $s;
    }
    private static function asset(int $id): array {
        $x=JSSocial_Service::asset($id,'reel',[]);
        if ($x['bytes']<=0 || $x['bytes']>12*1024*1024) { throw new InvalidArgumentException('YouTube-Upload aktuell: MP4 bis 12 MB, 3 bis 900 Sekunden.'); }
        return $x;
    }
    private static function future(int $ts): void {
        if ($ts < time()+300) { throw new InvalidArgumentException('YouTube-Termin muss mindestens fünf Minuten in der Zukunft liegen. Neue Vorschau mit neuem Termin erstellen; keine Sofortveröffentlichung.'); }
    }
    public static function prepare(array $a): array {
        return self::locked(function() use($a) {
            $c=JSSocial_YouTube::access();
            $id=hash('sha256',$a['request_key']);
            $fingerprint=hash('sha256',wp_json_encode($a));
            $old=JSSocial_Config::youtube_operation($id);
            if ($old) {
                if (($old['input_hash']??'')!==$fingerprint) { throw new RuntimeException('request_key gehört zu anderen Eingaben. Für Änderungen neuen Schlüssel verwenden.'); }
                return self::public_operation($old);
            }
            $kind=$a['operation'];
            if ((isset($a['local_datetime']) || isset($a['utc_offset'])) && $kind!=='upload_video') { throw new InvalidArgumentException('Terminplanung gilt nur für upload_video.'); }
            if (isset($a['utc_offset']) && empty($a['local_datetime'])) { throw new InvalidArgumentException('UTC-Abweichung benötigt einen Termin.'); }
            $p=['operation'=>$kind,'channel'=>$c['channel']];
            if (in_array($kind,['upload_video','create_playlist'],true)) {
                $p['title']=self::text($a['title']??'',100,true);
                $p['description']=self::text($a['description']??'', $kind==='upload_video'?5000:5000);
                $p['privacy']=$a['privacy']??'private';
            }
            if ($kind==='upload_video') {
                if (($a['rights_confirmed']??false)!==true || trim($a['rights_basis']??'')==='') { throw new InvalidArgumentException('Bestätigte Video-/Audio-Rechte und Rechtebasis erforderlich.'); }
                if (!isset($a['made_for_kids'],$a['contains_synthetic_media'])) { throw new InvalidArgumentException('Kinderzielgruppe und synthetische Medien ausdrücklich angeben.'); }
                $p['asset']=self::asset($a['attachment_id']??0);
                $p['made_for_kids']=$a['made_for_kids']; $p['contains_synthetic_media']=$a['contains_synthetic_media'];
                $p['rights_basis']=self::text($a['rights_basis'],2000,true);
                if (isset($a['local_datetime'])) {
                    if ($p['privacy']!=='public') { throw new InvalidArgumentException('Terminplanung benötigt privacy=public als Zielsichtbarkeit.'); }
                    $ts=JSSocial_Service::time($a['local_datetime'],$a['utc_offset']??'');
                    self::future($ts);
                    $p['schedule']=['local_datetime'=>$a['local_datetime'],'timezone'=>'Europe/Berlin','local_display'=>JSSocial_Service::local($ts),'publish_at'=>gmdate('Y-m-d\TH:i:s\Z',$ts),'initial_privacy'=>'private','target_privacy'=>'public','publisher'=>'YouTube'];
                }
            } elseif ($kind==='rename_playlist') {
                foreach ($a as $key=>$value) {
                    if (!in_array($key,['request_key','operation','playlist_id','title'],true)) { throw new InvalidArgumentException('rename_playlist erlaubt ausschließlich playlist_id und title neben request_key und operation.'); }
                }
                $p['title']=self::text($a['title']??'',100,true);
                $p['playlist']=self::playlist_snapshot(self::owned($c,'playlists',$a['playlist_id']??''));
                if (empty($p['playlist']['etag'])) { throw new RuntimeException('Playlist-Version (ETag) fehlt; keine sichere Umbenennung möglich.'); }
            } elseif ($kind==='add_to_playlist') {
                $playlist=self::owned($c,'playlists',$a['playlist_id']??'');
                $video=self::owned($c,'videos',$a['video_id']??'');
                $p['playlist']=['id'=>$playlist['id'],'title'=>$playlist['snippet']['title'],'privacy'=>$playlist['status']['privacyStatus']??null];
                $p['video']=['id'=>$video['id'],'title'=>$video['snippet']['title']];
            } elseif ($kind!=='create_playlist') { throw new InvalidArgumentException('Unbekannte YouTube-Schreibaktion.'); }
            $op=['id'=>$id,'input_hash'=>$fingerprint,'client_id'=>JSSocial_Config::youtube_credentials()['client_id'],'preview'=>$p,'preview_hash'=>hash('sha256',wp_json_encode($p)),'state'=>'draft','created_at'=>gmdate('c')];
            JSSocial_Config::youtube_operation($id,$op);
            return self::public_operation($op);
        });
    }
    private static function public_operation(array $op): array {
        return array_intersect_key($op,array_flip(['id','preview','preview_hash','state','created_at','approved_at','result','error','next_action']));
    }
    public static function preview(string $id): array {
        $op=JSSocial_Config::youtube_operation($id);
        if (!$op) { throw new InvalidArgumentException('YouTube-Auftrag nicht gefunden.'); }
        return self::public_operation($op);
    }
    private static function video_result(array $x): array {
        $s=$x['status']??[]; $u=$s['uploadStatus']??'unknown'; $privacy=$s['privacyStatus']??'unknown';
        $state=in_array($u,['failed','rejected','deleted'],true)?'failed':($u==='processed'?($privacy==='public'?'published':'uploaded_'.$privacy):'processing');
        $publishAt=$s['publishAt']??null;
        if ($state!=='failed' && $privacy==='private' && $publishAt) {
            $state=strtotime($publishAt)>time()?($u==='processed'?'scheduled':'scheduled_processing'):'schedule_overdue';
        }
        // snippet.publishedAt can be upload time for private videos: never label it actual publication time.
        return ['video_id'=>$x['id'],'url'=>'https://www.youtube.com/watch?v='.rawurlencode($x['id']),'state'=>$state,'upload_status'=>$u,'privacy'=>$privacy,'provider_status'=>$s,'publish_at'=>$publishAt];
    }
    public static function execute(array $a): array {
        return self::locked(function() use($a) {
            $op=JSSocial_Config::youtube_operation($a['operation_id']);
            if (!$op || !hash_equals($op['preview_hash'],$a['preview_hash'])) { throw new RuntimeException('Vorschau fehlt oder wurde geändert.'); }
            if (($a['confirm']??false)!==true || trim($a['approval_evidence']??'')==='') { throw new RuntimeException('Ausdrückliche Freigabe der aktuellen Vorschau fehlt.'); }
            if (in_array($op['state'],['complete','unknown','failed'],true) && !($op['state']==='unknown' && $op['preview']['operation']==='rename_playlist')) { return self::public_operation($op); }
            $c=JSSocial_YouTube::access(true); $p=$op['preview'];
            if ($c['channel']['id']!==$p['channel']['id'] || $op['client_id']!==JSSocial_Config::youtube_credentials()['client_id']) { throw new RuntimeException('Google-Client/Kanal geändert; neuer Entwurf und neue Freigabe erforderlich.'); }
            if ($op['state']==='unknown' && $p['operation']==='rename_playlist') {
                // Reconcile delayed provider reads without ever issuing another PUT.
                try {
                    $op['result']=self::verify_rename($c,$p); $op['state']='complete'; unset($op['error'],$op['next_action']);
                } catch (Throwable $e) { $op['error']=$e->getMessage(); }
                JSSocial_Config::youtube_operation($op['id'],$op); return self::public_operation($op);
            }
            if ($p['operation']==='upload_video') {
                $asset=self::asset($p['asset']['attachment_id']);
                if ($asset['sha256']!==$p['asset']['sha256'] || $asset['bytes']!==$p['asset']['bytes']) { throw new RuntimeException('Videodatei geändert. Neue Vorschau erforderlich.'); }
            } elseif ($p['operation']==='rename_playlist') {
                $current=self::playlist_snapshot(self::owned($c,'playlists',$p['playlist']['id']));
                if ($current!==$p['playlist']) { throw new RuntimeException('Playlist seit der Vorschau geändert. Neue Vorschau mit neuem request_key erforderlich.'); }
                if ($current['title']===$p['title']) {
                    $op['state']='complete'; $op['result']=['playlist_id'=>$current['id'],'title'=>$p['title'],'already_named'=>true,'url'=>'https://www.youtube.com/playlist?list='.rawurlencode($current['id'])];
                    JSSocial_Config::youtube_operation($op['id'],$op); return self::public_operation($op);
                }
            } elseif ($p['operation']==='add_to_playlist') {
                self::owned($c,'playlists',$p['playlist']['id']); self::owned($c,'videos',$p['video']['id']);
                $found=self::api($c,'playlistItems',['part'=>'id','playlistId'=>$p['playlist']['id'],'videoId'=>$p['video']['id'],'maxResults'=>50]);
                if (!empty($found['items'][0]['id'])) {
                    $op['state']='complete'; $op['result']=['playlist_item_id'=>$found['items'][0]['id'],'already_present'=>true,'playlist_id'=>$p['playlist']['id'],'video_id'=>$p['video']['id']];
                    JSSocial_Config::youtube_operation($op['id'],$op); return self::public_operation($op);
                }
            }
            $op['approved_at']=$op['approved_at']??gmdate('c'); $op['approval_evidence']=$op['approval_evidence']??self::text($a['approval_evidence'],4000,true);
            try {
                if ($p['operation']==='upload_video') { self::upload($c,$op); }
                else {
                    // Save uncertainty BEFORE the only non-idempotent request. A timeout/crash must never cause a duplicate POST.
                    $op['state']='unknown'; $op['next_action']='Nur lesend prüfen; nicht automatisch als neuen Auftrag senden.';
                    JSSocial_Config::youtube_operation($op['id'],$op);
                    if ($p['operation']==='create_playlist') {
                        $x=self::request($c,'POST',self::API.'playlists?part=snippet,status',['snippet'=>['title'=>$p['title'],'description'=>$p['description']],'status'=>['privacyStatus'=>$p['privacy']]]);
                        if (empty($x['id'])) { throw new RuntimeException('Playlist-ID nicht bestätigt.'); }
                        $op['result']=['playlist_id'=>$x['id'],'url'=>'https://www.youtube.com/playlist?list='.rawurlencode($x['id']),'privacy'=>$x['status']['privacyStatus']??'unknown'];
                    } elseif ($p['operation']==='rename_playlist') {
                        $snippet=['title'=>$p['title'],'description'=>$p['playlist']['description']];
                        if ($p['playlist']['default_language']!==null) { $snippet['defaultLanguage']=$p['playlist']['default_language']; }
                        $x=self::request($c,'PUT',self::API.'playlists?part=snippet',['id'=>$p['playlist']['id'],'snippet'=>$snippet],['If-Match'=>$p['playlist']['etag']]);
                        if (($x['id']??'')!==$p['playlist']['id'] || ($x['snippet']['title']??'')!==$p['title']) { throw new RuntimeException('Playlist-Umbenennung nicht bestätigt.'); }
                        $op['result']=self::verify_rename($c,$p);
                    } else {
                        $x=self::request($c,'POST',self::API.'playlistItems?part=snippet',['snippet'=>['playlistId'=>$p['playlist']['id'],'resourceId'=>['kind'=>'youtube#video','videoId'=>$p['video']['id']]]]);
                        if (empty($x['id'])) { throw new RuntimeException('Playlist-Eintrag nicht bestätigt.'); }
                        $op['result']=['playlist_item_id'=>$x['id'],'playlist_id'=>$p['playlist']['id'],'video_id'=>$p['video']['id']];
                    }
                    $op['state']='complete'; unset($op['next_action'],$op['error']);
                }
            } catch (Throwable $e) { $op['error']=$e->getMessage(); }
            JSSocial_Config::youtube_operation($op['id'],$op);
            return self::public_operation($op);
        });
    }
    private static function verify_rename(array $c, array $p): array {
        $actual=self::playlist_snapshot(self::owned($c,'playlists',$p['playlist']['id']));
        $expected=$p['playlist']; $expected['title']=$p['title']; unset($actual['etag'],$expected['etag']);
        if ($actual!==$expected) { throw new RuntimeException('YouTube-Leseprüfung bestätigt Titel oder unveränderte Playlist-Eigenschaften nicht.'); }
        return ['playlist_id'=>$p['playlist']['id'],'old_title'=>$p['playlist']['title'],'title'=>$p['title'],'description'=>$actual['description'],'privacy'=>$actual['privacy'],'verified'=>true,'url'=>'https://www.youtube.com/playlist?list='.rawurlencode($p['playlist']['id'])];
    }
    private static function upload(array $c, array &$op): void {
        $p=$op['preview']; $size=$p['asset']['bytes']; $fresh=false;
        if (!empty($p['schedule']) && empty($op['session_url'])) { self::future(strtotime($p['schedule']['publish_at'])); }
        if (empty($op['session_url'])) {
            $op['state']='unknown'; $op['next_action']='Upload-Initialisierung ungeklärt; keine automatische Neuanlage.';
            JSSocial_Config::youtube_operation($op['id'],$op);
            $body=['snippet'=>['title'=>$p['title'],'description'=>$p['description']],'status'=>['privacyStatus'=>$p['privacy'],'selfDeclaredMadeForKids'=>$p['made_for_kids'],'containsSyntheticMedia'=>$p['contains_synthetic_media']]];
            if (!empty($p['schedule'])) { $body['status']['privacyStatus']='private'; $body['status']['publishAt']=$p['schedule']['publish_at']; }
            $r=wp_remote_request('https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status',['method'=>'POST','timeout'=>30,'redirection'=>0,'headers'=>['Authorization'=>'Bearer '.$c['access_token'],'Content-Type'=>'application/json; charset=UTF-8','X-Upload-Content-Type'=>'video/mp4','X-Upload-Content-Length'=>(string)$size],'body'=>wp_json_encode($body)]);
            if (is_wp_error($r) || wp_remote_retrieve_response_code($r)<200 || wp_remote_retrieve_response_code($r)>=300) { throw new RuntimeException('Upload-Initialisierung nicht bestätigt.'); }
            $url=(string)wp_remote_retrieve_header($r,'location'); $u=wp_parse_url($url);
            if (($u['scheme']??'')!=='https' || ($u['host']??'')!=='www.googleapis.com' || !str_starts_with($u['path']??'','/upload/youtube/v3/videos') || isset($u['user']) || isset($u['pass']) || isset($u['port'])) { throw new RuntimeException('Google-Uploadziel ungültig.'); }
            $op['session_url']=$url; $op['state']='uploading'; $op['next_action']='Denselben freigegebenen Auftrag ausführen, um den Upload sicher fortzusetzen.';
            JSSocial_Config::youtube_operation($op['id'],$op); $fresh=true;
        }
        $headers=['Authorization'=>'Bearer '.$c['access_token'],'Content-Type'=>'video/mp4']; $offset=0;
        if (!$fresh) {
            $r=wp_remote_request($op['session_url'],['method'=>'PUT','timeout'=>30,'redirection'=>0,'headers'=>$headers+['Content-Length'=>'0','Content-Range'=>'bytes */'.$size],'body'=>'']);
            if (self::upload_response($r,$op)) { return; }
            if (wp_remote_retrieve_response_code($r)!==308) { throw new RuntimeException('Uploadstatus nicht bestätigt; nur dieselbe Sitzung erneut prüfen.'); }
            $range=(string)wp_remote_retrieve_header($r,'range');
            if ($range!=='' && !preg_match('/^bytes=0-(\d+)$/',$range,$m)) { throw new RuntimeException('Ungültiger bestätigter Uploadbereich.'); }
            $offset=$range===''?0:(int)$m[1]+1;
            if (wp_remote_retrieve_header($r,'retry-after')!=='') { throw new RuntimeException('Google bittet um Wartezeit; Auftrag später fortsetzen.'); }
        }
        if (!empty($p['schedule'])) { self::future(strtotime($p['schedule']['publish_at'])); }
        if ($offset<0 || $offset>=$size) { throw new RuntimeException('Upload vollständig übertragen, Verarbeitung noch nicht bestätigt. Später denselben Auftrag prüfen.'); }
        $path=get_attached_file($p['asset']['attachment_id']); $data=file_get_contents($path,false,null,$offset);
        if ($data===false || strlen($data)!==$size-$offset || hash_file('sha256',$path)!==$p['asset']['sha256']) { throw new RuntimeException('Videodatei konnte nicht unverändert gelesen werden.'); }
        $r=wp_remote_request($op['session_url'],['method'=>'PUT','timeout'=>60,'redirection'=>0,'headers'=>$headers+['Content-Length'=>(string)strlen($data),'Content-Range'=>'bytes '.$offset.'-'.($size-1).'/'.$size],'body'=>$data]);
        if (!self::upload_response($r,$op)) { $op['next_action']='Denselben freigegebenen Auftrag fortsetzen; keine neue Upload-Sitzung anlegen.'; }
    }
    private static function upload_response($r, array &$op): bool {
        if (is_wp_error($r)) { throw new RuntimeException('Uploadantwort fehlt. Dieselbe Sitzung kann sicher geprüft und fortgesetzt werden.'); }
        $code=wp_remote_retrieve_response_code($r);
        if ($code>=200 && $code<300) {
            $x=json_decode(wp_remote_retrieve_body($r),true);
            if (empty($x['id'])) { throw new RuntimeException('Video-ID noch nicht bestätigt.'); }
            $op['result']=self::video_result($x); $op['state']='complete';
            if (!empty($op['preview']['schedule'])) {
                $expected=$op['preview']['schedule']['publish_at'];
                $op['result']['schedule_confirmed']=($op['result']['privacy']==='private' && !empty($op['result']['publish_at']) && strtotime($op['result']['publish_at'])===strtotime($expected));
                if (!$op['result']['schedule_confirmed']) { $op['result']['warning']='YouTube hat den gewünschten Termin nicht bestätigt. Live-Videostatus prüfen; keinen erneuten Upload anlegen.'; }
            } unset($op['next_action'],$op['error'],$op['session_url']); return true;
        }
        if (in_array($code,[404,410],true)) { $op['state']='unknown'; throw new RuntimeException('Upload-Sitzung abgelaufen. Vor neuer Anlage Kanalinhalt manuell prüfen.'); }
        if ($code!==308) { throw new RuntimeException('Upload nicht bestätigt (HTTP '.(int)$code.'). Dieselbe Sitzung später prüfen.'); }
        return false;
    }
}
