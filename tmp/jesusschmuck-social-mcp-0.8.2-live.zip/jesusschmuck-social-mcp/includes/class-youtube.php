<?php
defined('ABSPATH') || exit;
/** Google authorization and verified channel access. */
final class JSSocial_YouTube {
    public const WRITE_SCOPE = 'https://www.googleapis.com/auth/youtube.force-ssl';
    private const SCOPE = 'https://www.googleapis.com/auth/youtube.readonly';
    public static function callback(): string { return admin_url('admin-post.php?action=jssocial_youtube_oauth'); }
    private static function guard(): void {
        if (!current_user_can('manage_options') || !is_ssl()) { wp_die('Administrator-Berechtigung und HTTPS erforderlich.'); }
    }
    private static function binding(): string {
        $c = JSSocial_Config::youtube_credentials();
        return hash('sha256', $c['client_id'].'|'.$c['client_secret'].'|'.wp_get_session_token());
    }
    private static function finish(string $message): void {
        set_transient('jssocial_flash_'.get_current_user_id(), $message, 60);
        wp_safe_redirect(admin_url('admin.php?page=jssocial&tab=setup')); exit;
    }
    public static function status(): array {
        $out = ['configured' => false, 'connected' => false, 'publishing_enabled' => false, 'redirect_uri' => self::callback(), 'scope' => self::SCOPE];
        try {
            $credentials = JSSocial_Config::youtube_credentials();
            $connection = JSSocial_Config::youtube_connection();
            $out['configured'] = $credentials['client_id'] !== '' && $credentials['client_secret'] !== '';
            $out['connected'] = !empty($connection['refresh_token']) && !empty($connection['channel']['id']);
            $out['publishing_enabled'] = $out['connected'] && self::can_write($connection);
            $out['reauthorization_required'] = $out['connected'] && !$out['publishing_enabled'];
            $out['granted_scopes'] = preg_split('/\s+/', $connection['scope'] ?? '');
            $out['features'] = ['video_upload', 'video_schedule', 'playlist_list', 'playlist_create', 'playlist_add_video'];
            $out['upload_limit_bytes'] = 12 * 1024 * 1024;
            $out['channel'] = $connection['channel'] ?? null;
            $out['checked_at'] = !empty($connection['checked_at']) ? gmdate('c', $connection['checked_at']) : null;
            $out['connected_at'] = !empty($connection['connected_at']) ? gmdate('c', $connection['connected_at']) : null;
            $out['access_expires_at'] = !empty($connection['expires_at']) ? gmdate('c', $connection['expires_at']) : null;
            $out['note'] = 'Gespeicherter Verbindungsstand; keine aktuelle Online-Prüfung. Uploads/Playlist-Änderungen erfordern Schreibrechte und eine freigegebene Vorschau. API-Projekte ohne YouTube-Audit können auf private Uploads begrenzt sein.';
        } catch (Throwable $e) { $out['error'] = 'YouTube-Konfiguration konnte nicht gelesen werden.'; }
        return $out;
    }
    private static function response($response): array {
        if (is_wp_error($response)) { throw new RuntimeException('Google ist derzeit nicht erreichbar. Verbindung wurde nicht geändert.'); }
        $status = wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);
        if ($status < 200 || $status >= 300 || !is_array($data) || isset($data['error'])) {
            // Never expose raw provider responses, request payloads, tokens or authorization codes.
            throw new RuntimeException('Google-Anfrage fehlgeschlagen (HTTP '.(int)$status.'). Client-Einstellungen und erteilte Berechtigungen prüfen.');
        }
        return $data;
    }
    private static function token(array $body): array {
        $c = JSSocial_Config::youtube_credentials();
        return self::response(wp_remote_post('https://oauth2.googleapis.com/token', [
            'timeout' => 30, 'redirection' => 0,
            'body' => array_merge($body, ['client_id' => $c['client_id'], 'client_secret' => $c['client_secret']]),
        ]));
    }
    private static function channel(string $access_token): array {
        $data = self::response(wp_remote_get('https://www.googleapis.com/youtube/v3/channels?part=id%2Csnippet&mine=true&maxResults=50', [
            'timeout' => 30, 'redirection' => 0, 'headers' => ['Authorization' => 'Bearer '.$access_token],
        ]));
        $items = $data['items'] ?? [];
        if (count($items) !== 1 || !empty($data['nextPageToken']) || empty($items[0]['id'])) {
            throw new RuntimeException('Kein eindeutiger YouTube-Kanal erhalten. Google-Verbindung mit dem gewünschten Kanal erneut starten.');
        }
        return ['id' => (string)$items[0]['id'], 'title' => (string)($items[0]['snippet']['title'] ?? ''), 'url' => 'https://www.youtube.com/channel/'.rawurlencode($items[0]['id'])];
    }
    public static function authorization_url(): string {
        $c = JSSocial_Config::youtube_credentials();
        if ($c['client_id'] === '' || $c['client_secret'] === '') { throw new RuntimeException('Google-Client-ID und Clientschlüssel zuerst speichern.'); }
        $state = bin2hex(random_bytes(32));
        set_transient('jssocial_yt_state_'.get_current_user_id(), ['hash' => hash('sha256', $state), 'binding' => self::binding()], 600);
        return 'https://accounts.google.com/o/oauth2/v2/auth?'.http_build_query([
            'client_id' => $c['client_id'], 'redirect_uri' => self::callback(), 'response_type' => 'code',
            'scope' => self::SCOPE.' '.self::WRITE_SCOPE, 'state' => $state, 'access_type' => 'offline', 'prompt' => 'consent select_account',
        ], '', '&', PHP_QUERY_RFC3986);
    }
    public static function complete(array $query): void {
        $key = 'jssocial_yt_state_'.get_current_user_id();
        $expected = get_transient($key);
        $state = is_string($query['state'] ?? null) ? $query['state'] : '';
        if (!is_array($expected) || !hash_equals($expected['hash'], hash('sha256', $state)) || !hash_equals($expected['binding'], self::binding())) {
            throw new RuntimeException('Google-Anmeldung abgelaufen oder ungültig. Verbindung erneut starten.');
        }
        delete_transient($key); // One-time use, also on cancellation or token errors.
        if (isset($query['error'])) { throw new RuntimeException('Google-Anmeldung abgebrochen oder nicht genehmigt.'); }
        $code = $query['code'] ?? '';
        if (!is_string($code) || $code === '' || strlen($code) > 4096) { throw new RuntimeException('Google hat keinen gültigen Anmeldecode geliefert.'); }
        $token = self::token(['code' => $code, 'grant_type' => 'authorization_code', 'redirect_uri' => self::callback()]);
        if (empty($token['access_token']) || empty($token['refresh_token']) || empty($token['expires_in'])) {
            throw new RuntimeException('Google hat keinen dauerhaften Kanalzugriff erteilt. Verbindung erneut mit Zustimmung starten.');
        }
        $scopes = preg_split('/\s+/', (string)($token['scope'] ?? ''));
        if (!in_array(self::SCOPE, $scopes, true)) { throw new RuntimeException('Die YouTube-Leseberechtigung wurde nicht erteilt.'); }
        $channel = self::channel($token['access_token']);
        JSSocial_Config::save_youtube_connection([
            'access_token' => $token['access_token'], 'refresh_token' => $token['refresh_token'],
            'expires_at' => time() + (int)$token['expires_in'], 'scope' => implode(' ', $scopes),
            'channel' => $channel, 'connected_at' => time(), 'checked_at' => time(),
        ]);
    }
    public static function can_write(array $c): bool {
        $scopes = preg_split('/\s+/', $c['scope'] ?? '');
        return in_array(self::WRITE_SCOPE, $scopes, true) || in_array('https://www.googleapis.com/auth/youtube', $scopes, true);
    }
    public static function access(bool $write = false): array {
        self::verify();
        $c = JSSocial_Config::youtube_connection();
        if ($write && !self::can_write($c)) { throw new RuntimeException('YouTube erneut verbinden und Schreibrechte für Uploads und Playlists erteilen.'); }
        return $c;
    }
    public static function verify(): array {
        $c = JSSocial_Config::youtube_connection();
        if (empty($c['refresh_token']) || empty($c['channel']['id'])) { throw new RuntimeException('YouTube ist noch nicht verbunden.'); }
        if (empty($c['access_token']) || ($c['expires_at'] ?? 0) <= time() + 60) {
            $t = self::token(['grant_type' => 'refresh_token', 'refresh_token' => $c['refresh_token']]);
            if (empty($t['access_token']) || empty($t['expires_in'])) { throw new RuntimeException('Google-Zugriff konnte nicht erneuert werden.'); }
            $c['access_token'] = $t['access_token']; $c['expires_at'] = time() + (int)$t['expires_in'];
            if (!empty($t['refresh_token'])) { $c['refresh_token'] = $t['refresh_token']; }
        }
        $channel = self::channel($c['access_token']);
        if ($channel['id'] !== $c['channel']['id']) { throw new RuntimeException('Google meldet einen anderen Kanal. Neu verbinden und Ziel prüfen.'); }
        $c['channel'] = $channel; $c['checked_at'] = time();
        JSSocial_Config::save_youtube_connection($c);
        return $channel;
    }
    public static function callback_action(): void {
        self::guard(); nocache_headers(); header('Referrer-Policy: no-referrer');
        try { self::complete(wp_unslash($_GET)); self::finish('YouTube-Kanal verbunden. Uploads und Playlists können über ChatGPT mit Vorschau und Freigabe verwaltet werden; erteilte Berechtigungen im Status prüfen.'); }
        catch (Throwable $e) { self::finish($e->getMessage()); }
    }
    public static function admin_action(): void {
        self::guard(); check_admin_referer('jssocial_youtube');
        $a = wp_unslash($_POST);
        try {
            switch ($a['op'] ?? '') {
                case 'save': JSSocial_Config::save_youtube_credentials(trim((string)($a['client_id'] ?? '')), trim((string)($a['client_secret'] ?? ''))); self::finish('Google-Zugangsdaten verschlüsselt gespeichert. Jetzt YouTube verbinden.'); break;
                case 'connect': wp_redirect(self::authorization_url()); exit;
                case 'verify': $c = self::verify(); self::finish('YouTube-Kanal bestätigt: '.$c['title']); break;
                case 'disconnect': delete_option('jssocial_youtube_connection'); delete_transient('jssocial_yt_state_'.get_current_user_id()); self::finish('YouTube-Verbindung lokal entfernt.'); break;
                default: throw new InvalidArgumentException('Unbekannte YouTube-Aktion.');
            }
        } catch (Throwable $e) { self::finish($e->getMessage()); }
    }
    private static function form(string $op): void {
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">'; wp_nonce_field('jssocial_youtube');
        echo '<input type="hidden" name="action" value="jssocial_youtube_action"><input type="hidden" name="op" value="'.esc_attr($op).'">';
    }
    public static function render_setup(): void {
        $s = self::status();
        echo '<section class="jss-card"><h2>YouTube · Google-Verbindung</h2><p>Kanal verbinden und prüfen. Für Uploads und Playlists bitte erneut verbinden und die zusätzlichen Google-Rechte erteilen. Uploads (MP4 bis 12 MB) und Playlist-Änderungen erfolgen über ChatGPT nach Vorschau und Freigabe.</p><p>Autorisierte Weiterleitungs-URI:</p><code class="jss-url">'.esc_html(self::callback()).'</code>';
        self::form('save');
        echo '<label class="jss-field">Google Client-ID<input name="client_id" type="text" value="'.esc_attr((string)get_option('jssocial_youtube_client_id', '')).'" required></label><label class="jss-field">Google Clientschlüssel<input name="client_secret" type="password" value="" autocomplete="new-password" placeholder="'.($s['configured'] ? 'Gespeichert – leer lassen zum Beibehalten' : 'Hier eintragen').'" ></label><p>Clientschlüssel und Kanalzugriff werden verschlüsselt gespeichert.</p><button class="button">Google-Konfiguration speichern</button></form>';
        if ($s['configured']) { self::form('connect'); echo '<p><button class="button button-primary">Mit YouTube verbinden / erneuern</button></p></form>'; }
        if ($s['connected']) {
            echo '<p>Kanal: <a href="'.esc_url($s['channel']['url']).'">'.esc_html($s['channel']['title']).'</a> · '.esc_html($s['channel']['id']).'</p><p>Zuletzt bestätigt: '.esc_html($s['checked_at']).'</p>';
            self::form('verify'); echo '<p><button class="button">YouTube-Kanal prüfen</button></p></form>';
            self::form('disconnect'); echo '<button class="button">YouTube-Verbindung lokal entfernen</button></form>';
        }
        echo '</section>';
    }
}
