<?php
defined('ABSPATH') || exit;
final class JSSocial_Store {
    private static bool $locked = false;
    private static bool $changed = false;
    public static function gate(): JSSocial_Gate { return JSSocial_Gate::site(ABSPATH . 'wp-load.php'); }
    private static function changing(): void {
        if (!self::$changed) {
            // This must succeed BEFORE any DB mutation. A crash leaves a dirty hint, never a later wake-up.
            self::gate()->invalidate(); self::$changed = true;
        }
    }
    public static function resync_on_unlock(): void { self::assert_lock(); self::changing(); }
    private static function sync_schedule(): void {
        global $wpdb;
        self::assert_lock();
        $next = $wpdb->get_var('SELECT MIN(next_run) FROM ' . self::table() . " WHERE state IN ('queued','running')");
        if (!empty($wpdb->last_error)) { throw new RuntimeException('Warteschlange konnte nicht geprüft werden.'); }
        self::gate()->queue($next === null ? null : (int) $next);
    }
    public static function table(): string { global $wpdb; return $wpdb->prefix . 'jssocial_jobs'; }
    private static function lock_name(): string { return 'jssocial_' . md5(self::table() . (defined('DB_NAME') ? DB_NAME : '')); }
    public static function install(): void {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = self::table(); $charset = $wpdb->get_charset_collate();
        dbDelta("CREATE TABLE $table (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            request_key varchar(64) NOT NULL,
            state varchar(24) NOT NULL DEFAULT 'draft',
            due bigint(20) unsigned NOT NULL DEFAULT 0,
            next_run bigint(20) unsigned NOT NULL DEFAULT 0,
            revision bigint(20) unsigned NOT NULL DEFAULT 1,
            document longtext NOT NULL,
            updated bigint(20) unsigned NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY request_key (request_key),
            KEY queue (state,next_run)
        ) $charset;");
        update_option('jssocial_schema', 1, false);
    }
    public static function lock(callable $callback) {
        global $wpdb;
        if (self::$locked) { throw new RuntimeException('Verschachtelte Warteschlangensperre.'); }
        if ((string) $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 0)', self::lock_name())) !== '1') { throw new RuntimeException('Warteschlange wird gerade bearbeitet. Bitte in Kürze erneut versuchen.'); }
        self::$locked = true; self::$changed = false;
        try { return $callback(); }
        finally {
            try {
                if (self::$changed) { self::sync_schedule(); }
            } catch (Throwable $e) {
                // A dirty hint forces a full scan on the next minute. Do not mask a publication result.
                error_log('Jesusschmuck Social: Termin-Hinweis konnte nicht aktualisiert werden; nächste CLI-Prüfung erforderlich.');
            } finally {
                $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', self::lock_name()));
                self::$locked = false; self::$changed = false;
            }
        }
    }
    public static function assert_lock(): void {
        global $wpdb;
        $held = $wpdb->get_var($wpdb->prepare('SELECT IS_USED_LOCK(%s) = CONNECTION_ID()', self::lock_name()));
        if (!self::$locked || (string) $held !== '1') { throw new RuntimeException('Datenbanksperre verloren. Vorgang sicher angehalten.'); }
    }
    public static function get(int $id): array {
        global $wpdb;
        $raw = $wpdb->get_var($wpdb->prepare('SELECT document FROM ' . self::table() . ' WHERE id=%d', $id));
        if (!$raw) { throw new InvalidArgumentException('Beitrag nicht gefunden.'); }
        return json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
    }
    public static function by_key(string $key): ?array {
        global $wpdb;
        $id = $wpdb->get_var($wpdb->prepare('SELECT id FROM ' . self::table() . ' WHERE request_key=%s', $key));
        return $id ? self::get((int) $id) : null;
    }
    public static function insert(array $job): array {
        global $wpdb; self::assert_lock(); self::changing();
        $ok = $wpdb->insert(self::table(), ['request_key' => $job['request_key'], 'state' => 'draft', 'due' => 0, 'revision' => 1, 'document' => '{}', 'updated' => time()]);
        if ($ok === false) { throw new RuntimeException('Beitrag konnte nicht angelegt werden.'); }
        $job['id'] = (int) $wpdb->insert_id; self::save($job); return $job;
    }
    public static function save(array $job): void {
        global $wpdb; self::assert_lock();
        $document = wp_json_encode($job, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($document === false) { throw new RuntimeException('Beitrag konnte nicht serialisiert werden.'); }
        $next = array_map(fn($r) => (int) ($r['next_at'] ?? 0), array_filter($job['results'], fn($r) => in_array($r['state'], ['pending','processing','verifying'], true)));
        $next_run = max($job['due'], $next ? min($next) : 0);
        self::changing();
        $ok = $wpdb->update(self::table(), ['state' => $job['state'], 'due' => $job['due'], 'next_run' => $next_run, 'revision' => $job['revision'], 'document' => $document, 'updated' => time()], ['id' => $job['id']]);
        if ($ok === false) { throw new RuntimeException('Status konnte nicht gespeichert werden. Keine weitere API-Aktion.'); }
        if ($ok === 0 && $wpdb->get_var($wpdb->prepare('SELECT document FROM ' . self::table() . ' WHERE id=%d', $job['id'])) !== $document) { throw new RuntimeException('Beitragsdatensatz fehlt. Keine weitere API-Aktion.'); }
    }
    public static function listing(int $limit = 30, int $before = 0): array {
        global $wpdb; $limit = max(1, min(100, $limit));
        $q = 'SELECT document FROM ' . self::table() . ($before ? $wpdb->prepare(' WHERE id < %d', $before) : '') . ' ORDER BY id DESC LIMIT ' . $limit;
        return array_map(fn($v) => json_decode($v, true, 512, JSON_THROW_ON_ERROR), $wpdb->get_col($q));
    }
    public static function due(): array {
        global $wpdb;
        return array_map('intval', $wpdb->get_col($wpdb->prepare('SELECT id FROM ' . self::table() . " WHERE state IN ('queued','running') AND next_run <= %d ORDER BY next_run,id LIMIT 8", time())));
    }
    public static function event(array &$job, string $event): void {
        $job['audit'][] = ['at' => gmdate('c'), 'actor' => get_current_user_id() ?: 'mcp/worker', 'event' => $event];
        $job['audit'] = array_slice($job['audit'], -100);
    }
}
