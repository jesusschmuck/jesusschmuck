<?php
defined('ABSPATH') || exit;
class JSSocial_Meta_Error extends RuntimeException {
    public bool $ambiguous;
    public function __construct(string $message, bool $ambiguous = false) { parent::__construct($message); $this->ambiguous = $ambiguous; }
}
class JSSocial_Meta {
    public function request(string $method, string $path, array $params = [], string $token = '', bool $upload = false): array {
        if ($method === 'POST') { JSSocial_Store::assert_lock(); }
        if ($upload) {
            if (!preg_match('~^https://rupload\.facebook\.com/video-upload/v[0-9]+\.0/[0-9]+$~', $path)) { throw new RuntimeException('Ungültiger Meta-Upload-Endpunkt.'); }
            $url = $path;
        } else {
            if (!preg_match('~^[a-zA-Z0-9_/-]+$~', $path)) { throw new InvalidArgumentException('Ungültiger API-Pfad.'); }
            $url = 'https://graph.facebook.com/' . JSSocial_Config::version() . '/' . ltrim($path, '/');
            if ($token && JSSocial_Config::app_secret()) { $params['appsecret_proof'] = hash_hmac('sha256', $token, JSSocial_Config::app_secret()); }
        }
        $headers = ['Accept' => 'application/json'];
        if ($token) { $headers['Authorization'] = ($upload ? 'OAuth ' : 'Bearer ') . $token; }
        $args = ['method' => $method, 'timeout' => 25, 'redirection' => 0, 'sslverify' => true, 'headers' => $headers, 'limit_response_size' => 2 * 1024 * 1024];
        if ($upload) { $args['headers']['file_url'] = $params['file_url']; }
        elseif ($method === 'GET') { $url = add_query_arg($params, $url); }
        else { $args['body'] = $params; }
        $res = wp_remote_request($url, $args);
        if (is_wp_error($res)) { throw new JSSocial_Meta_Error('Meta nicht erreichbar (Netzwerk/Timeout). Bei einer Veröffentlichungsanfrage ist das Ergebnis zunächst unklar.', $method === 'POST'); }
        $http = wp_remote_retrieve_response_code($res); $body = json_decode(wp_remote_retrieve_body($res), true);
        if (!is_array($body)) { throw new JSSocial_Meta_Error('Meta lieferte keine gültige JSON-Antwort (HTTP ' . $http . ').', $method === 'POST'); }
        if (isset($body['error']) || $http < 200 || $http >= 300) {
            $code = (int) ($body['error']['code'] ?? 0); $sub = (int) ($body['error']['error_subcode'] ?? 0);
            $help = match ($code) { 190 => 'Meta-Anmeldung abgelaufen oder widerrufen. Erneut verbinden.', 10, 200 => 'Meta-Berechtigung oder Kontofreischaltung fehlt.', 4, 17, 32, 613 => 'Meta-Anfragelimit erreicht. Später erneut prüfen.', 100 => 'Meta lehnt Parameter, Medium oder Konto ab.', default => 'Meta hat die Anfrage abgelehnt.' };
            $detail = sanitize_text_field((string) ($body['error']['error_user_msg'] ?? $body['error']['message'] ?? ''));
            foreach ([$token, JSSocial_Config::app_secret(), $params['input_token'] ?? '', $params['fb_exchange_token'] ?? '', $params['code'] ?? ''] as $secret) { if ($secret) { $detail = str_replace($secret, '[entfernt]', $detail); } }
            $detail = preg_replace('/(access_token|client_secret|appsecret_proof)[=:][^\s&]+/i', '$1=[entfernt]', $detail);
            throw new JSSocial_Meta_Error($help . ' Code ' . $code . '/' . $sub . ', HTTP ' . $http . '. ' . mb_substr($detail, 0, 350), $http >= 500 || $http === 429 || in_array($code, [1,2], true) || !empty($body['error']['is_transient']));
        }
        return $body;
    }
    public function user(string $method, string $path, array $params = []): array {
        $c = JSSocial_Config::connection();
        if (empty($c['user_token'])) { throw new RuntimeException('Facebook Login ist noch nicht verbunden.'); }
        // Meta validates the credential; a cached login expiry is not authoritative.
        return $this->request($method, $path, $params, $c['user_token']);
    }
    public function page(string $method, string $path, array $params = [], bool $upload = false): array {
        $p = JSSocial_Config::selected();
        return $this->request($method, $path, $params, $p['access_token'], $upload);
    }
    public function verify(): array {
        $c = JSSocial_Config::connection(); $p = JSSocial_Config::selected();
        $user = $this->token_info($c['user_token'] ?? '');
        $page_token = $this->token_info($p['access_token'] ?? '');
        $granted = $user['scopes']; $page_granted = $page_token['scopes'];
        if (!$page_token['valid']) { throw new RuntimeException('Meta-Seitenzugang ungültig oder abgelaufen. Erneut verbinden.'); }
        $page = $this->page('GET', $p['id'], ['fields' => 'id,name,instagram_business_account{id,username}']);
        if ((string)($page['id'] ?? '') !== (string)$p['id']) { throw new RuntimeException('Meta-Zielseite stimmt nicht überein.'); }
        $out = ['checked_at' => time(), 'page_id' => $page['id'], 'ig_id' => $page['instagram_business_account']['id'] ?? '', 'permissions' => $granted, 'missing_permissions' => array_values(array_diff(JSSocial_Config::scopes(), $granted)), 'tasks' => $p['tasks'] ?? []];
        $out['token_health'] = ['user' => $user, 'page' => $page_token];
        $out['facebook_ready'] = !array_diff(['pages_read_engagement','pages_manage_posts'], $page_granted) && (bool) array_intersect(['MANAGE','CREATE_CONTENT'], $out['tasks']);
        $out['instagram_ready'] = $user['valid'] && $out['ig_id'] && !array_diff(['instagram_basic','instagram_content_publish','pages_read_engagement'], $granted) && (bool) array_intersect(['MANAGE','CREATE_CONTENT'], $out['tasks']);
        if (JSSocial_Config::product_tags_enabled() && $out['ig_id']) {
            try {
                $eligibility = $this->user('GET', $out['ig_id'], ['fields' => 'shopping_product_tag_eligibility']);
                $out['product_tag_eligible'] = ($eligibility['shopping_product_tag_eligibility'] ?? false) === true;
                if ($out['product_tag_eligible']) { $out['available_catalogs'] = $this->user('GET', $out['ig_id'] . '/available_catalogs')['data'] ?? []; }
            } catch (Throwable $e) { $out['product_tag_eligible'] = false; $out['product_tag_message'] = $e->getMessage(); }
        }
        update_option('jssocial_verified', $out, false); return $out;
    }
    public function token_info(string $token): array {
        if (!$token) { throw new RuntimeException('Meta-Zugang fehlt.'); }
        $r = $this->request('GET', 'debug_token', ['input_token' => $token], JSSocial_Config::app_id() . '|' . JSSocial_Config::app_secret());
        $d = $r['data'] ?? [];
        if (!array_key_exists('is_valid', $d) || ($d['is_valid'] !== false && (string)($d['app_id'] ?? '') !== (string)JSSocial_Config::app_id())) { throw new RuntimeException('Meta-Zugang konnte nicht eindeutig geprüft werden. Später erneut prüfen.'); }
        $expiry = isset($d['expires_at']) ? (int)$d['expires_at'] : null;
        $access = isset($d['data_access_expires_at']) ? (int)$d['data_access_expires_at'] : null;
        return ['valid' => $d['is_valid'] === true && (!$expiry || $expiry > time()) && (!$access || $access > time()),
            'expires_at' => $expiry, 'data_access_expires_at' => $access,
            'expiry_status' => $expiry === null ? 'unknown' : ($expiry === 0 ? 'no_fixed_expiry' : 'dated'),
            'scopes' => array_values(array_filter($d['scopes'] ?? [], 'is_string')), 'checked_at' => time()];
    }
    public static function assert_schedule(array $verification, array $platforms, int $due): void {
        foreach ($platforms as $platform) {
            $key = $platform === 'facebook' ? 'page' : 'user';
            $info = $verification['token_health'][$key] ?? [];
            if (empty($info['valid'])) { throw new RuntimeException('Meta-Zugang nicht gültig: ' . $platform); }
            foreach (['expires_at','data_access_expires_at'] as $field) {
                if (!empty($info[$field]) && $info[$field] <= ($due ?: time()) + 600) { throw new RuntimeException('Meta-Zugang für ' . $platform . ' läuft vor dem Termin ab. Erneut verbinden.'); }
            }
            if (($info['expiry_status'] ?? 'unknown') === 'unknown') { throw new RuntimeException('Meta-Ablaufdatum für ' . $platform . ' unbekannt. Verbindung erneut prüfen.'); }
        }
    }
    public function audio(string $query = '', string $type = 'music', string $id = ''): array {
        if (!in_array($type, ['music','original_sound'], true)) { throw new InvalidArgumentException('Ungültiger Audiotyp.'); }
        $ig = JSSocial_Config::targets()['instagram']['id'];
        if (!$ig) { throw new RuntimeException('Kein verbundenes Instagram-Profikonto.'); }
        $params = ['user_id' => $ig];
        if ($id) { if (!ctype_digit($id)) { throw new InvalidArgumentException('Ungültige Audio-ID.'); } }
        else { $params['audio_type'] = $type; if ($query !== '') { $params['search_query'] = $query; } }
        $r = $this->user('GET', $id ?: 'ig_audio', $params);
        $rows = $id ? [$r] : ($r['audio'] ?? $r['data'] ?? []); $out = [];
        foreach ($rows as $a) {
            if (empty($a['audio_id'])) { continue; }
            $track = array_intersect_key($a, array_flip(['audio_id','title','display_artist','ig_username','audio_type','duration_in_ms','download_url','on_platform_audio_preview_link','is_ads_eligible']));
            $track['rights_status'] = 'unverified';
            $track['rights_note'] = 'API-Verfügbarkeit und Ads-Flag sind kein Lizenznachweis. Konkrete Nutzungsrechte für diesen Beitrag separat dokumentieren.';
            $out[] = $track;
        }
        return ['tracks' => $out, 'mode' => $id !== '' ? 'metadata' : ($query === '' ? 'trending' : 'search'), 'checked_at' => gmdate('c'), 'limitations' => ['Auswahl kann von Instagram-App abweichen.', 'Vorhör-URL kann fehlen oder nach etwa 1,5 Tagen ablaufen.', 'Keine Vorschau des gemischten Reels.', 'Facebook bekommt nur den Originalton der Datei.', 'Kommerzielle Rechte separat prüfen; is_ads_eligible kann fehlen. Sound Collection ist keine allgemeine Freigabe aller Suchtreffer.']];
    }
}
