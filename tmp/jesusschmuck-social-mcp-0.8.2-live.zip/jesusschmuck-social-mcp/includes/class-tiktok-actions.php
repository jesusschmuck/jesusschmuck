<?php
defined('ABSPATH') || exit;
/** Inbox handoff only. Never Direct Post; uncertain writes are not retried. */
final class JSSocial_TikTok_Actions {
    private static function locked(callable $fn): array {
        global $wpdb;
        $key='jssocial_tt_'.substr(hash('sha256',$wpdb->prefix),0,32);
        if ((string)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 0)',$key))!=='1') { throw new RuntimeException('TikTok-Auftrag wird gerade bearbeitet. Später Status prüfen.'); }
        try { return $fn(); } finally { $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$key)); }
    }
    private static function access(): array {
        JSSocial_TikTok::verify(); $c=JSSocial_Config::tiktok_connection();
        if (!in_array('video.upload',explode(',',$c['scope']??''),true)) { throw new RuntimeException('TikTok-Upload-Berechtigung fehlt.'); }
        return $c;
    }
    private static function api(array $c,string $path,array $body): array {
        $r=wp_remote_post('https://open.tiktokapis.com/v2/post/publish/'.$path,[
            'timeout'=>15,'redirection'=>0,'headers'=>['Authorization'=>'Bearer '.$c['access_token'],'Content-Type'=>'application/json; charset=UTF-8'],'body'=>wp_json_encode($body),
        ]);
        if (is_wp_error($r)) { throw new RuntimeException('TikTok-Antwort fehlt. Keine automatische Wiederholung; Auftragsstatus prüfen.'); }
        $status=wp_remote_retrieve_response_code($r); $d=json_decode(wp_remote_retrieve_body($r),true);
        if ($status<200 || $status>=300 || !is_array($d) || ($d['error']['code']??'')!=='ok' || !is_array($d['data']??null)) {
            $code=$d['error']['code']??'';
            $known=['spam_risk_too_many_pending_share','spam_risk_user_banned_from_posting','scope_not_authorized','access_token_invalid','rate_limit_exceeded','invalid_param'];
            throw new RuntimeException('TikTok-Anfrage nicht bestätigt (HTTP '.(int)$status.(in_array($code,$known,true)?', '.$code:'').'). Status prüfen; nicht als neuen Auftrag wiederholen.');
        }
        return $d['data'];
    }
    private static function asset(int $id): array {
        $x=JSSocial_Service::asset($id,'reel',[]);
        if ($x['bytes']<=0 || $x['bytes']>12*1024*1024 || min($x['width'],$x['height'])<360 || max($x['width'],$x['height'])>4096) { throw new InvalidArgumentException('TikTok-Testupload: MP4 bis 12 MB, 3–900 Sekunden und 360–4096 Pixel je Seite.'); }
        return $x;
    }
    private static function text(string $s,int $max): string {
        $s=trim($s); if ($s==='' || strlen($s)>$max || str_contains($s,"\0")) { throw new InvalidArgumentException('Text fehlt oder ist zu lang.'); } return $s;
    }
    private static function public_op(array $op): array {
        return array_intersect_key($op,array_flip(['id','preview','preview_hash','state','created_at','approved_at','result','error','next_action','upload_target']));
    }
    public static function prepare(array $a): array {
        return self::locked(function() use($a) {
            $id=hash('sha256',$a['request_key']); $fingerprint=hash('sha256',wp_json_encode($a));
            $old=JSSocial_Config::tiktok_operation($id);
            if ($old) { if ($old['input_hash']!==$fingerprint) { throw new RuntimeException('request_key gehört zu einer anderen Vorschau.'); } return self::public_op($old); }
            if (($a['rights_confirmed']??false)!==true) { throw new InvalidArgumentException('Video- und Audiorechte für TikTok ausdrücklich bestätigen.'); }
            $c=self::access();
            $p=['account'=>$c['account'],'mode'=>'sandbox','operation'=>'inbox_upload','asset'=>self::asset($a['attachment_id']),
                'description_to_copy'=>self::text($a['description'],8000),'rights_basis'=>self::text($a['rights_basis'],2000),
                'notice'=>'Nur Videoübergabe. TikTok-App → Postfach-Benachrichtigung öffnen und Beitrag dort fertigstellen. Beschreibung separat kopieren. Keine automatische Veröffentlichung oder Terminplanung.'];
            $op=['id'=>$id,'input_hash'=>$fingerprint,'client_key'=>JSSocial_Config::tiktok_credentials()['client_key'],'preview'=>$p,'preview_hash'=>hash('sha256',wp_json_encode($p)),'state'=>'draft','created_at'=>gmdate('c')];
            JSSocial_Config::tiktok_operation($id,$op); return self::public_op($op);
        });
    }
    public static function preview(string $id): array {
        $op=JSSocial_Config::tiktok_operation($id);
        if (!$op) { throw new InvalidArgumentException('TikTok-Auftrag nicht gefunden.'); } return self::public_op($op);
    }
    private static function same_account(array $op,array $c): void {
        if ($op['preview']['account']['id']!==$c['account']['id'] || $op['client_key']!==JSSocial_Config::tiktok_credentials()['client_key']) { throw new RuntimeException('TikTok-App/Konto geändert. Neue Vorschau erforderlich.'); }
    }
    public static function execute(array $a): array {
        return self::locked(function() use($a) {
            $op=JSSocial_Config::tiktok_operation($a['operation_id']);
            if (!$op || !hash_equals($op['preview_hash'],$a['preview_hash'])) { throw new RuntimeException('Vorschau fehlt oder wurde geändert.'); }
            if (($a['confirm']??false)!==true || trim($a['approval_evidence']??'')==='') { throw new RuntimeException('Freigabe der gezeigten Vorschau fehlt.'); }
            // Only a persisted pre-transfer block can resume, never a started/uncertain PUT.
            $resume=in_array($op['state'],['unknown','processing'],true) && ($op['transfer_attempted']??null)===false && !empty($op['upload_url']) && !empty($op['publish_id']);
            if ($op['state']!=='draft' && !$resume) { return self::public_op($op); }
            $c=self::access(); self::same_account($op,$c);
            $p=$op['preview'];$asset=self::asset($p['asset']['attachment_id']);
            if ($asset['sha256']!==$p['asset']['sha256'] || $asset['bytes']!==$p['asset']['bytes']) { throw new RuntimeException('Datei geändert. Neue Vorschau erforderlich.'); }
            $bytes=file_get_contents(get_attached_file($asset['attachment_id']));
            if ($bytes===false || strlen($bytes)!==$asset['bytes'] || hash('sha256',$bytes)!==$asset['sha256']) { throw new RuntimeException('Videodatei konnte nicht unverändert gelesen werden.'); }
            if ($resume) {
                $d=self::api($c,'status/fetch/',['publish_id'=>$op['publish_id']]);
                if (($d['status']??'')!=='PROCESSING_UPLOAD' || ($d['uploaded_bytes']??null)!==0 || time()-strtotime($op['approved_at'])>=3500) {
                    $op['next_action']='Fortsetzung nicht sicher möglich. Status prüfen; keine Neuanlage.';
                    JSSocial_Config::tiktok_operation($op['id'],$op); return self::public_op($op);
                }
            }
            $op['approved_at']=$op['approved_at']??gmdate('c');$op['approval_evidence']=self::text($a['approval_evidence'],4000);
            $op['state']='unknown';$op['next_action']='Auftragsstatus lesen; keine automatische erneute Übertragung.';
            JSSocial_Config::tiktok_operation($op['id'],$op); // Durable BEFORE non-idempotent initialization.
            try {
                if (!$resume) {
                $d=self::api($c,'inbox/video/init/',['source_info'=>['source'=>'FILE_UPLOAD','video_size'=>$asset['bytes'],'chunk_size'=>$asset['bytes'],'total_chunk_count'=>1]]);
                if (!is_string($d['publish_id']??null) || $d['publish_id']==='' || strlen($d['publish_id'])>64) { throw new RuntimeException('TikTok-Auftrags-ID fehlt.'); }
                $op['publish_id']=$d['publish_id']; JSSocial_Config::tiktok_operation($op['id'],$op);
                $op['upload_url']=is_string($d['upload_url']??null)?$d['upload_url']:'';
                }
                $url=$op['upload_url']??''; $u=is_string($url)?wp_parse_url($url):false;
                // Store signed URLs encrypted; expose only the host and validation flags.
                $op['upload_url']=is_string($url)?$url:'';
                $op['upload_target']=['host'=>is_array($u)&&preg_match('/^[a-zA-Z0-9.-]{1,253}$/D',$u['host']??'')?$u['host']:'invalid','https'=>($u['scheme']??'')==='https','video_path'=>($u['path']??'')==='/video/','has_port'=>isset($u['port'])];
                $op['transfer_attempted']=false;
                JSSocial_Config::tiktok_operation($op['id'],$op);
                // Fixed API-owned hosts only, no token forwarding, no redirects.
                if (!$u || ($u['scheme']??'')!=='https' || !in_array($u['host']??'',['open-upload.tiktokapis.com','upload.us.tiktokapis.com','open-upload-i18n.tiktokapis.com'],true) || !str_starts_with($u['path']??'','/') || isset($u['user']) || isset($u['pass']) || isset($u['port']) || isset($u['fragment'])) { throw new RuntimeException('TikTok-Uploadziel nicht freigegeben. Status prüfen.'); }
                $op['transfer_attempted']=true; JSSocial_Config::tiktok_operation($op['id'],$op);
                $r=wp_remote_request($url,['method'=>'PUT','timeout'=>20,'redirection'=>0,'headers'=>['Content-Type'=>'video/mp4','Content-Length'=>(string)$asset['bytes'],'Content-Range'=>'bytes 0-'.($asset['bytes']-1).'/'.$asset['bytes']],'body'=>$bytes]);
                if (is_wp_error($r) || wp_remote_retrieve_response_code($r)!==201) { throw new RuntimeException('Videoübertragung nicht bestätigt. Nur Auftragsstatus prüfen; keinen neuen Upload starten.'); }
                unset($op['error'],$op['upload_url']);
                $op['state']='processing';$op['result']=['transferred_bytes'=>$asset['bytes'],'published'=>false];
                $op['next_action']='TikTok-Auftragsstatus prüfen. Erst SEND_TO_USER_INBOX bestätigt die Übergabe ins Postfach.';
            } catch (Throwable $e) { $op['error']=$e->getMessage(); }
            JSSocial_Config::tiktok_operation($op['id'],$op);return self::public_op($op);
        });
    }
    public static function status(string $id): array {
        return self::locked(function() use($id) {
            $op=JSSocial_Config::tiktok_operation($id);
            if (!$op) { throw new InvalidArgumentException('TikTok-Auftrag nicht gefunden.'); }
            if (empty($op['publish_id'])) { return self::public_op($op); }
            $c=self::access();self::same_account($op,$c);
            $d=self::api($c,'status/fetch/',['publish_id'=>$op['publish_id']]);
            $state=$d['status']??'';
            $states=['PROCESSING_UPLOAD'=>'processing','PROCESSING_DOWNLOAD'=>'processing','SEND_TO_USER_INBOX'=>'inbox_ready','PUBLISH_COMPLETE'=>'published','FAILED'=>'failed'];
            if (!isset($states[$state])) { throw new RuntimeException('TikTok hat keinen bekannten Verarbeitungsstatus geliefert.'); }
            $op['state']=$states[$state];$op['result']=['provider_status'=>$state,'published'=>$state==='PUBLISH_COMPLETE','checked_at'=>gmdate('c')];
            if (isset($d['uploaded_bytes']) && is_int($d['uploaded_bytes'])) { $op['result']['uploaded_bytes']=$d['uploaded_bytes']; }
            if ($state==='FAILED' && is_string($d['fail_reason']??null) && preg_match('/^[a-z0-9_]{1,120}$/D',$d['fail_reason'])) { $op['result']['fail_reason']=$d['fail_reason']; }
            $op['next_action']=$state==='SEND_TO_USER_INBOX'?'TikTok-App öffnen → Postfach-Benachrichtigung → Video fertigstellen. Beschreibung aus der Vorschau kopieren.':($state==='PUBLISH_COMPLETE'?'Manuelle Veröffentlichung durch TikTok bestätigt.':($state==='FAILED'?'Fehler prüfen; keine automatische Neuanlage.':'Später erneut Status prüfen.'));
            if ($state!=='PROCESSING_UPLOAD') { unset($op['error']); } JSSocial_Config::tiktok_operation($id,$op);return self::public_op($op);
        });
    }
}
