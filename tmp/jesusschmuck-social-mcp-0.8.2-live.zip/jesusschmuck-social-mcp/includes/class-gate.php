<?php
// Deliberately independent of WordPress: the CLI runner loads only this class while idle.
final class JSSocial_Gate {
    public const AUDIT_SECONDS = 3600;
    private const PREFIX = "<?php http_response_code(404); exit; ?>\n";
    public function __construct(private string $directory, private string $context) {}
    public static function site(string $wp_load): self {
        $plugin = dirname(__DIR__);
        $context = hash('sha256', $plugin . '|' . (realpath($wp_load) ?: $wp_load));
        return new self(dirname($plugin, 2) . '/jssocial-runtime-' . substr($context, 0, 16), $context);
    }
    public function path(): string { return $this->directory; }
    private function defaults(): array {
        return ['schema' => 1, 'context' => $this->context, 'dirty' => true, 'next_due' => null,
            'last_full' => 0, 'last' => 0, 'previous' => 0, 'failed_at' => 0, 'running_at' => 0];
    }
    public function read(): array {
        $raw = @file_get_contents($this->directory . '/state.php', false, null, 0, 8193);
        if (!is_string($raw) || strlen($raw) > 8192 || !str_starts_with($raw, self::PREFIX)) { return $this->defaults(); }
        $s = json_decode(substr($raw, strlen(self::PREFIX)), true);
        if (!is_array($s) || ($s['schema'] ?? null) !== 1 || ($s['context'] ?? null) !== $this->context
            || !is_bool($s['dirty'] ?? null) || !array_key_exists('next_due', $s)
            || !($s['next_due'] === null || (is_int($s['next_due']) && $s['next_due'] >= 0))) { return $this->defaults(); }
        foreach (['last_full','last','previous','failed_at','running_at'] as $key) {
            if (!isset($s[$key]) || !is_int($s[$key]) || $s[$key] < 0) { return $this->defaults(); }
        }
        $checksum = $s['checksum'] ?? ''; unset($s['checksum']);
        if (!is_string($checksum) || !hash_equals(hash('sha256', json_encode($s)), $checksum)) { return $this->defaults(); }
        return $s;
    }
    private function ensure_directory(): void {
        if (!is_dir($this->directory) && !@mkdir($this->directory, 0700, true) && !is_dir($this->directory)) {
            throw new RuntimeException('Social-Zeitsteuerung: Laufzeitordner nicht beschreibbar. Cronjob und Website müssen unter demselben Systembenutzer laufen.');
        }
    }
    private function open_lock(string $name) {
        $this->ensure_directory();
        $h = @fopen($this->directory . '/' . $name, 'c');
        if (!$h || !@chmod($this->directory . '/' . $name, 0600)) {
            if ($h) { fclose($h); }
            throw new RuntimeException('Social-Zeitsteuerung: Dateisperre nicht verfügbar. Dateirechte und Systembenutzer prüfen.');
        }
        return $h;
    }
    // Keep the returned handle open for the entire invocation, including WordPress startup.
    public function runner_lock() {
        $h = $this->open_lock('runner.lock');
        if (!flock($h, LOCK_EX | LOCK_NB)) { fclose($h); return false; }
        return $h;
    }
    private function change(callable $callback): array {
        $lock = $this->open_lock('state.lock'); $tmp = null;
        try {
            if (!flock($lock, LOCK_EX)) { throw new RuntimeException('Social-Zeitsteuerung: Statusdatei konnte nicht gesperrt werden.'); }
            $s = $callback($this->read());
            $s['checksum'] = hash('sha256', json_encode($s));
            $data = self::PREFIX . json_encode($s, JSON_THROW_ON_ERROR);
            $tmp = $this->directory . '/state-' . bin2hex(random_bytes(8)) . '.php';
            $out = @fopen($tmp, 'x');
            if (!$out) { throw new RuntimeException('Social-Zeitsteuerung: Statusdatei konnte nicht angelegt werden.'); }
            try {
                if (!@chmod($tmp, 0600) || fwrite($out, $data) !== strlen($data) || !fflush($out)
                    || (function_exists('fsync') && !fsync($out))) {
                    throw new RuntimeException('Social-Zeitsteuerung: Statusdatei konnte nicht sicher geschrieben werden.');
                }
            } finally { fclose($out); }
            if (!@rename($tmp, $this->directory . '/state.php')) { throw new RuntimeException('Social-Zeitsteuerung: Statusdatei konnte nicht ersetzt werden.'); }
            return $s;
        } finally { if ($tmp && is_file($tmp)) { @unlink($tmp); } fclose($lock); }
    }
    public function invalidate(): void { $this->change(function ($s) { $s['dirty'] = true; return $s; }); }
    public function queue(?int $due): void {
        $this->change(function ($s) use ($due) { $s['next_due'] = $due; $s['dirty'] = false; return $s; });
    }
    public static function needs_wordpress(array $s, int $now): bool {
        return $s['dirty'] || !$s['last_full'] || $s['last_full'] > $now || $s['last'] > $now
            || $s['last_full'] <= $now - self::AUDIT_SECONDS || $s['failed_at'] > 0 || $s['running_at'] > 0
            || ($s['next_due'] !== null && $s['next_due'] <= $now);
    }
    private static function heartbeat(array $s, int $now): array {
        if (!$s['last'] || $now - $s['last'] >= 20 || $s['last'] > $now) {
            $s['previous'] = $s['last'] > $now ? 0 : $s['last']; $s['last'] = $now;
        }
        return $s;
    }
    public function probe(int $now): bool {
        $full = false;
        $this->change(function ($s) use ($now, &$full) {
            $full = self::needs_wordpress($s, $now);
            if ($full) { $s['running_at'] = $now; return $s; }
            return self::heartbeat($s, $now);
        });
        return $full;
    }
    public function complete(int $now): void {
        $this->change(function ($s) use ($now) {
            $s['last_full'] = $now; $s['running_at'] = 0; $s['failed_at'] = 0;
            // Do not touch dirty/next_due: a web request may have changed the queue meanwhile.
            return self::heartbeat($s, $now);
        });
    }
    public function failed(int $now): void {
        $this->change(function ($s) use ($now) { $s['failed_at'] = $now; $s['running_at'] = 0; $s['dirty'] = true; return $s; });
    }
}
