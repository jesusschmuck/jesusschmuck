# YouTube in Jesusschmuck Social 0.4.0

The existing MCP connection now provides four additional tools: js_social_youtube_list, js_social_youtube_prepare, js_social_youtube_preview and js_social_youtube_execute.

Operations: upload_video, create_playlist, add_to_playlist. Reads: playlists, playlist_items, uploads and individual live video status. Google authorization needs youtube.readonly plus youtube.force-ssl; existing read-only connections remain usable and explicitly report that reauthorization is required for writes.

Prepare stores an encrypted immutable draft without contacting a Google write endpoint. Execute requires the exact preview hash, confirm=true and actual user approval evidence. A dedicated MySQL advisory lock serializes YouTube changes. Durable uncertainty is written before playlist POSTs and resumable upload initialization. Lost playlist responses never cause automatic repeated insertions. Playlist assignment checks for an existing video entry. Upload resume uses the stored, encrypted Google session and server-confirmed byte range; it never starts a second upload automatically. Tokens and upload session URLs are excluded from public tool results.

Current limits: WordPress-local MP4, 12 MiB maximum, 3–900 seconds. Media can be imported through the existing js_social_upload_media tool. No YouTube scheduling, deletion, playlist reordering, or metadata editing in this release. Existing Meta queues are unchanged. Google API projects without a YouTube audit may be restricted to private uploads, independently of OAuth app verification. Private uploads and processing are never labeled public publication.

Validation: 64 YouTube/OAuth/action assertions using mocked Google responses plus 90 existing contract and 16 Meta token-health assertions. Covers replay and missing consent, OAuth scopes, stale preview/changed media, foreign channel resources, duplicate requests, ambiguous insert failure, private video status, resumable upload recovery, secret redaction/encryption, hostile session URLs, and concurrent access. Real uploads/playlist writes require renewed user OAuth consent and a separately approved concrete test.
