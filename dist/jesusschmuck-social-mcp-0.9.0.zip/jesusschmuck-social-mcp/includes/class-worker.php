<?php
defined('ABSPATH') || exit;
final class JSSocial_Worker {
    public static function health(): array {
        $h = get_option('jssocial_heartbeat', []); $last = (int) ($h['last'] ?? 0); $previous = (int) ($h['previous'] ?? 0);
        $gate = JSSocial_Store::gate()->read(); $light = $gate['last'] >= $last && $gate['last'] > 0;
        if ($light) { $last = $gate['last']; $previous = $gate['previous']; }
        $healthy = $last <= time() && $last > time() - 180 && $previous > 0 && $last - $previous >= 20 && $last - $previous <= 150;
        if ($gate['failed_at'] >= $last && $gate['failed_at'] > 0) { $healthy = false; }
        if ($gate['running_at'] && $gate['running_at'] < time() - 180) { $healthy = false; }
        return ['healthy' => $healthy, 'last_run_utc' => $last ? gmdate('c', $last) : null,
            'previous_run_utc' => $previous ? gmdate('c', $previous) : null,
            'last_full_run_utc' => $gate['last_full'] ? gmdate('c', $gate['last_full']) : null,
            'next_work_utc' => $gate['next_due'] === null ? null : gmdate('c', $gate['next_due']),
            'schedule_check_required' => $gate['dirty'], 'last_runner_failed' => $gate['failed_at'] > 0,
            'mode' => $light ? 'Leichter Server-Runner; WordPress nur bei Arbeit oder stündlicher Kontrollprüfung' : 'Server-CLI (kein besucherabhängiger WP-Cron)'];
    }
    public static function tick(): array {
        if (PHP_SAPI !== 'cli' && !(defined('WP_CLI') && WP_CLI)) { throw new RuntimeException('Worker darf nur serverseitig über CLI laufen.'); }
        $result = JSSocial_Store::lock(function () {
            JSSocial_Store::resync_on_unlock();
            $start = time();
            $count = 0;
            foreach (JSSocial_Store::due() as $id) {
                if (time() - $start > 45) { break; }
                $j = JSSocial_Store::get($id);
                if (($j['payload']['channel'] ?? '') === 'tiktok_direct') { JSSocial_TikTok_Direct::worker($j); $count++; continue; }
                if (!$j['approval'] || !hash_equals($j['approval']['hash'], JSSocial_Service::hash($j))) { $j['state'] = 'held'; JSSocial_Store::event($j, 'Freigabe fehlt oder stimmt nicht mehr.'); JSSocial_Store::save($j); continue; }
                $j['state'] = 'running'; JSSocial_Store::save($j);
                try { JSSocial_Service::assert_assets($j); }
                catch (Throwable $e) { $j['state'] = 'held'; JSSocial_Store::event($j, $e->getMessage()); JSSocial_Store::save($j); continue; }
                foreach ($j['payload']['platforms'] as $p) {
                    if (time() - $start > 45) { break; }
                    $r = $j['results'][$p];
                    if (in_array($r['state'], ['published','failed','unknown'], true) || ($r['next_at'] ?? 0) > time()) { continue; }
                    try { self::step($j, $p, new JSSocial_Meta()); }
                    catch (Throwable $e) {
                        // A durable intent always precedes publication. Crashes and uncertain responses never trigger a second publish POST.
                        $r = &$j['results'][$p];
                        if (!empty($r['publish_sent'])) {
                            $r['state'] = !empty($r['remote_id']) ? 'verifying' : 'unknown';
                            $r['stage'] = 'verify'; $r['error'] = $e->getMessage();
                        } else { $r['state'] = 'failed'; $r['error'] = $e->getMessage(); }
                        $r['next_at'] = time() + 60; unset($r);
                        JSSocial_Store::save($j);
                    }
                }
                self::aggregate($j); JSSocial_Store::save($j); $count++;
            }
            return ['processed_jobs' => $count];
        });
        $now = time(); $h = get_option('jssocial_heartbeat', []); $previous = (int) ($h['last'] ?? 0);
        if (empty($h['last']) || $now - (int) $h['last'] >= 20 || $h['last'] > $now) {
            update_option('jssocial_heartbeat', ['last' => $now, 'previous' => $previous > $now ? 0 : $previous], false);
        }
        $result['worker'] = self::health(); return $result;
    }
    public static function aggregate(array &$j): void {
        $states = array_column($j['results'], 'state');
        if (count(array_filter($states, fn($s) => $s === 'published')) === count($states)) { $j['state'] = 'published'; }
        elseif (array_intersect($states, ['pending','processing','verifying'])) { $j['state'] = 'running'; }
        elseif (in_array('published', $states, true)) { $j['state'] = 'partial'; }
        else { $j['state'] = in_array('unknown', $states, true) ? 'unknown' : 'failed'; }
    }
    private static function save(array &$j): void { JSSocial_Store::save($j); }
    public static function step(array &$j, string $p, JSSocial_Meta $api): void {
        $blockers = JSSocial_Service::music_blockers($j);
        if ($blockers) { throw new RuntimeException(implode(' ', $blockers)); }
        $d = $j['payload']; $r = &$j['results'][$p]; $o = $d['options'];
        $target = $d['targets'][$p]['id'];
        // After a crash this persisted marker is the source of truth, regardless of the previous stage.
        if (!empty($r['publish_sent']) && $r['state'] !== 'published') { self::verify_result($j, $p, $api); return; }
        if ($r['stage'] === 'new') {
            if ($p === 'instagram') {
                $params = ['caption' => $d['captions'][$p]];
                if ($d['kind'] === 'reel') {
                    $params += ['media_type' => 'REELS', 'video_url' => $d['asset']['url'], 'share_to_feed' => $o['share_to_feed'] ? 'true' : 'false'];
                    if (isset($o['cover'])) { $params['cover_url'] = $o['cover']['url']; }
                    elseif (isset($o['thumb_offset'])) { $params['thumb_offset'] = $o['thumb_offset']; }
                    if (isset($o['audio'])) { $params['audio_configuration'] = wp_json_encode(array_intersect_key($o['audio'], array_flip(['audio_id','audio_volume','video_volume']))); }
                } else { $params['image_url'] = $d['asset']['url']; }
                if (isset($o['product_tags'])) { $params['product_tags'] = wp_json_encode($o['product_tags']); }
                $res = $api->user('POST', $target . '/media', $params);
                if (empty($res['id'])) { throw new RuntimeException('Meta lieferte keine Container-ID.'); }
                $r['remote_id'] = (string) $res['id']; $r['stage'] = 'ig_wait';
            } elseif ($d['kind'] === 'reel') {
                $res = $api->page('POST', $target . '/video_reels', ['upload_phase' => 'start']);
                if (empty($res['video_id'])) { throw new RuntimeException('Meta lieferte keine Video-ID.'); }
                $r['remote_id'] = (string) $res['video_id']; $r['stage'] = 'fb_upload';
                $r['upload_url'] = $res['upload_url'] ?? ('https://rupload.facebook.com/video-upload/' . JSSocial_Config::version() . '/' . $r['remote_id']);
            } else {
                self::publish($j, $p, $api, $target . '/photos', ['url' => $d['asset']['url'], 'caption' => $d['captions'][$p], 'published' => 'true']); return;
            }
            $r['state'] = 'processing'; $r['started_at'] = time(); $r['next_at'] = time(); self::save($j);
        }
        if ($r['stage'] === 'fb_upload') {
            $api->page('POST', $r['upload_url'], ['file_url' => ($o['facebook_asset'] ?? $d['asset'])['url']], true);
            $r['stage'] = 'fb_wait'; $r['next_at'] = time() + 30; self::save($j); return;
        }
        if ($r['stage'] === 'ig_wait' || $r['stage'] === 'fb_wait') {
            if (time() - ($r['started_at'] ?? time()) > 2 * HOUR_IN_SECONDS) { throw new RuntimeException('Meta-Verarbeitung dauert länger als zwei Stunden. Medium und Status manuell prüfen.'); }
            try {
                if ($p === 'instagram') {
                    $res = $api->user('GET', $r['remote_id'], ['fields' => 'status_code']); $status = $res['status_code'] ?? '';
                    if (in_array($status, ['ERROR','EXPIRED'], true)) { throw new RuntimeException('Instagram-Container: ' . $status . '. Neuen Entwurf erstellen.'); }
                    if ($status === 'PUBLISHED') { $r['publish_sent'] = true; self::verify_result($j, $p, $api); return; }
                    $ready = $status === 'FINISHED';
                } else {
                    $res = $api->page('GET', $r['remote_id'], ['fields' => 'status']); $s = $res['status'] ?? [];
                    if (in_array($s['video_status'] ?? '', ['error','expired','upload_failed'], true) || ($s['processing_phase']['status'] ?? '') === 'error') { throw new RuntimeException('Facebook-Videoverarbeitung fehlgeschlagen. Video-ID im Beitrag prüfen.'); }
                    $ready = ($s['video_status'] ?? '') === 'ready' || ($s['processing_phase']['status'] ?? '') === 'completed';
                }
            } catch (JSSocial_Meta_Error $e) {
                $r['read_failures']++; $r['error'] = $e->getMessage(); $r['next_at'] = time() + min(1800, 60 * (2 ** min(5, $r['read_failures'])));
                if ($r['read_failures'] >= 8) { $r['state'] = 'failed'; }
                self::save($j); return;
            }
            if (!$ready) { $r['next_at'] = time() + 60; self::save($j); return; }
            if ($p === 'instagram') { self::publish($j, $p, $api, $target . '/media_publish', ['creation_id' => $r['remote_id']]); }
            else { self::publish($j, $p, $api, $target . '/video_reels', ['upload_phase' => 'finish', 'video_id' => $r['remote_id'], 'video_state' => 'PUBLISHED', 'description' => $d['captions'][$p]]); }
        }
    }
    private static function publish(array &$j, string $p, JSSocial_Meta $api, string $path, array $params): void {
        $r = &$j['results'][$p];
        if (!empty($r['publish_sent']) || $r['state'] === 'published') { throw new RuntimeException('Doppelte Veröffentlichungsanfrage verhindert.'); }
        if ($p === 'facebook' && $j['payload']['kind'] === 'reel') {
            $history = array_values(array_filter(get_option('jssocial_fb_publish_attempts', []), fn($t) => $t > time() - DAY_IN_SECONDS));
            if (count($history) >= 30) { throw new RuntimeException('Lokales Facebook-Reel-Limit von 30 Versuchen in 24 Stunden erreicht.'); }
            $history[] = time(); update_option('jssocial_fb_publish_attempts', $history, false);
        }
        $r['publish_sent'] = true; $r['publish_at'] = time(); $r['state'] = 'verifying'; $r['stage'] = 'verify';
        JSSocial_Store::event($j, 'Veröffentlichungsanfrage vorbereitet: ' . $p); self::save($j);
        try { $res = $p === 'instagram' ? $api->user('POST', $path, $params) : $api->page('POST', $path, $params); }
        catch (JSSocial_Meta_Error $e) {
            if (!$e->ambiguous) { $r['publish_sent'] = false; $r['state'] = 'failed'; $r['stage'] = $j['payload']['kind'] === 'image' && $p === 'facebook' ? 'new' : ($p === 'instagram' ? 'ig_wait' : 'fb_wait'); }
            $r['error'] = $e->getMessage(); $r['next_at'] = time() + 60; self::save($j); return;
        }
        if ($p === 'instagram' && !empty($res['id'])) { $r['published_id'] = (string) $res['id']; $r['state'] = 'published'; }
        elseif ($p === 'facebook' && $j['payload']['kind'] === 'image' && !empty($res['id'])) { $r['remote_id'] = (string) $res['id']; $r['published_id'] = (string) ($res['post_id'] ?? $res['id']); $r['state'] = 'published'; }
        // A successful Facebook finish response confirms acceptance, not completed publication.
        $r['next_at'] = time() + 60; self::save($j);
        if ($r['state'] === 'published') { self::permalink($j, $p, $api); }
    }
    public static function verify_result(array &$j, string $p, JSSocial_Meta $api): void {
        $r = &$j['results'][$p];
        if ($r['state'] === 'published') { if (!$r['url']) { self::permalink($j, $p, $api); } return; }
        if (empty($r['publish_sent'])) { return; }
        if (empty($r['remote_id'])) { $r['state'] = 'unknown'; $r['error'] = 'Veröffentlichungsergebnis unklar; keine Meta-ID empfangen. Vor jeder weiteren Aktion das Konto manuell prüfen. Kein automatischer Neuversuch.'; self::save($j); return; }
        try {
            if ($p === 'instagram') {
                $v = $api->user('GET', $r['remote_id'], ['fields' => 'status_code']);
                if (($v['status_code'] ?? '') === 'PUBLISHED') { $r['state'] = 'published'; $r['error'] = $r['published_id'] ? '' : 'Veröffentlichung vom Container bestätigt; Beitrags-ID/Link nach Antwortverlust nicht automatisch zuordenbar. Im Instagram-Konto prüfen.'; }
            } elseif ($j['payload']['kind'] === 'reel') {
                $v = $api->page('GET', $r['remote_id'], ['fields' => 'status']);
                if (($v['status']['publishing_phase']['publish_status'] ?? '') === 'published') { $r['state'] = 'published'; $r['published_id'] = $r['remote_id']; $r['error'] = ''; }
            }
        } catch (Throwable $e) { $r['error'] = $e->getMessage(); }
        if ($r['state'] !== 'published') {
            $r['read_failures']++; $r['state'] = $r['read_failures'] >= 12 ? 'unknown' : 'verifying';
            $r['next_at'] = time() + min(900, 60 * (2 ** min(4, $r['read_failures'])));
            if ($r['state'] === 'unknown') { $r['error'] = 'Veröffentlichungsstatus weiter unklar. Konto und Meta-ID manuell prüfen. Erneutes Senden ist gesperrt. ' . ($r['error'] ?? ''); }
        }
        self::save($j);
        if ($r['state'] === 'published') { self::permalink($j, $p, $api); }
    }
    private static function permalink(array &$j, string $p, JSSocial_Meta $api): void {
        $r = &$j['results'][$p]; if (!$r['published_id']) { return; }
        try {
            if ($p === 'instagram') { $v = $api->user('GET', $r['published_id'], ['fields' => 'permalink']); $link = $v['permalink'] ?? ''; }
            else { $field = $j['payload']['kind'] === 'image' && !str_contains($r['published_id'], '_') ? 'link' : 'permalink_url'; $v = $api->page('GET', $r['published_id'], ['fields' => $field]); $link = $v[$field] ?? ''; if (str_starts_with($link, '/')) { $link = 'https://www.facebook.com' . $link; } }
            if ($link && in_array(wp_parse_url($link, PHP_URL_HOST), ['www.facebook.com','facebook.com','www.instagram.com','instagram.com'], true)) { $r['url'] = esc_url_raw($link, ['https']); }
        } catch (Throwable $e) { $r['error'] = 'Veröffentlicht; Beitragslink derzeit nicht abrufbar. Status erneut prüfen.'; }
        self::save($j);
    }
    public static function reconcile(int $id): array {
        return JSSocial_Store::lock(function () use ($id) {
            $j = JSSocial_Store::get($id); $was_cancelled = $j['state'] === 'cancelled';
            if (!$j['approval']) { return JSSocial_Service::preview($j); }
            foreach ($j['payload']['platforms'] as $p) { if (!empty($j['results'][$p]['publish_sent'])) { self::verify_result($j, $p, new JSSocial_Meta()); } }
            if (!$was_cancelled) { self::aggregate($j); } JSSocial_Store::save($j); return JSSocial_Service::preview($j);
        });
    }
}
