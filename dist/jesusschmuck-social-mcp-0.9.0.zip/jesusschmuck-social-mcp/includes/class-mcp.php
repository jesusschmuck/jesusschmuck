<?php
defined('ABSPATH') || exit;
final class JSSocial_MCP {
    private const OPTION_ENABLED = 'jssocial_mcp_enabled';
    private const OPTION_TOKEN   = 'jssocial_mcp_token';
    private static function ensure_options(): void { if ((string)get_option(self::OPTION_TOKEN,'')==='') update_option(self::OPTION_TOKEN,self::new_token(),false); if (false===get_option(self::OPTION_ENABLED,false)) update_option(self::OPTION_ENABLED,'yes',false); }
    public static function activate(): void { self::ensure_options(); }
    private static function new_token(): string { return wp_generate_password(64,false,false); }
    public static function regenerate_token(): void { update_option(self::OPTION_TOKEN,self::new_token(),false); }
    public static function enabled(): bool { return 'yes' === (string)get_option(self::OPTION_ENABLED,'yes'); }
    public static function private_url(): string { self::ensure_options(); return add_query_arg('access_token',rawurlencode((string)get_option(self::OPTION_TOKEN,'')),rest_url('jssocial/v1/mcp')); }
    public static function register(): void {
        self::ensure_options();
        register_rest_route('jssocial/v1', '/mcp', [
            // MCP capability discovery must be reachable before OAuth is linked. Individual
            // tool calls enforce OAuth inside handle() and return an MCP auth challenge.
            ['methods' => 'POST', 'permission_callback' => [self::class, 'transport'], 'callback' => [self::class, 'handle']],
            ['methods'=>'GET','permission_callback'=>[self::class,'transport'],'callback'=>[self::class,'endpoint_status']],
        ]);
    }
    public static function transport(WP_REST_Request $r) { if (!is_ssl()) return new WP_Error('https_required','HTTPS erforderlich.',['status'=>403]); if (!self::enabled()) return new WP_Error('mcp_disabled','Die Jesusschmuck-Social-MCP-Schnittstelle ist deaktiviert.',['status'=>403]); return true; }
    private static function auth_challenge(string $error = 'invalid_token', string $description = 'OAuth login required'): string {
        $safe_error = preg_replace('/[^A-Za-z0-9_.-]/', '_', $error) ?: 'invalid_token';
        $safe_description = str_replace(['\\', '"', "\r", "\n"], ['\\\\', '\"', ' ', ' '], $description);
        return 'Bearer resource_metadata="' . JSSocial_OAuth::resource_url() . '", error="' . $safe_error . '", error_description="' . $safe_description . '"';
    }
    public static function authorize(WP_REST_Request $r) {
        if (!is_ssl()) return new WP_Error('https_required','HTTPS erforderlich.',['status'=>403]);
        if (!self::enabled()) return new WP_Error('mcp_disabled','Die Jesusschmuck-Social-MCP-Schnittstelle ist deaktiviert.',['status'=>403]);
        $expected=(string)get_option(self::OPTION_TOKEN,''); $provided=(string)$r->get_param('access_token');
        if ($expected!=='' && $provided!=='' && hash_equals($expected,$provided)) return true;
        $auth=(string)$r->get_header('authorization'); $key=preg_match('/^Bearer ([A-Za-z0-9_-]{32,128})$/',$auth,$m)?$m[1]:''; $grant=$key?JSSocial_OAuth::grant($key):[];
        if (!$grant) { header('WWW-Authenticate: '.self::auth_challenge()); return new WP_Error('unauthorized','Social-MCP-Verbindung über OAuth oder private MCP-Adresse erforderlich.',['status'=>401]); }
        if (function_exists('wp_set_current_user') && !empty($grant['user_id'])) wp_set_current_user((int)$grant['user_id']);
        return true;
    }
    public static function endpoint_status(): WP_REST_Response { return new WP_REST_Response(['name'=>'Jesusschmuck Social MCP','version'=>JSSOCIAL_VERSION,'status'=>'ready','read_only'=>false,'authentication'=>'OAuth 2.0 PKCE; private URL token fallback','tools'=>count(self::definitions())],200,['Cache-Control'=>'no-store']); }
    private static function auth_error_result($id, string $message = 'Authentication required: no valid access token provided.'): WP_REST_Response {
        return self::rpc($id, [
            'content' => [['type' => 'text', 'text' => $message]],
            '_meta' => ['mcp/www_authenticate' => [self::auth_challenge('invalid_token', 'Connect Jesusschmuck Social to continue')]],
            'isError' => true,
        ]);
    }
    private static function obj(array $properties, array $required = []): array { $schema=['type'=>'object','properties'=>$properties ?: new stdClass(),'additionalProperties'=>false]; if ($required) $schema['required']=array_values($required); return $schema; }
    private static function routes(): array {
        return [
            'mcp' => rest_url('jssocial/v1/mcp'),
            'oauth_authorization_server' => rest_url('jssocial/v1/oauth'),
            'oauth_authorize' => admin_url('admin-post.php?action=jssocial_mcp_authorize'),
            'oauth_token' => rest_url('jssocial/v1/oauth/token'),
            'oauth_registration' => rest_url('jssocial/v1/oauth/register'),
            'oauth_metadata' => JSSocial_OAuth::metadata(),
            'oauth_resource_metadata' => JSSocial_OAuth::resource(),
            'oauth_authorization_server_discovery' => self::well_known('oauth-authorization-server', rest_url('jssocial/v1/oauth')),
            'oauth_protected_resource_discovery' => JSSocial_OAuth::resource_url(),
            'meta_callback' => JSSocial_Config::callback(),
            'transport' => 'streamable-http-post-jsonrpc',
            'authentication'=>'OAuth 2.0 Authorization Code + PKCE S256 + refresh token; private URL token fallback','private_url_exposed_via_mcp'=>false,
        ];
    }
    private static function well_known(string $kind, string $url): string {
        $u = wp_parse_url($url); $path = $u['path'] ?? '/';
        return ($u['scheme'] ?? 'https') . '://' . ($u['host'] ?? '') . (isset($u['port']) ? ':' . $u['port'] : '') . '/.well-known/' . $kind . $path;
    }
    public static function definitions(): array {
        $str = ['type' => 'string']; $int = ['type' => 'integer', 'minimum' => 1];
        $id = ['job_id' => $int]; $hash = $id + ['preview_hash' => ['type' => 'string', 'pattern' => '^[a-f0-9]{64}$']];
        $draft = self::obj([
            'request_key' => ['type' => 'string', 'pattern' => '^[A-Za-z0-9_-]{8,64}$'], 'attachment_id' => $int,
            'kind' => ['type' => 'string', 'enum' => ['reel','image']], 'platforms' => ['type' => 'array', 'items' => ['type' => 'string', 'enum' => ['instagram','facebook']], 'minItems' => 1, 'maxItems' => 2, 'uniqueItems' => true],
            'instagram_caption' => $str, 'facebook_caption' => $str, 'product_url' => $str, 'campaign' => $str,
            'local_datetime' => ['type' => 'string', 'description' => 'Europe/Berlin: YYYY-MM-DDTHH:MM; leer = sofort nach Freigabe. Auch später heute erlaubt.'], 'utc_offset' => ['type' => 'string', 'enum' => ['','+01:00','+02:00']],
            'facebook_attachment_id' => $int,
            'facebook_audio_rights' => self::obj(['rights_confirmed' => ['type' => 'boolean'], 'rights_basis' => $str], ['rights_confirmed','rights_basis']),
            'cover_id' => $int, 'thumb_offset' => ['type' => 'integer', 'minimum' => 0], 'share_to_feed' => ['type' => 'boolean'],
            'audio' => self::obj(['audio_id' => $str, 'audio_volume' => ['type' => 'integer','minimum' => 0,'maximum' => 100], 'video_volume' => ['type' => 'integer','minimum' => 0,'maximum' => 100], 'rights_confirmed' => ['type' => 'boolean'], 'rights_basis' => $str], ['audio_id','rights_confirmed','rights_basis']),
            'product_tags' => ['type' => 'array','maxItems' => 5,'items' => self::obj(['product_id' => $str, 'x' => ['type' => 'number','minimum' => 0,'maximum' => 1], 'y' => ['type' => 'number','minimum' => 0,'maximum' => 1]], ['product_id'])],
        ], ['request_key','attachment_id','platforms','kind']);
        $settings = self::obj([
            'graph_version' => ['type'=>'string','pattern'=>'^v[0-9]+\\.0$'],
            'fb_config_id' => ['type'=>'string','pattern'=>'^[A-Za-z0-9_-]*$'],
            'business_role_access' => ['type'=>'boolean'],
            'product_tags' => ['type'=>'boolean'],
            'confirm' => ['type'=>'boolean'],
        ], ['confirm']);
        $rows = [
            ['js_social_status','Einrichtungsstatus, Zielkonten, Server-Worker, noch nötige Schritte und Funktionsgrenzen ohne Geheimnisse.', self::obj([]), true],
            ['js_social_routes','Liest die aktiven MCP-, OAuth- und Meta-Callback-Endpunkte samt Discovery-URLs. Keine Geheimnisse.', self::obj([]), true],
            ['js_social_update_settings','Ändert nur nicht-geheime Betriebsoptionen: Graph-Version, optionale Facebook-Login-Config-ID, Business-Rollenmodus und Produktmarkierungen. App-Secret wird niemals per MCP angenommen. confirm=true erforderlich. wp-config-Konstanten bleiben vorrangig.', $settings, false],
            ['js_social_list_targets','Listet die über Meta autorisierten Facebook-Seiten und zugehörigen Instagram-Profikonten sowie das aktuell gewählte Ziel.', self::obj([]), true],
            ['js_social_select_target','Wählt eine bereits über Meta autorisierte Facebook-Seite als Social-Ziel. Bestehende Jobs behalten ihre gebundenen Ziel-IDs. confirm=true erforderlich.', self::obj(['page_id'=>$str,'confirm'=>['type'=>'boolean']],['page_id','confirm']), false],
            ['js_social_verify_connection','Konten und Meta-Berechtigungen lesend prüfen; keine Medienveröffentlichung.', self::obj([]), true],
            ['js_social_upload_media','Eine freigegebene MP4-/JPEG-Datei einmal in WordPress übernehmen, maximal 12 MB; SHA256 verhindert identische Re-Uploads. Noch keine Veröffentlichung.', self::obj(['filename'=>$str,'base64'=>$str],['filename','base64']), false],
            ['js_social_create_draft','Unverbindlichen Entwurf mit beiden Captions und Termin erstellen. Gleichen request_key bei Wiederholung beibehalten. Danach Vorschau vollständig zeigen.', $draft, false],
            ['js_social_preview','Vollständige Vorschau mit Datei, Konten, Texten, Einstellungen, Termin und Freigabe-Prüfwert.', self::obj($id,['job_id']), true],
            ['js_social_list','Geplante Beiträge und andere Zustände anzeigen; mit before_id weiterblättern.', self::obj(['limit'=>['type'=>'integer','minimum'=>1,'maximum'=>100],'before_id'=>$int]), true],
            ['js_social_approve','VERÖFFENTLICHUNG/VERBINDLICHE PLANUNG: Nur nach ausdrücklicher Nutzerfreigabe der exakt gezeigten aktuellen Vorschau aufrufen. Gestaltungsfreigabe genügt nicht. approval_evidence enthält die tatsächliche Freigabe des Nutzers; nichts erfinden. Terminfreigabe erlaubt spätere automatische Veröffentlichung.', self::obj($hash+['confirmation'=>$str,'approval_evidence'=>$str],['job_id','preview_hash','confirmation','approval_evidence']), false],
            ['js_social_reschedule','Terminänderung vorbereiten. Hebt alten Termin auf und setzt auf Entwurf; neue Vorschau muss ausdrücklich freigegeben werden.',self::obj($hash+['local_datetime'=>$str,'utc_offset'=>['type'=>'string','enum'=>['','+01:00','+02:00']]],['job_id','preview_hash','local_datetime']),false],
            ['js_social_cancel','Weitere Verarbeitung stornieren. Bereits veröffentlichte Beiträge werden nicht gelöscht; gesendete Anfragen können noch abschließen.',self::obj($hash,['job_id','preview_hash']),false],
            ['js_social_retry','Nur eine sicher fehlgeschlagene Plattform unter bestehender Freigabe erneut versuchen. Erfolgreiche Plattformen bleiben unberührt; unklare Publikationsanfragen werden gesperrt.',self::obj($id+['platform'=>['type'=>'string','enum'=>['instagram','facebook']]],['job_id','platform']),false],
            ['js_social_reconcile','Nur Meta-Status/Beitragslinks nachlesen; keine erneute Veröffentlichungsanfrage.',self::obj($id,['job_id']),true],
            ['js_social_audio_search','Instagram-Musik/Originalsounds für das verbundene Konto suchen; leere query = angesagte Audios. Vorschau, Katalog und Rechte sind eingeschränkt. Niemals Verfügbarkeit als kommerzielle Lizenz ausgeben.',self::obj(['query'=>$str,'audio_type'=>['type'=>'string','enum'=>['music','original_sound']],'audio_id'=>$str]),true],
        ];
        $opid=['type'=>'string','pattern'=>'^[a-f0-9]{64}$'];
        $rows[]=['js_social_youtube_list','Liest eigene YouTube-Playlists, Playlist-Inhalte, Kanal-Uploads oder den tatsächlichen Videostatus. next_page_token zum Weiterblättern verwenden. Keine Veröffentlichung.',self::obj(['resource'=>['type'=>'string','enum'=>['playlists','playlist_items','uploads','video']],'playlist_id'=>$str,'video_id'=>$str,'page_token'=>$str],['resource']),true];
        $rows[]=['js_social_youtube_prepare','Erstellt eine unverbindliche YouTube-Vorschau: upload_video (lokale MP4 bis 12 MB, 3–900 Sekunden), create_playlist, add_to_playlist oder rename_playlist (eigene Videos/Playlists). Noch kein Google-Schreibzugriff. request_key bei Wiederholung beibehalten; für Änderungen neuen Schlüssel nutzen. Standard-Sichtbarkeit privat. Für automatische Veröffentlichung: upload_video, privacy=public und local_datetime in Europe/Berlin; Upload zunächst privat, Veröffentlichung durch YouTube. Termin mindestens fünf Minuten in der Zukunft. rename_playlist benötigt ausschließlich playlist_id und title; Vorschau zeigt bisherigen Titel, Beschreibung und Sichtbarkeit. Nur der Titel wird geändert; zwischenzeitliche Änderungen blockieren die Ausführung.',self::obj([
            'request_key'=>['type'=>'string','pattern'=>'^[A-Za-z0-9_-]{8,64}$'],
            'operation'=>['type'=>'string','enum'=>['upload_video','create_playlist','add_to_playlist','rename_playlist']],
            'title'=>$str,'description'=>$str,'privacy'=>['type'=>'string','enum'=>['private','unlisted','public']],
            'local_datetime'=>['type'=>'string','pattern'=>'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$','description'=>'Veröffentlichungstermin in Europe/Berlin, nur upload_video mit privacy=public.'],
            'utc_offset'=>['type'=>'string','enum'=>['+01:00','+02:00'],'description'=>'Bei doppelt vorkommender Uhrzeit zur Zeitumstellung erforderlich.'],
            'attachment_id'=>$int,'made_for_kids'=>['type'=>'boolean'],'contains_synthetic_media'=>['type'=>'boolean'],
            'rights_confirmed'=>['type'=>'boolean'],'rights_basis'=>$str,'playlist_id'=>$str,'video_id'=>$str
        ],['request_key','operation']),false];
        $rows[]=['js_social_youtube_preview','Liest die gespeicherte YouTube-Vorschau und den Ausführungsstand. state=complete bestätigt die Operation, nicht automatisch öffentliche Veröffentlichung; result.state und Live-Videostatus beachten.',self::obj(['operation_id'=>$opid],['operation_id']),true];
        $rows[]=['js_social_youtube_execute','SCHREIBT AUF YOUTUBE: Video hochladen (mit freigegebenem Termin zunächst privat und automatisch durch YouTube veröffentlichen), Playlist erstellen, Playlist-Titel ändern oder Video zuordnen. Nur nach Nutzerfreigabe der vollständig gezeigten aktuellen Vorschau. approval_evidence muss die tatsächliche Freigabe wiedergeben. Wiederholung derselben ID erzeugt keine neue Anlage; unklare Playlist-Schreibvorgänge werden gesperrt. Uploads können innerhalb derselben freigegebenen Sitzung fortgesetzt werden.',self::obj(['operation_id'=>$opid,'preview_hash'=>$opid,'confirm'=>['type'=>'boolean'],'approval_evidence'=>$str],['operation_id','preview_hash','confirm','approval_evidence']),false];
        $rows[]=['js_social_tiktok_prepare','Erstellt TikTok-Sandbox-Vorschau für Videoübergabe ins Postfach. MP4 bis 12 MB, 3–900 Sekunden. Kein Upload. Beschreibung wird nur zum Kopieren gespeichert, nicht an TikTok übertragen. TikTok-spezifische Video-/Audiorechte bestätigen. request_key bei Wiederholung beibehalten.',self::obj(['request_key'=>['type'=>'string','pattern'=>'^[A-Za-z0-9_-]{8,64}$'],'attachment_id'=>$int,'description'=>$str,'rights_confirmed'=>['type'=>'boolean'],'rights_basis'=>$str],['request_key','attachment_id','description','rights_confirmed','rights_basis']),false];
        $rows[]=['js_social_tiktok_preview','Liest gespeicherte TikTok-Vorschau und Auftragsstand, ohne Provider-Anfrage.',self::obj(['operation_id'=>$opid],['operation_id']),true];
        $rows[]=['js_social_tiktok_execute','ÜBERTRÄGT VIDEO ZU TIKTOK: nur nach tatsächlicher Nutzerfreigabe der vollständig gezeigten aktuellen Vorschau. approval_evidence muss diese Freigabe wiedergeben. Nur Postfach-Upload, keine Veröffentlichung/Planung. Nutzer muss TikTok-Postfach-Benachrichtigung öffnen und dort fertigstellen. Beschreibung separat kopieren. Unklare Übertragungen nie als neuen Auftrag wiederholen; Status prüfen.',self::obj(['operation_id'=>$opid,'preview_hash'=>$opid,'confirm'=>['type'=>'boolean'],'approval_evidence'=>$str],['operation_id','preview_hash','confirm','approval_evidence']),false];
        $rows[]=['js_social_tiktok_status','Prüft vorhandenen Upload bei TikTok: inbox_ready bestätigt Postfach-Übergabe, published erst manuelle Veröffentlichung. Startet keinen Upload und wiederholt keine Übertragung.',self::obj(['operation_id'=>$opid],['operation_id']),true];
        $rows[]=['js_social_tiktok_creator_info','Liest TikToks aktuelle Creator-Info für Direct Post. Benötigt video.publish; keine Veröffentlichung.',self::obj([]),true];
        $rows[]=['js_social_tiktok_direct_prepare','Erstellt unverbindliche TikTok-Direct-Post-Vorschau mit Caption, Sichtbarkeit, Interaktionen, Commercial-Content-Angaben, Cover und optionalem Europe/Berlin-Termin.',self::obj(['request_key'=>['type'=>'string','pattern'=>'^[A-Za-z0-9_-]{8,64}$'],'attachment_id'=>$int,'title'=>$str,'privacy_level'=>['type'=>'string','enum'=>['PUBLIC_TO_EVERYONE','MUTUAL_FOLLOW_FRIENDS','FOLLOWER_OF_CREATOR','SELF_ONLY']],'disable_comment'=>['type'=>'boolean'],'disable_duet'=>['type'=>'boolean'],'disable_stitch'=>['type'=>'boolean'],'video_cover_timestamp_ms'=>['type'=>'integer','minimum'=>0],'brand_content_toggle'=>['type'=>'boolean'],'brand_organic_toggle'=>['type'=>'boolean'],'is_aigc'=>['type'=>'boolean'],'rights_confirmed'=>['type'=>'boolean'],'rights_basis'=>$str,'local_datetime'=>['type'=>'string','pattern'=>'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$'],'utc_offset'=>['type'=>'string','enum'=>['+01:00','+02:00']]],['request_key','attachment_id','title','privacy_level','brand_content_toggle','brand_organic_toggle','rights_confirmed','rights_basis']),false];
        $rows[]=['js_social_tiktok_direct_preview','Liest gespeicherte TikTok-Direct-Post-Vorschau.',self::obj($id,['job_id']),true];
        $rows[]=['js_social_tiktok_direct_approve','VERÖFFENTLICHUNG/VERBINDLICHE PLANUNG AUF TIKTOK: nur nach ausdrücklicher Freigabe der vollständig gezeigten Vorschau.',self::obj($hash+['confirmation'=>$str,'approval_evidence'=>$str],['job_id','preview_hash','confirmation','approval_evidence']),false];
        $rows[]=['js_social_tiktok_direct_reschedule','Ändert Termin eines noch nicht initialisierten TikTok Direct Posts; neue Freigabe erforderlich.',self::obj($hash+['local_datetime'=>$str,'utc_offset'=>['type'=>'string','enum'=>['','+01:00','+02:00']]],['job_id','preview_hash','local_datetime']),false];
        $rows[]=['js_social_tiktok_direct_cancel','Storniert TikTok Direct Post vor Provider-Initialisierung.',self::obj($hash,['job_id','preview_hash']),false];
        $rows[]=['js_social_tiktok_direct_status','Prüft TikTok-Status anhand gespeicherter publish_id; startet keinen neuen Post.',self::obj($id,['job_id']),true];
        return array_map(function($r){
            $name=$r[0];
            return ['name'=>$name,'description'=>$r[1],'inputSchema'=>$r[2],
                'securitySchemes'=>[['type'=>'oauth2','scopes'=>['social:manage']]],
                'annotations'=>[
                    'readOnlyHint'=>$r[3],
                    'destructiveHint'=>in_array($name,['js_social_approve','js_social_youtube_execute','js_social_tiktok_execute'],true),
                    'idempotentHint'=>!in_array($name,['js_social_reschedule','js_social_approve'],true),
                    'openWorldHint'=>true,
                ],
            ];
        },$rows);
    }
    public static function validate($value, array $s, string $path = 'arguments'): void {
        $type = $s['type'];
        $valid = match ($type) { 'object' => is_array($value) || $value instanceof stdClass, 'array' => is_array($value) && array_is_list($value), 'integer' => is_int($value), 'number' => is_numeric($value) && !is_string($value), 'boolean' => is_bool($value), 'string' => is_string($value), default => false };
        if (!$valid) { throw new InvalidArgumentException($path . ': falscher Datentyp.'); }
        if (isset($s['enum']) && !in_array($value,$s['enum'],true)) { throw new InvalidArgumentException($path . ': ungültiger Wert.'); }
        if ((isset($s['minimum']) && $value < $s['minimum']) || (isset($s['maximum']) && $value > $s['maximum'])) { throw new InvalidArgumentException($path . ': außerhalb des Wertebereichs.'); }
        if (isset($s['pattern']) && !preg_match('~'.$s['pattern'].'~',$value)) { throw new InvalidArgumentException($path . ': ungültiges Format.'); }
        if ($type === 'object') {
            $value = (array) $value; $props = (array) $s['properties'];
            if (array_diff(array_keys($value),array_keys($props)) || array_diff($s['required'] ?? [],array_keys($value))) { throw new InvalidArgumentException($path . ': fehlende oder unbekannte Felder.'); }
            foreach ($value as $k=>$v) { self::validate($v,$props[$k],$path.'.'.$k); }
        }
        if ($type === 'array') {
            if (count($value)<($s['minItems']??0) || count($value)>($s['maxItems']??PHP_INT_MAX) || (!empty($s['uniqueItems']) && count(array_unique($value,SORT_REGULAR))!==count($value))) { throw new InvalidArgumentException($path . ': ungültige Liste.'); }
            foreach ($value as $v) { self::validate($v,$s['items'],$path.'[]'); }
        }
    }
    public static function call(string $name, array $a): array {
        $defs = array_column(self::definitions(),null,'name');
        if (!isset($defs[$name])) { throw new InvalidArgumentException('Werkzeug nicht gefunden.'); }
        self::validate($a,$defs[$name]['inputSchema']);
        return match ($name) {
            'js_social_status' => JSSocial_Config::public_status(),
            'js_social_tiktok_prepare' => JSSocial_TikTok_Actions::prepare($a),
            'js_social_tiktok_preview' => JSSocial_TikTok_Actions::preview($a['operation_id']),
            'js_social_tiktok_execute' => JSSocial_TikTok_Actions::execute($a),
            'js_social_tiktok_status' => JSSocial_TikTok_Actions::status($a['operation_id']),
            'js_social_tiktok_creator_info' => JSSocial_TikTok_Direct::creator_info(),
            'js_social_tiktok_direct_prepare' => JSSocial_TikTok_Direct::prepare($a),
            'js_social_tiktok_direct_preview' => JSSocial_TikTok_Direct::preview(JSSocial_Store::get($a['job_id'])),
            'js_social_tiktok_direct_approve' => JSSocial_TikTok_Direct::approve($a['job_id'],$a['preview_hash'],$a['confirmation'],$a['approval_evidence']),
            'js_social_tiktok_direct_reschedule' => JSSocial_TikTok_Direct::reschedule($a['job_id'],$a['preview_hash'],$a['local_datetime'],$a['utc_offset']??''),
            'js_social_tiktok_direct_cancel' => JSSocial_TikTok_Direct::cancel($a['job_id'],$a['preview_hash']),
            'js_social_tiktok_direct_status' => JSSocial_TikTok_Direct::status($a['job_id']),
            'js_social_youtube_list' => JSSocial_YouTube_Actions::listing($a),
            'js_social_youtube_prepare' => JSSocial_YouTube_Actions::prepare($a),
            'js_social_youtube_preview' => JSSocial_YouTube_Actions::preview($a['operation_id']),
            'js_social_youtube_execute' => JSSocial_YouTube_Actions::execute($a),
            'js_social_routes' => self::routes(),
            'js_social_update_settings' => self::update_settings($a),
            'js_social_list_targets' => ['targets'=>JSSocial_Config::available_targets()],
            'js_social_select_target' => self::select_target($a),
            'js_social_verify_connection' => (new JSSocial_Meta())->verify(),
            'js_social_upload_media' => JSSocial_Service::upload($a['filename'],$a['base64']),
            'js_social_create_draft' => JSSocial_Service::create($a),
            'js_social_preview' => JSSocial_Service::preview(JSSocial_Store::get($a['job_id'])),
            'js_social_list' => ['jobs'=>array_map([JSSocial_Service::class,'preview'],JSSocial_Store::listing($a['limit']??30,$a['before_id']??0))],
            'js_social_approve' => JSSocial_Service::approve($a['job_id'],$a['preview_hash'],$a['confirmation'],$a['approval_evidence']),
            'js_social_reschedule' => JSSocial_Service::reschedule($a['job_id'],$a['preview_hash'],$a['local_datetime'],$a['utc_offset']??''),
            'js_social_cancel' => JSSocial_Service::cancel($a['job_id'],$a['preview_hash']),
            'js_social_retry' => JSSocial_Service::retry($a['job_id'],$a['platform']),
            'js_social_reconcile' => JSSocial_Worker::reconcile($a['job_id']),
            'js_social_audio_search' => (new JSSocial_Meta())->audio($a['query']??'',$a['audio_type']??'music',$a['audio_id']??''),
        };
    }
    private static function update_settings(array $a): array {
        if (($a['confirm'] ?? false) !== true) { throw new InvalidArgumentException('confirm=true ist für Einstellungsänderungen erforderlich.'); }
        unset($a['confirm']); return JSSocial_Config::save_operational_settings($a);
    }
    private static function select_target(array $a): array {
        if (($a['confirm'] ?? false) !== true) { throw new InvalidArgumentException('confirm=true ist für den Zielwechsel erforderlich.'); }
        return JSSocial_Config::select_target((string) $a['page_id']);
    }
    public static function handle(WP_REST_Request $request): WP_REST_Response {
        $b = $request->get_json_params();
        $id = is_array($b) ? ($b['id'] ?? null) : null;
        if (!is_array($b) || ($b['jsonrpc'] ?? '') !== '2.0' || !is_string($b['method'] ?? null)) { return self::rpc($id,null,[-32600,'Ungültiger JSON-RPC-Request.']); }
        if (!array_key_exists('id',$b)) { return new WP_REST_Response(null,202,['Cache-Control'=>'no-store']); }
        $p = $b['params'] ?? [];
        if (!is_array($p)) { return self::rpc($id,null,[-32602,'Ungültige Parameter.']); }
        switch ($b['method']) {
            case 'initialize':
                $v = $p['protocolVersion'] ?? ''; if (!in_array($v,['2024-11-05','2025-03-26','2025-06-18'],true)) { $v='2025-06-18'; }
                return self::rpc($id,['protocolVersion'=>$v,'capabilities'=>['tools'=>['listChanged'=>false]],'serverInfo'=>['name'=>'jesusschmuck-social','version'=>JSSOCIAL_VERSION],'instructions'=>'Einrichtung darf über die dafür vorgesehenen Social-Tools verwaltet werden. Meta-App-Secret niemals im Chat anfordern; falls es fehlt, Nutzer zur geschützten WordPress-Eingabe führen. Entwürfe sind unverbindlich. Vor approve vollständige Vorschau zeigen und ausdrückliche Nutzerfreigabe des genauen Inhalts und Termins einholen. Gestaltung ist keine Veröffentlichungsfreigabe.']);
            case 'ping': return self::rpc($id,new stdClass());
            case 'tools/list': return self::rpc($id,['tools'=>self::definitions()]);
            case 'tools/call':
                $auth = self::authorize($request);
                if ($auth !== true) { return self::auth_error_result($id); }
                try { $result=self::call((string)($p['name']??''),(array)($p['arguments']??[])); return self::rpc($id,['content'=>[['type'=>'text','text'=>wp_json_encode($result,JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)]],'structuredContent'=>$result,'isError'=>false]); }
                catch (Throwable $e) { return self::rpc($id,['content'=>[['type'=>'text','text'=>$e->getMessage()]],'isError'=>true]); }
            default: return self::rpc($id,null,[-32601,'Methode nicht unterstützt.']);
        }
    }
    private static function rpc($id,$result,?array $error=null): WP_REST_Response { return new WP_REST_Response(['jsonrpc'=>'2.0','id'=>$id]+($error?['error'=>['code'=>$error[0],'message'=>$error[1]]]:['result'=>$result]),200,['Cache-Control'=>'no-store']); }
}
