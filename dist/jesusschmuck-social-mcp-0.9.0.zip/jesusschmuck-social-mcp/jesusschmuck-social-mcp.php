<?php
/**
 * Plugin Name: Jesusschmuck Social MCP
 * Description: Eigenständige Instagram-/Facebook-Veröffentlichung mit Vorschau, Freigabe, Server-Warteschlange und MCP.
 * Version: 0.9.0
 * Requires at least: 6.4
 * Requires PHP: 8.1
 * Author: Jesusschmuck.com
 * License: GPL-2.0-or-later
 * Text Domain: jesusschmuck-social-mcp
 */
defined('ABSPATH') || exit;
define('JSSOCIAL_VERSION', '0.9.0');
define('JSSOCIAL_DIR', __DIR__ . '/');

// Exact allowlist: load a module only when one of its classes is actually used.
spl_autoload_register(static function (string $class): void {
    static $modules = [
        'JSSocial_Config' => 'config',
        'JSSocial_Store' => 'store',
        'JSSocial_Gate' => 'gate',
        'JSSocial_Meta' => 'meta',
        'JSSocial_Meta_Error' => 'meta',
        'JSSocial_Service' => 'service',
        'JSSocial_Worker' => 'worker',
        'JSSocial_OAuth' => 'oauth',
        'JSSocial_MCP' => 'mcp',
        'JSSocial_Admin' => 'admin',
        'JSSocial_YouTube' => 'youtube',
        'JSSocial_TikTok' => 'tiktok',
        'JSSocial_TikTok_Actions' => 'tiktok-actions',
        'JSSocial_TikTok_Direct' => 'tiktok-direct',
        'JSSocial_YouTube_Actions' => 'youtube-actions',
    ];
    if (isset($modules[$class])) {
        require_once JSSOCIAL_DIR . 'includes/class-' . $modules[$class] . '.php';
    }
});

// Closures keep WordPress callback validation from autoloading classes early.
register_activation_hook(__FILE__, static function (): void { JSSocial_Store::install(); JSSocial_MCP::activate(); });
add_action('rest_api_init', static function (): void {
    JSSocial_MCP::register();
    JSSocial_OAuth::register_routes();
});
add_action('admin_menu', static function (): void {
    add_menu_page('Jesusschmuck Social', 'Jesusschmuck Social', 'manage_options', 'jssocial',
        static function (): void { JSSocial_Admin::render(); }, 'dashicons-share', 58);
});
add_action('admin_enqueue_scripts', static function ($hook): void {
    if ($hook === 'toplevel_page_jssocial') { JSSocial_Admin::enqueue(); }
});
add_action('admin_post_jssocial_action', static function (): void { JSSocial_Admin::action(); });
add_action('admin_post_jssocial_oauth', static function (): void { JSSocial_Admin::oauth(); });
add_action('admin_post_jssocial_mcp_authorize', static function (): void { JSSocial_OAuth::authorize(); });
add_action('admin_post_nopriv_jssocial_mcp_authorize', static function (): void { JSSocial_OAuth::login(); });
add_action('admin_post_jssocial_mcp_consent', static function (): void { JSSocial_OAuth::consent(); });
if (str_starts_with((string)($_SERVER['REQUEST_URI']??''),'/.well-known/oauth-authorization-server') || str_starts_with((string)($_SERVER['REQUEST_URI']??''),'/.well-known/oauth-protected-resource')) add_action('parse_request', static function (): void { JSSocial_OAuth::discovery(); }, 0);
if (defined('WP_CLI') && WP_CLI) {
    WP_CLI::add_command('jssocial tick', function () {
        try { WP_CLI::success(wp_json_encode(JSSocial_Worker::tick())); }
        catch (Throwable $e) { WP_CLI::error($e->getMessage()); }
    });
}

add_action('admin_post_jssocial_youtube_oauth', static function (): void { JSSocial_YouTube::callback_action(); });
add_action('admin_post_jssocial_youtube_action', static function (): void { JSSocial_YouTube::admin_action(); });

add_action('admin_post_jssocial_tiktok_action', static function (): void { JSSocial_TikTok::admin_action(); });
add_action('parse_request', static function (): void {
    if (parse_url((string)($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH) === parse_url(JSSocial_TikTok::callback(), PHP_URL_PATH)) {
        JSSocial_TikTok::callback_action();
    }
}, 0);
