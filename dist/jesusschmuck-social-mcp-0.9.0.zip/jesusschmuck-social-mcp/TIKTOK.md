# TikTok Content Posting 0.9.0

Unterstützt weiterhin Upload-to-TikTok (video.upload) und zusätzlich Direct Post (video.publish).

Direct Post: Creator Info wird vor Vorschau und vor Ausführung erneut geprüft. Der vorhandene Jesusschmuck-Server-Worker löst freigegebene Posts erst zum gespeicherten Europe/Berlin-Termin aus. TikTok selbst erhält keinen Vorab-Termin. Nicht eindeutige Initialisierungen oder Uploads werden nie blind wiederholt. Nicht auditierte TikTok-Clients können nur privat posten.
